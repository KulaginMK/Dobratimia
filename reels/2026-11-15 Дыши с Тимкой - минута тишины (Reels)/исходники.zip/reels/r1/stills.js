// Обложка (сетка профиля видит центр 1080×1350) и кадр сторис для репоста с местом под стикер.
(function () {
  const kind = new URLSearchParams(location.search).get('still');
  if (!kind) return;
  const { C, svg } = R;
  const S = R.stage(C.bg);
  const decor = [
    [110, 430, 230, C.soft, 0.5],
    [1010, 1230, 170, C.growthSoft, 0.85],
    [70, 1690, 270, C.soft, 0.42],
    [990, 280, 120, C.growthSoft, 0.7],
  ];
  decor.forEach(([x, y, r, c, o]) => svg('circle', { cx: x, cy: y, r, fill: c, opacity: o }, S.world));
  let tk;
  const fill = 0.35;
  if (kind === 'cover') {
    R.chip(S, { text: 'Дыши с Тимкой', y: 330 });
    R.textBlock(S.text, { text: 'Минута\nтишины', y: 440, size: 150, line: 160, w: 960 });
    svg('circle', { cx: 540, cy: 1120, r: 300, fill: C.soft }, S.world);
    tk = R.breathingTimka(S.world);
    tk.update({ t: 0.5, fill, face: { kind: 'rest', from: 'rest', shift: 1 }, x: 540, y: 1120, size: 470, noBlink: true });
    R.textBlock(S.text, { text: 'Закройте конспект и отпустите тело по частям', y: 1470, size: 48, line: 60, w: 820, font: 'text', weight: 600, color: C.text });
  } else {
    R.wordmark(S, { y: 300, h: 76 });
    R.textBlock(S.text, { text: 'Получилось\nостановиться\nна минуту?', y: 440, size: 96, line: 108, w: 940 });
    svg('circle', { cx: 540, cy: 990, r: 190, fill: C.soft }, S.world);
    tk = R.breathingTimka(S.world);
    tk.update({ t: 0.5, fill, face: { kind: 'look', from: 'look', shift: 1 }, x: 540, y: 990, size: 300, noBlink: true });
    R.textBlock(S.text, { text: 'Ответьте в опросе ниже', y: 1230, size: 44, line: 56, font: 'text', weight: 600, color: C.primary });
  }
  window.renderAt = () => {};
  R.ready().then(() => (window.READY = true));
})();
