// «Дыши с Тимкой — минута тишины». 58 с, петля: кадр 58,0 совпадает с кадром 0.
(function () {
  const { C, clamp, lerp, ease, win, keys, svg, tr, op, set } = R;
  const D = 58;
  const TAU = Math.PI * 2;
  const per = (k) => (TAU * k) / D; // частоты, кратные петле: дрейф на шве не прыгает
  const CX = 540;
  const CY = 960;
  const R0 = 330;
  const TK = 520; // сторона рисунка Тимки, px
  const U = TK / 120; // px в единице рисунка
  const BOTTOM = CY + 48 * U; // низ тела Тимки
  const KIDLE = { idleSpeed: per(16), blinkEvery: D / 16 };

  if (new URLSearchParams(location.search).get('still')) return; // обложка и сторис — в stills.js
  const S = R.stage(C.bg);
  const far = svg('g', {}, S.world);
  const scene = svg('g', {}, S.world);
  const ui = svg('g', {}, S.world);

  // ---- дальний план: крупные мягкие пятна, глубина 0,45 ----
  const blobs = [
    { x: 110, y: 430, r: 230, c: C.soft, o: 0.5 },
    { x: 1010, y: 1230, r: 170, c: C.growthSoft, o: 0.85 },
    { x: 70, y: 1690, r: 270, c: C.soft, o: 0.42 },
    { x: 990, y: 280, r: 120, c: C.growthSoft, o: 0.7 },
  ].map((b) => ({ ...b, n: svg('circle', { cx: b.x, cy: b.y, r: b.r, fill: b.c, opacity: b.o }, far) }));

  // ---- круг тишины и земля внутри него ----
  const disc = svg('g', {}, scene);
  const clip = svg('clipPath', { id: 'discClip', clipPathUnits: 'userSpaceOnUse' }, S.defs);
  const clipC = svg('circle', { cx: CX, cy: CY, r: R0 }, clip);
  const circle = svg('circle', { cx: CX, cy: CY, r: R0, fill: C.soft }, disc);
  const groundG = svg('g', { 'clip-path': 'url(#discClip)' }, disc);
  const ground = svg('rect', { x: 0, y: 1300, width: 1080, height: 900, fill: C.growthSoft }, groundG);
  const ripples = [0, 1].map(() => svg('ellipse', { cx: CX, cy: BOTTOM, rx: 60, ry: 10, fill: 'none', stroke: C.growth, 'stroke-width': 5 }, groundG));

  // ---- Тимка ----
  const EYES_OPEN =
    '<ellipse cx="48" cy="64" rx="3.5" ry="4.3" fill="#2C1F1A"/><circle cx="49.2" cy="62.4" r="1.1" fill="#FFFFFF"/><ellipse cx="72" cy="64" rx="3.5" ry="4.3" fill="#2C1F1A"/><circle cx="73.2" cy="62.4" r="1.1" fill="#FFFFFF"/>';
  const EYES_CLOSED =
    '<path d="M44 64 Q48 67.5 52 64" fill="none" stroke="#2C1F1A" stroke-width="2.6" stroke-linecap="round"/><path d="M68 64 Q72 67.5 76 64" fill="none" stroke="#2C1F1A" stroke-width="2.6" stroke-linecap="round"/>';
  const CHEEKS = (o) => `<ellipse cx="39" cy="73" rx="5.5" ry="3.2" fill="#E07A5F" opacity="${o}"/><ellipse cx="81" cy="73" rx="5.5" ry="3.2" fill="#E07A5F" opacity="${o}"/>`;
  const tkG = svg('g', {}, scene);
  const tk = R.breathingTimka(tkG, {
    // Сжатая челюсть: глаза открыты, губы ровной чертой.
    tense: CHEEKS(0.5) + EYES_OPEN + '<path d="M55.5 78 H64.5" fill="none" stroke="#2C1F1A" stroke-width="2.6" stroke-linecap="round"/>',
    // Челюсть отпустили: глаза закрыты, рот чуть приоткрыт кружком (без губ и языка).
    jaw: CHEEKS(0.55) + EYES_CLOSED + '<ellipse class="m" cx="60" cy="79" rx="2.6" ry="2.6" fill="#2C1F1A"/>',
  });
  const jawMouth = tk.faces.jaw.querySelector('.m');
  // Лапка на животе — та же форма, что у позы hello, лежит позади тела у правого бока.
  const hand = svg('g', {}, tk.behind);
  svg('ellipse', { cx: 99, cy: 87, rx: 7, ry: 11, transform: 'rotate(52 99 87)', fill: '#F2B28A' }, hand);

  // Медовые искорки (F): маленькие акценты.
  const sparks = [
    [CX + 170, CY - 250, 0],
    [CX - 175, CY - 200, 0.35],
    [CX + 120, CY - 330, 0.7],
  ].map(([x, y, d]) => ({ x, y, d, n: svg('rect', { x: -14, y: -14, width: 28, height: 28, rx: 3, fill: C.honey }, scene) }));

  // ---- конспект ----
  const book = svg('g', {}, scene);
  const BX = 120;
  const BY = 1050;
  const BW = 840;
  const BH = 520;
  const leftHalf = svg('g', {}, book);
  svg('rect', { x: BX, y: BY, width: BW / 2 + 20, height: BH, rx: 30, fill: C.choco }, leftHalf);
  svg('rect', { x: BX + 18, y: BY + 16, width: BW / 2 - 24, height: BH - 32, rx: 18, fill: C.bg }, leftHalf);
  const rightHalf = svg('g', {}, book);
  const rightFront = svg('g', {}, rightHalf);
  svg('rect', { x: CX - 20, y: BY, width: BW / 2 + 20, height: BH, rx: 30, fill: C.choco }, rightFront);
  svg('rect', { x: CX + 6, y: BY + 16, width: BW / 2 - 24, height: BH - 32, rx: 18, fill: C.bg }, rightFront);
  const rightBack = svg('g', {}, rightHalf);
  svg('rect', { x: CX - 20, y: BY, width: BW / 2 + 20, height: BH, rx: 30, fill: C.choco }, rightBack);
  svg('rect', { x: CX + 150, y: BY + 200, width: 120, height: 18, rx: 9, fill: C.soft, opacity: 0.55 }, rightBack);
  const lines = (g, x0, list) =>
    list.forEach(([w, c], i) => svg('rect', { x: x0, y: BY + 70 + i * 50, width: w, height: 18, rx: 9, fill: c }, g));
  lines(leftHalf, BX + 56, [[250, C.primary], [320, C.soft], [300, C.soft], [330, C.soft], [210, C.soft], [310, C.soft], [280, C.soft], [180, C.soft]]);
  lines(rightFront, CX + 44, [[300, C.soft], [260, C.soft], [320, C.soft], [150, C.soft]]);
  // маленькое сердце-схема на правой странице
  svg('path', { d: `M${CX + 190} ${BY + 330} c-34 -26 -60 -46 -60 -74 c0 -20 16 -34 34 -34 c12 0 21 6 26 15 c5 -9 14 -15 26 -15 c18 0 34 14 34 34 c0 28 -26 48 -60 74z`, fill: C.primary, opacity: 0.85 }, rightFront);
  lines(rightFront, CX + 44, []);

  // ---- точки шагов ----
  const dots = [0, 1, 2, 3, 4].map((i) => svg('circle', { cx: CX + (i - 2) * 66, cy: 1500, r: 14, fill: C.soft }, ui));

  // ---- знак ----
  const mark = R.logo(ui, 'logo-mark');

  // ---- тексты ----
  const prompts = [
    { a: -10, b: 2.75, text: 'Закройте конспект\nна минуту' },
    { a: 3.0, b: 11.7, text: 'Опустите плечи' },
    { a: 12.0, b: 20.7, text: 'Разожмите челюсть' },
    { a: 21.0, b: 29.7, text: 'Почувствуйте\nстопы на полу' },
    { a: 30.0, b: 39.7, text: 'Положите руку на живот\nи сделайте три\nмедленных выдоха', size: 72 },
    { a: 40.0, b: 49.7, text: 'Заметьте,\nчто изменилось' },
    { a: 50.4, b: 56.75, text: 'Вы молодец,\nчто остановились', color: C.onSoft },
  ].map((p) => ({ ...p, n: R.textBlock(S.text, { text: p.text, y: 300, w: 900, size: p.size || 76, line: p.size ? 86 : 90, color: p.color || C.text, words: true }) }));
  const dizzy = R.textBlock(S.text, { text: 'Если закружилась голова,\nвернитесь к обычному дыханию', y: 1556, w: 900, font: 'text', weight: 400, size: 38, line: 48, color: C.text });
  const save = R.textBlock(S.text, { text: 'Сохраните, чтобы вернуться\nк этой минуте', y: 1455, w: 820, font: 'text', weight: 600, size: 44, line: 58, color: C.onSoft, words: true });

  // ---- дорожки ----
  const faceTrack = [
    [0, 'look'],
    [3.3, 'in'],
    [4.9, 'out'],
    [7.3, 'rest'],
    [8.0, 'in'],
    [9.5, 'out'],
    [11.6, 'rest'],
    [12.2, 'tense'],
    [14.4, 'jaw'],
    [18.8, 'rest'],
    [31.0, 'in'],
    [32.2, 'out'],
    [34.4, 'in'],
    [35.6, 'out'],
    [37.8, 'in'],
    [39.0, 'out'],
    [41.2, 'rest'],
    [41.9, 'look'],
    [50.6, 'rest'],
    [53.4, 'look'],
  ];
  // Наполненность L: явные ключи там, где Тимка дышит по сценарию; в остальное время — спокойное «живое» дыхание.
  const idleFill = (t) => 0.25 + 0.07 * Math.sin(per(10) * t);
  const fillKeys = [
    [3.3, idleFill(3.3)],
    [4.9, 1],
    [7.3, 0],
    [8.0, 0],
    [9.5, 1],
    [11.6, 0],
    [12.6, idleFill(12.6)],
  ];
  const breathKeys = [
    [30.4, idleFill(30.4)],
    [31.0, 0],
    [32.2, 1],
    [34.4, 0],
    [35.6, 1],
    [37.8, 0],
    [39.0, 1],
    [41.2, 0],
    [42.2, idleFill(42.2)],
  ];
  function fillAt(t) {
    if (t >= 3.3 && t <= 12.6) return keys(t, fillKeys);
    if (t >= 30.4 && t <= 42.2) return keys(t, breathKeys);
    return idleFill(t);
  }

  function cameraAt(t) {
    const z = keys(t, [
      [0, 1.0],
      [3, 1.02],
      [12, 1.05],
      [15.2, 1.3],
      [20, 1.32],
      [23, 1.15],
      [28.6, 1.12],
      [30.3, 1.0],
      [40, 1.03],
      [47, 0.98],
      [57, 1.0],
      [58, 1.0],
    ]);
    const cy = keys(t, [
      [0, CY],
      [12, CY],
      [15.2, CY + 95],
      [20, CY + 95],
      [23, CY + 150],
      [28.6, CY + 140],
      [30.3, CY - 45],
      [40.5, CY - 45],
      [46, CY],
      [58, CY],
    ]);
    return {
      cx: CX,
      cy,
      z,
      x: 6 * Math.sin(per(3) * t),
      y: 5 * Math.sin(per(2) * t + 1),
      r: 0.35 * Math.sin(per(2) * t + 0.5),
    };
  }

  // Появление и уход фразы: слова поднимаются по очереди за 0,8 с, уходят вверх за 0,35 с.
  function promptState(p, t) {
    if (p.a < 0) {
      // хук: виден с первого кадра, на шве петли возвращается к 58,0
      if (t >= 57.3) return { k: (t - 57.3) / 0.65, out: 0 };
      return { k: 1, out: clamp((t - p.b) / 0.3) };
    }
    return { k: (t - p.a) / 0.8, out: clamp((t - p.b) / 0.3) };
  }

  window.renderAt = function (tRaw) {
    const t = ((tRaw % D) + D) % D;
    // ---- камера ----
    const cam = cameraAt(t);
    tr(scene, R.camera(cam, 1));
    tr(far, R.camera(cam, 0.45));
    blobs.forEach((b, i) => set(b.n, { cy: b.y + 14 * Math.sin(per(1) * t + i * 1.9), cx: b.x + 8 * Math.sin(per(1) * t + i) }));

    // ---- круг: живое дыхание, дыхание в E, расширение в G и сжатие на шве ----
    const L = fillAt(t);
    const wBreath = win(t, 30.4, 31.0, 41.2, 42.0);
    const sc = lerp(1 + 0.012 * Math.sin(per(10) * t), 0.93 + 0.07 * L, wBreath);
    const rr = keys(t, [
      [50.0, R0],
      [55.6, 1260],
      [57.0, 1260],
      [58.0, R0],
    ], ease.inOutCubic);
    const rad = (t < 50 ? R0 : rr) * sc;
    set(circle, { r: rad });
    set(clipC, { r: rad });

    // ---- земля ----
    const gTop = keys(t, [
      [21.3, CY + 360],
      [23.0, BOTTOM],
      [41.6, BOTTOM],
      [44.6, 2100],
    ], ease.inOutCubic);
    set(ground, { y: gTop });
    [23.0, 26.4].forEach((t0, i) => {
      const q = (t - t0) / 1.7;
      const n = ripples[i];
      if (q < 0 || q > 1) return op(n, 0);
      op(n, 0.5 * (1 - ease.outCubic(q)));
      set(n, { rx: 80 + 300 * ease.outCubic(q), ry: 12 + 34 * ease.outCubic(q), cy: BOTTOM + 4 });
    });

    // ---- Тимка ----
    const face = R.faceAt(faceTrack, t);
    // касание земли: короткое приседание и мягкое возвращение (без пружины)
    const press = (t0, a) => a * (win(t, t0, t0 + 0.22, t0 + 0.22, t0 + 1.0, ease.outCubic));
    const settle = win(t, 23.0, 24.0, 41.4, 43.0) * 0.012;
    const sq = press(23.0, 0.035) + press(26.4, 0.022) + settle;
    // «Плечи» в B: на подъёме тело тянется вверх
    const tension = 0.05 * (win(t, 3.3, 4.9, 4.9, 6.6) + win(t, 8.0, 9.5, 9.5, 11.0));
    const eyeDx = keys(t, [
      [42.6, 0],
      [43.3, -2.6],
      [44.6, -2.6],
      [45.3, 2.6],
      [46.6, 2.6],
      [47.2, 0],
    ]);
    const eyeDy = keys(t, [
      [0, 2.2],
      [1.1, 2.2],
      [1.7, 0],
      [47.0, 0],
      [47.5, -2.0],
      [48.9, -2.0],
      [49.5, 0],
      [57.25, 0],
      [57.8, 2.2],
      [58, 2.2],
    ]);
    const res = tk.update({
      t,
      fill: L,
      face,
      x: CX,
      y: CY,
      size: TK,
      extraX: sq,
      extraY: -sq + tension,
      eyeDx,
      eyeDy,
      leafLift: -0.14 * win(t, 47.0, 47.8, 49.0, 50.0),
      ...KIDLE,
    });
    // челюсть опускается: рот-кружок чуть раскрывается
    const jaw = ease.inOutSine((t - 14.6) / 1.6);
    set(jawMouth, { ry: 2.4 + 1.2 * jaw, rx: 2.4 + 0.5 * jaw });
    // лапка: выезжает из-за бока, едет вместе с краем тела
    const hIn = win(t, 30.2, 30.9, 41.2, 41.9, ease.inOutCubic);
    tr(hand, `translate(${-12 * (1 - hIn) + (res.sx - 1) * 41} ${3 * (1 - hIn)})`);
    op(hand, hIn > 0.01 ? 1 : 0);

    // искорки, когда Тимка смотрит вверх
    sparks.forEach((s) => {
      const q = win(t, 47.6 + s.d, 48.0 + s.d, 48.7 + s.d, 49.4 + s.d);
      const tw = 0.75 + 0.25 * Math.sin(t * 9 + s.d * 5);
      op(s.n, q);
      tr(s.n, `translate(${s.x} ${s.y - 14 * q}) rotate(45) scale(${q * tw})`);
    });

    // ---- конспект: закрывается 0,95–1,55, уезжает 1,7–2,7; возвращается раскрытым 57,05–58,0 ----
    const flip = ease.inOutCubic((t - 0.95) / 0.6);
    const reopen = t >= 57 ? 0 : flip; // на шве книга уже раскрыта
    const s = Math.cos(Math.PI * reopen);
    tr(rightHalf, `translate(${CX} ${-36 * Math.sin(Math.PI * reopen)}) scale(${s} 1) translate(${-CX} 0)`);
    op(rightFront, s > 0 ? 1 : 0);
    op(rightBack, s > 0 ? 0 : 1);
    const away = ease.inCubic((t - 1.7) / 1.0);
    const back = t >= 57.05 ? 1 - ease.outCubic((t - 57.05) / 0.95) : 0;
    const dy = t >= 57.05 ? 920 * back : 920 * away;
    const dx = t >= 57.05 ? 0 : 210 * ease.inOutSine((t - 1.55) / 0.55);
    const rot = t >= 57.05 ? 4 * back : -4 * away;
    tr(book, `translate(${dx} ${dy}) rotate(${rot} ${CX} ${BY + BH / 2})`);
    op(book, t > 2.8 && t < 57.0 ? 0 : 1);

    // ---- точки шагов ----
    const dotsO = win(t, 3.1, 3.6, 50.0, 50.6);
    const step = t < 12 ? 0 : t < 21 ? 1 : t < 30 ? 2 : t < 40 ? 3 : 4;
    const starts = [3, 12, 21, 30, 40];
    dots.forEach((d, i) => {
      const act = i === step ? ease.outCubic((t - starts[i]) / 0.4) : i < step ? 1 : 0;
      const doneC = i < step || (i === step && act > 0.5);
      set(d, { r: 14 + 6 * (i === step ? act : 0), fill: doneC ? C.primary : C.soft });
      op(d, dotsO);
    });

    // ---- тексты ----
    prompts.forEach((p, i) => {
      const st = promptState(p, t);
      const vis = st.k > 0 && st.out < 1;
      if (!vis) return op(p.n, 0);
      op(p.n, 1 - ease.inOutSine(st.out));
      R.wordsIn(p.n, clamp(st.k), { rise: 30, spread: 0.5 });
      let y = -22 * ease.inOutSine(st.out);
      if (i === 1) y += -14 * (L - 0.25); // слова «плеч» поднимаются и опускаются с Тимкой
      if (i === 3) y += 10 * win(t, 23.0, 23.25, 23.25, 24.2, ease.outCubic);
      p.n.style.transform = `translateY(${y}px)`;
      if (i === 2) p.n.style.letterSpacing = `${-0.01 + 0.07 * ease.inOutSine((t - 14.4) / 2.0)}em`;
    });
    R.place(dizzy, { o: win(t, 30.8, 31.4, 41.4, 42.0), y: 8 * (1 - win(t, 30.8, 31.4, 99, 100, ease.outCubic)) });
    // знак и «Сохраните»
    const endO = win(t, 53.0, 53.8, 56.7, 57.05);
    mark.at(CX, 1330, 170 * (0.94 + 0.06 * ease.outCubic((t - 53.0) / 0.8)), endO);
    if (t > 53.5 && t < 57.05) {
      op(save, 1 - ease.inOutSine((t - 56.7) / 0.35));
      R.wordsIn(save, clamp((t - 53.6) / 0.9), { rise: 22, spread: 0.45 });
    } else op(save, 0);
  };

  R.ready().then(() => {
    window.READY = true;
  });
})();
