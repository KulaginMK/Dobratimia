"""Звук «Минуты тишины»: эмбиент ре мажор, всё синтезировано кодом.
python3 reels/r1/audio.py out/audio.wav [длительность]"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "engine"))
import numpy as np
import synth as s
from synth import note as N

D = 58.0
out = sys.argv[1]
length = float(sys.argv[2]) if len(sys.argv) > 2 else D
rng = np.random.default_rng(11)

b = s.buf(D + 8)  # с запасом под хвосты: потом они переносятся в начало

# ---- пэды: аккорд меняется вместе с подсказкой ----
chords = [
    (2.2, 12.8, ["G2", "D3", "F#3", "B3", "D4"]),
    (11.2, 21.8, ["B2", "F#3", "A3", "D4"]),
    (20.2, 30.8, ["E2", "B2", "G3", "D4", "F#4"]),
    (29.2, 40.8, ["G2", "D3", "A3", "B3", "F#4"]),
    (39.2, 50.8, ["F#2", "A3", "D4", "E4"]),
    (49.6, 61.0, ["D2", "A2", "F#3", "C#4", "E4", "A4"]),
]
for a, z, ch in chords:
    sig = s.pad([N(x) for x in ch], z - a, attack=2.0, release=2.4, bright=1400, level=0.08)
    s.mix(b, sig, a, pan=0)
# низкий гул под всем — тепло
drone = s.sine_pad([N("D2")], D + 3, attack=0.01, release=3, level=0.05)
s.mix(b, drone, 0)

# ---- мотивы калимбы на каждую подсказку ----
motifs = [
    (3.0, ["D5", "B4", "G4"]),
    (12.0, ["F#5", "D5", "B4"]),
    (21.0, ["E4", "G4", "B4"]),
    (30.0, ["B4", "D5", "G5"]),
    (40.0, ["A4", "D5", "F#5"]),
    (50.4, ["F#5", "A5", "D6"]),
    (57.3, ["A4", "D5"]),
]
for t0, notes in motifs:
    for i, x in enumerate(notes):
        s.mix(b, s.pluck(N(x), 2.8, bright=0.6, level=0.16), t0 + i * 0.19, pan=(-0.3 + 0.3 * i))

# ---- редкие ноты внутри сцен (фетровое фортепиано) ----
for a, z, ch in chords:
    t = a + 2.6
    while t < z - 2.5:
        x = ch[rng.integers(1, len(ch))]
        f = N(x) * 2
        s.mix(b, s.felt(f, 3.0, level=0.05), t, pan=float(rng.uniform(-0.5, 0.5)))
        t += float(rng.uniform(2.2, 3.4))

# ---- конспект: захлопнулся и уехал; на шве — вернулся ----
s.mix(b, s.thump(110, 0.4, level=0.32), 1.53)
s.mix(b, s.whoosh(1.0, 250, 1800, level=0.06), 1.65, pan=0.1)
s.mix(b, s.whoosh(0.9, 1400, 300, level=0.05), 57.05, pan=-0.1)

# ---- «плечи» в B: вдох и выдох ----
for a, dur, kind in [(3.3, 1.6, "in"), (4.9, 2.4, "out"), (8.0, 1.5, "in"), (9.5, 2.1, "out")]:
    s.mix(b, s.breath(dur, kind, level=0.055), a)
# челюсть отпустили: мягкая низкая нота
s.mix(b, s.felt(N("D3"), 3.5, level=0.12), 14.45)

# ---- земля: касание ----
s.mix(b, s.thump(70, 0.5, level=0.30), 23.0)
s.mix(b, s.thump(65, 0.5, level=0.18), 26.4)

# ---- три медленных выдоха ----
for a, dur, kind in [(31.0, 1.2, "in"), (32.2, 2.2, "out"), (34.4, 1.2, "in"), (35.6, 2.2, "out"), (37.8, 1.2, "in"), (39.0, 2.2, "out")]:
    s.mix(b, s.breath(dur, kind, level=0.10 if kind == "out" else 0.075), a)

# ---- искорки ----
for i, t0 in enumerate([47.6, 47.95, 48.3]):
    s.mix(b, s.sparkle(2350 + 330 * i, 0.7, level=0.035), t0, pan=[0.4, -0.4, 0.2][i])

# ---- финал: колокольчик со знаком ----
s.mix(b, s.bell(N("A5"), 4.0, level=0.09), 53.0)
s.mix(b, s.bell(N("D6"), 4.0, level=0.06), 53.25, pan=0.3)

b = s.reverb(b, seconds=2.8, wet=0.3)
b = s.loop_wrap(b, D)  # хвост за 58,0 с — в начало: петля без шва
# длина звука = длине видео (кадр 58,0 включён: 3481 кадр)
n = int(round(length * s.SR))
if n > b.shape[1]:
    b = np.concatenate([b, b[:, : n - b.shape[1]]], axis=1)  # продолжение петли
b = b[:, :n]
b = s.master_lufs(b, target=-17.0, ceiling_db=-1.5)
s.write(out, b)
