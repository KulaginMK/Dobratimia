// Общая библиотека роликов Добратимии: время, цвет, сцена, текст, Тимка.
// Всё вычисляется из времени t (секунды): renderAt(t) можно вызывать в любом порядке.
(function () {
  'use strict';
  const NS = 'http://www.w3.org/2000/svg';
  const W = 1080;
  const H = 1920;

  // Палитра бренда (бриф): только эти цвета для фона, текста и графики.
  const C = {
    bg: '#FBF5EE',
    text: '#2C1F1A',
    primary: '#B4532F',
    soft: '#F8DCCD',
    onSoft: '#6B2A12',
    choco: '#6B3A2A',
    white: '#FFFFFF',
    honey: '#E8B04A',
    growth: '#6E8A4E',
    growthSoft: '#E3EAD6',
  };

  // ---------- математика и кривые ----------
  const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
  const lerp = (a, b, k) => a + (b - a) * k;
  const seg = (t, a, b) => clamp((t - a) / (b - a));
  const ease = {
    linear: (x) => x,
    inOutSine: (x) => 0.5 - 0.5 * Math.cos(Math.PI * clamp(x)),
    outCubic: (x) => 1 - Math.pow(1 - clamp(x), 3),
    inCubic: (x) => Math.pow(clamp(x), 3),
    inOutCubic: (x) => {
      x = clamp(x);
      return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
    },
    outQuint: (x) => 1 - Math.pow(1 - clamp(x), 5),
    inOutQuint: (x) => {
      x = clamp(x);
      return x < 0.5 ? 16 * x ** 5 : 1 - Math.pow(-2 * x + 2, 5) / 2;
    },
  };
  /** Окно появления/исчезания: 0 до a, 1 между b и c, 0 после d. */
  function win(t, a, b, c, d, e = ease.inOutSine) {
    if (t <= a || t >= d) return 0;
    if (t < b) return e((t - a) / (b - a));
    if (t <= c) return 1;
    return 1 - e((t - c) / (d - c));
  }
  /** Ключи [[время, значение], ...] с кривой между ними. */
  function keys(t, list, e = ease.inOutSine) {
    if (t <= list[0][0]) return list[0][1];
    for (let i = 1; i < list.length; i++) {
      const [t1, v1] = list[i];
      const [t0, v0] = list[i - 1];
      if (t <= t1) return lerp(v0, v1, e((t - t0) / (t1 - t0)));
    }
    return list[list.length - 1][1];
  }
  /** Плавный шум для дрейфа камеры: сумма синусов, детерминирован. */
  const drift = (t, seed = 0) =>
    0.6 * Math.sin(t * 0.37 + seed * 1.7) + 0.3 * Math.sin(t * 0.71 + seed * 2.9) + 0.1 * Math.sin(t * 1.33 + seed);

  // ---------- цвет ----------
  const hex = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  const toHex = (rgb) => '#' + rgb.map((v) => Math.round(clamp(v, 0, 255)).toString(16).padStart(2, '0')).join('');
  const mix = (a, b, k) => {
    const x = hex(a);
    const y = hex(b);
    return toHex(x.map((v, i) => lerp(v, y[i], clamp(k))));
  };

  // ---------- DOM ----------
  function svg(tag, attrs = {}, parent) {
    const n = document.createElementNS(NS, tag);
    for (const k in attrs) n.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(n);
    return n;
  }
  function div(attrs = {}, parent) {
    const n = document.createElement('div');
    if (attrs.class) n.className = attrs.class;
    if (attrs.style) Object.assign(n.style, attrs.style);
    if (attrs.html !== undefined) n.innerHTML = attrs.html;
    if (parent) parent.appendChild(n);
    return n;
  }
  const set = (n, attrs) => {
    for (const k in attrs) n.setAttribute(k, attrs[k]);
  };
  const tr = (n, s) => n.setAttribute('transform', s);
  const op = (n, v) => {
    const o = clamp(v);
    n.style.opacity = o;
    n.style.visibility = o < 0.002 ? 'hidden' : 'visible';
  };

  /** Неразрывные пробелы после коротких слов и перед тире — без «висячих» предлогов. */
  function typo(s) {
    const NB = '\u00A0';
    const short = /(^|[ («\n\u00A0])(в|во|к|ко|с|со|и|а|но|на|по|у|о|об|от|до|за|из|не|ни|же|бы|ли|что|как|для|при|без|над|под|вы|вас|вам|это|уже|все|всё) /gi;
    return s
      .replace(short, '$1$2' + NB)
      .replace(/(^|[ («\n\u00A0])(в|во|к|ко|с|со|и|а|но|на|по|у|о|об|от|до|за|из|не|ни|же|бы|ли|что|как|для|при|без|над|под|вы|вас|вам|это|уже|все|всё) /gi, '$1$2' + NB)
      .replace(/ —/g, NB + '—')
      .replace(/(\d) /g, '$1' + NB);
  }

  // ---------- сцена ----------
  /** Корень кадра 1080×1920: svg-мир со слоями и html-слой текста поверх. */
  function stage(bg = C.bg) {
    document.body.style.cssText = `margin:0;width:${W}px;height:${H}px;overflow:hidden;background:${bg}`;
    const root = div({ style: { position: 'absolute', left: 0, top: 0, width: W + 'px', height: H + 'px', overflow: 'hidden', background: bg } }, document.body);
    const s = svg('svg', { width: W, height: H, viewBox: `0 0 ${W} ${H}` }, root);
    s.style.position = 'absolute';
    const defs = svg('defs', {}, s);
    const bgRect = svg('rect', { x: -200, y: -200, width: W + 400, height: H + 400, fill: bg }, s);
    const world = svg('g', {}, s);
    const text = div({ style: { position: 'absolute', left: 0, top: 0, width: W + 'px', height: H + 'px' } }, root);
    return { root, svg: s, defs, bgRect, world, text };
  }

  /** Камера: точка интереса (cx, cy), масштаб z, поворот r°, сдвиг (x, y). Слой с глубиной depth (1 — герой). */
  function camera(cam, depth = 1) {
    const z = 1 + (cam.z - 1) * depth;
    const x = (cam.x || 0) * depth;
    const y = (cam.y || 0) * depth;
    const r = (cam.r || 0) * depth;
    const cx = cam.cx ?? W / 2;
    const cy = cam.cy ?? H / 2;
    return `translate(${W / 2 + x} ${H / 2 + y}) rotate(${r}) scale(${z}) translate(${-cx} ${-cy})`;
  }

  /** Текстовый блок: абсолютный div по центру с шириной w; y — верх блока. */
  function textBlock(parent, { text, y, w = 880, x = (W - w) / 2, font = 'display', size = 72, line, color = C.text, weight, align = 'center', words = false, balance = true }) {
    const fam = font === 'display' ? "'Nunito'" : "'Golos Text'";
    const n = div(
      {
        style: {
          position: 'absolute',
          left: x + 'px',
          top: y + 'px',
          width: w + 'px',
          fontFamily: fam,
          fontWeight: weight ?? (font === 'display' ? 900 : 400),
          fontSize: size + 'px',
          lineHeight: (line ?? Math.round(size * 1.18)) + 'px',
          color,
          textAlign: align,
          textWrap: balance ? 'balance' : 'wrap',
          letterSpacing: font === 'display' ? '-0.01em' : '0',
          transformOrigin: '50% 50%',
        },
      },
      parent,
    );
    n.words = [];
    if (words) {
      // делим только по обычным пробелам: неразрывные (после предлогов) остаются внутри слова
      const parts = typo(text).split(/([ \t]+|\n)/);
      for (const p of parts) {
        if (p === '\n') {
          n.appendChild(document.createElement('br'));
        } else if (/^[ \t]+$/.test(p)) {
          n.appendChild(document.createTextNode(' '));
        } else if (p) {
          const s = document.createElement('span');
          s.textContent = p;
          s.style.display = 'inline-block';
          n.appendChild(s);
          n.words.push(s);
        }
      }
    } else {
      n.style.whiteSpace = 'pre-line';
      n.textContent = typo(text);
    }
    return n;
  }
  /** Слова появляются по очереди: k 0…1 — общий ход, spread — доля на «волну». */
  function wordsIn(n, k, { rise = 28, spread = 0.55, blur = 0 } = {}) {
    const m = n.words.length;
    n.words.forEach((s, i) => {
      const a = m > 1 ? (i / (m - 1)) * spread : 0;
      const q = ease.outCubic(clamp((k - a) / (1 - spread)));
      s.style.opacity = q;
      s.style.transform = `translateY(${(1 - q) * rise}px)`;
      s.style.filter = blur ? `blur(${(1 - q) * blur}px)` : '';
    });
  }
  function place(n, { o = 1, x = 0, y = 0, s = 1, r = 0, blur = 0 }) {
    op(n, o);
    n.style.transform = `translate(${x}px, ${y}px) rotate(${r}deg) scale(${s})`;
    n.style.filter = blur > 0.05 ? `blur(${blur}px)` : '';
  }

  // ---------- SVG-ресурсы ----------
  /** Вставляет SVG из ASSETS: возвращает группу и части по id (каждая обёрнута в <g> для движения). */
  function importSvg(name, parent) {
    const doc = new DOMParser().parseFromString(window.ASSETS[name], 'image/svg+xml');
    const g = svg('g', {}, parent);
    for (const c of Array.from(doc.documentElement.childNodes)) g.appendChild(document.importNode(c, true));
    const parts = {};
    for (const el of Array.from(g.querySelectorAll('[id]'))) {
      const id = el.getAttribute('id');
      el.removeAttribute('id');
      const wrap = svg('g', {});
      el.parentNode.insertBefore(wrap, el);
      wrap.appendChild(el);
      parts[id] = wrap;
    }
    // id внутри defs логотипа (градиенты) должны остаться уникальными: переименуем
    return { g, parts, viewBox: doc.documentElement.getAttribute('viewBox') };
  }
  let logoCount = 0;
  /** Знак: name — logo-mark или logo-mark-white. Размер — высота в px, (x, y) — центр. */
  function logo(parent, name = 'logo-mark') {
    let src = window.ASSETS[name];
    const tag = 'lg' + logoCount++;
    src = src.replace(/id="(\w+)"/g, `id="${tag}$1"`).replace(/url\(#(\w+)\)/g, `url(#${tag}$1)`);
    const doc = new DOMParser().parseFromString(src, 'image/svg+xml');
    const outer = svg('g', {}, parent);
    const g = svg('g', {}, outer);
    for (const c of Array.from(doc.documentElement.childNodes)) g.appendChild(document.importNode(c, true));
    return {
      g: outer,
      at(x, y, size, o = 1) {
        const k = size / 64;
        tr(g, `translate(${x - 32 * k} ${y - 32 * k}) scale(${k})`);
        op(outer, o);
      },
    };
  }

  // ---------- Тимка ----------
  // Рисунок 120×120, viewBox «0 -6 120 120». (x, y) — центр рисунка, size — сторона в px.
  const VIEW_TOP = -6;
  const rad = 180 / Math.PI;
  function placeFigure(g, x, y, size, extra = '') {
    const k = size / 120;
    tr(g, `translate(${x - 60 * k} ${y - 60 * k}) scale(${k}) translate(0 ${-VIEW_TOP}) ${extra}`);
  }
  const about = (x, y, s) => `translate(${x} ${y}) ${s} translate(${-x} ${-y})`;

  // Дыхание — «Тимка · дыхание · спецификация» 1.0 (как в expo-app/src/components/brand/Timka.tsx).
  const B = {
    FACE_BLEND: 0.28,
    BODY_EMPTY_X: 0.97,
    BODY_GROW_X: 0.06,
    BODY_PUFF_X: 0.025,
    BODY_EMPTY_Y: 0.94,
    BODY_GROW_Y: 0.1,
    BODY_HEIGHT: 74,
    STEM_HEIGHT: 21,
    STEM_SWAY: 9,
    STEM_SPEED: 3.2,
    LEAF_TILT: 0.18,
    LEAF_IDLE: 0.03,
    LEAF_IDLE_SPEED: 1.7,
    LEAF_FLUTTER: 0.18,
    LEAF_FLUTTER_SPEED: 11,
    BLINK_EVERY: 3.6,
    BLINK: 0.13,
    BLINK_CLOSED: 0.08,
    MOUTH_MIN_X: 1.6,
    MOUTH_GROW_X: 2.4,
    MOUTH_MIN_Y: 2,
    MOUTH_GROW_Y: 3.2,
    MOUTH_SPEED: 6,
    PUFF_SPEED: 0.8,
    PUFF_DX: 16,
    PUFF_DY: 22,
    PUFF_R_MIN: 2,
    PUFF_R_GROW: 5,
    PUFF_R: 4.5,
    PUFF_ALPHA: 0.8,
    EFFECT_AFTER: 0.4,
    SPARK_SPEED: 5,
    SPARK_SIZE: 7,
    SPARK_MIN: 2,
    SPARK_DIM: 0.4,
  };
  const FACES = ['in', 'hold', 'out', 'rest', 'look'];

  /** Дорожка лиц: [[время, лицо], ...]. Новое лицо смешивается с прежним за 0,28 с, ease in-out. */
  function faceAt(track, t) {
    let i = 0;
    while (i + 1 < track.length && track[i + 1][0] <= t) i++;
    const [t0, to] = track[i];
    const from = i > 0 ? track[i - 1][1] : to;
    const shift = t < t0 ? 1 : ease.inOutSine((t - t0) / B.FACE_BLEND);
    return { kind: to, from, shift };
  }

  /** Тимка в дыхательном круге. extraFaces: {имя: svg-разметка лица в координатах рисунка}. */
  function breathingTimka(parent, extraFaces = {}) {
    const fig = importSvg('timka-breathing', parent);
    const p = fig.parts;
    const body = p.body.firstChild; // <g> тела с лицами внутри
    const faceGroups = {};
    for (const f of FACES) faceGroups[f] = p['face-' + f];
    for (const name in extraFaces) {
      const g = svg('g', {}, body);
      const doc = new DOMParser().parseFromString(`<svg xmlns="${NS}">${extraFaces[name]}</svg>`, 'image/svg+xml');
      for (const c of Array.from(doc.documentElement.childNodes)) g.appendChild(document.importNode(c, true));
      faceGroups[name] = g;
    }
    // Слой позади тела (рука на животе и т. п.)
    const behind = svg('g', {});
    p.body.parentNode.insertBefore(behind, p.body);
    return {
      g: fig.g,
      parts: p,
      faces: faceGroups,
      behind,
      /**
       * n: { t, fill 0…1, face: {kind, from, shift}, eyeDx, eyeDy, x, y, size, tilt, lift }
       * fill — наполненность (уже сглаженная); тело растёт от нижнего края.
       */
      update(n) {
        const t = n.t;
        const fill = clamp(n.fill);
        const weight = (f) => (n.face.kind === f ? n.face.shift : 0) + (n.face.from === f ? 1 - n.face.shift : 0);
        const wOut = weight('out');
        const tip = B.STEM_SWAY * Math.sin(t * B.STEM_SPEED) * wOut * (n.swayK ?? 1);
        const flutter = B.LEAF_FLUTTER * Math.sin(t * B.LEAF_FLUTTER_SPEED) * wOut * (n.swayK ?? 1);
        const sy = B.BODY_EMPTY_Y + B.BODY_GROW_Y * fill + (n.extraY || 0);
        const sx = B.BODY_EMPTY_X + B.BODY_GROW_X * fill + B.BODY_PUFF_X * weight('hold') + (n.extraX || 0);
        placeFigure(fig.g, n.x, n.y, n.size, n.rot ? about(60, 102, `rotate(${n.rot})`) : '');
        tr(p.sprout, `translate(0 ${-B.BODY_HEIGHT * (sy - 1)})`);
        tr(p.stem, `rotate(${Math.asin(clamp(tip / B.STEM_HEIGHT, -1, 1)) * rad} 60 31)`);
        tr(p.leaves, `translate(${tip} ${B.STEM_HEIGHT - Math.sqrt(B.STEM_HEIGHT ** 2 - tip * tip)})`);
        const tilt = B.LEAF_TILT * (1 - 2 * fill) + (n.leafLift || 0);
        const idle = B.LEAF_IDLE * (n.idleK ?? 1) * Math.sin(t * (n.idleSpeed ?? B.LEAF_IDLE_SPEED) + (n.idlePhase || 0));
        tr(p['leaf-left'], `rotate(${(-1 * (tilt - flutter) + idle) * rad} 59.5 18)`);
        tr(p['leaf-right'], `rotate(${(1 * (tilt - flutter) + idle) * rad} 60.5 14)`);
        tr(p.body, about(60, 102, `scale(${sx} ${sy})`));
        for (const f in faceGroups) op(faceGroups[f], weight(f));
        const every = n.blinkEvery ?? B.BLINK_EVERY;
        const blink = n.noBlink ? 1 : ((((t + (n.blinkPhase || 0)) % every) + every) % every) > every - B.BLINK ? B.BLINK_CLOSED : 1;
        const ex = n.eyeDx || 0;
        const ey = n.eyeDy || 0;
        tr(p['eyes-in'], `translate(${ex} ${ey}) ` + about(60, 64, `scale(1 ${blink})`));
        tr(p['eyes-look'], `translate(${ex} ${ey}) ` + about(60, 64, `scale(1 ${blink})`));
        const mouth = (open) =>
          about(60, 79, `scale(${(B.MOUTH_MIN_X + B.MOUTH_GROW_X * open) / (B.MOUTH_MIN_X + B.MOUTH_GROW_X)} ${(B.MOUTH_MIN_Y + B.MOUTH_GROW_Y * open) / (B.MOUTH_MIN_Y + B.MOUTH_GROW_Y)})`);
        tr(p['mouth-in'], mouth(0.65 + 0.35 * fill));
        tr(p['mouth-out'], mouth(0.75 + 0.25 * Math.sin(t * B.MOUTH_SPEED)));
        for (let i = 0; i < 3; i++) {
          const run = (((t * B.PUFF_SPEED + i / 3) % 1) + 1) % 1;
          const q = n.face.kind === 'in' ? 1 - run : run;
          const shown = (n.face.kind === 'in' || n.face.kind === 'out') && n.face.shift >= B.EFFECT_AFTER && !n.noPuffs;
          const puff = p['puff-' + i];
          op(puff, shown ? (1 - q) * B.PUFF_ALPHA : 0);
          const s = (B.PUFF_R_MIN + B.PUFF_R_GROW * q) / B.PUFF_R;
          tr(puff, `translate(${B.PUFF_DX * (q - 0.5)} ${B.PUFF_DY * (q - 0.5) + (n.puffShift ?? -7)}) ` + about(68, 103, `scale(${s})`));
        }
        const tw = 0.5 + 0.5 * Math.sin(t * B.SPARK_SPEED);
        const sparkOn = n.face.kind === 'hold' && n.face.shift >= B.EFFECT_AFTER;
        op(p.spark, sparkOn ? B.SPARK_DIM + (1 - B.SPARK_DIM) * tw : 0);
        tr(p.spark, about(98, 38, `scale(${(B.SPARK_MIN + (B.SPARK_SIZE - B.SPARK_MIN) * tw) / B.SPARK_SIZE})`));
        return { sx, sy };
      },
    };
  }

  /** Статичная поза с живыми мелочами: покачивание ростка, моргание, взмах рукой. */
  function poseTimka(parent, name) {
    const fig = importSvg('timka-' + name, parent);
    return {
      g: fig.g,
      parts: fig.parts,
      /** n: { t, x, y, size, sway°, wave°, blink 0…1 (1 — открыты), lift (растяжение тела), rot° } */
      update(n) {
        placeFigure(fig.g, n.x, n.y, n.size, (n.rot ? about(60, 104, `rotate(${n.rot})`) : '') + (n.squash ? ' ' + about(60, 104, `scale(${1 + n.squash * 0.6} ${1 - n.squash})`) : ''));
        const p = fig.parts;
        if (p.sprout) tr(p.sprout, about(60, 30, `rotate(${n.sway ?? 3 * Math.sin((n.t * 2 * Math.PI) / 3)})`));
        if (p.hand) tr(p.hand, about(98, 68, `rotate(${n.wave || 0})`));
        if (p.eyes) tr(p.eyes, about(60, 64, `scale(1 ${n.blink ?? 1})`));
        if (p.body && n.lift) tr(p.body, about(60, 102, `scale(1 ${1 + n.lift})`));
        if (p.zzz) {
          const z = n.zzz ?? 0.5 + 0.5 * Math.sin((n.t * 2 * Math.PI) / 4);
          tr(p.zzz, `translate(0 ${-3 * z})`);
          op(p.zzz, (1 - 0.5 * z) * (n.zzzO ?? 1));
        }
      },
    };
  }

  /** Взмах как в приложении: 2 раза по 240 мс туда и обратно, 20°. start — начало, возвращает угол. */
  function waveAngle(t, start, times = 2, swing = 0.24, deg = 20) {
    const x = t - start;
    if (x < 0 || x > times * 2 * swing) return 0;
    const ph = (x % (2 * swing)) / swing;
    return ph < 1 ? deg * ease.outCubic(ph) : deg * (1 - ease.outCubic(ph - 1));
  }
  /** Моргание раз в every с: 160 мс, глаза сжимаются до 0,1. */
  function blinkAt(t, every = 4.3, phase = 0) {
    const x = (((t + phase) % every) + every) % every;
    if (x > 0.16) return 1;
    return 1 - 0.9 * Math.sin((Math.PI * x) / 0.16);
  }

  // ---------- готовность ----------
  async function ready() {
    const faces = ["900 72px 'Nunito'", "400 40px 'Golos Text'", "600 40px 'Golos Text'"];
    await Promise.all(faces.map((f) => document.fonts.load(f, 'АБВабв Ёё 0123456789 POV —')));
    await document.fonts.ready;
  }

  window.R = { W, H, C, clamp, lerp, seg, ease, win, keys, drift, mix, hex, svg, div, set, tr, op, typo, stage, camera, textBlock, wordsIn, place, importSvg, logo, breathingTimka, poseTimka, faceAt, waveAngle, blinkAt, placeFigure, about, ready, B };
})();

// ---------- статичные макеты: обложка и сторис ----------
(function () {
  const { C, svg, tr } = window.R;
  /** Горизонтальный логотип: знак + «Добратимия» (Nunito 900, кегль 0,58 высоты знака, зазор 8 px). */
  window.R.wordmark = function (S, { y, h = 76, color = C.text, mark = 'logo-mark', cx = 540 }) {
    const fs = Math.round(h * 0.58);
    const probe = document.createElement('span');
    probe.style.cssText = `font:900 ${fs}px 'Nunito';position:absolute;visibility:hidden;white-space:nowrap`;
    probe.textContent = 'Добратимия';
    document.body.appendChild(probe);
    const tw = probe.getBoundingClientRect().width;
    probe.remove();
    const total = h + 8 + tw;
    const x0 = cx - total / 2;
    const m = window.R.logo(S.world, mark);
    m.at(x0 + h / 2, y + h / 2, h);
    window.R.div({ style: { position: 'absolute', left: x0 + h + 8 + 'px', top: y + (h - fs * 1.2) / 2 + 'px', font: `900 ${fs}px 'Nunito'`, lineHeight: fs * 1.2 + 'px', color, whiteSpace: 'nowrap' }, html: 'Добратимия' }, S.text);
  };
  /** Плашка-метка серии: мягкая терракота, текст #6B2A12. */
  window.R.chip = function (S, { text, y, size = 40, bg = C.soft, color = C.onSoft }) {
    const d = window.R.div({ style: { position: 'absolute', left: '0', top: y + 'px', width: '1080px', textAlign: 'center' } }, S.text);
    window.R.div({ style: { display: 'inline-block', padding: `${Math.round(size * 0.32)}px ${Math.round(size * 0.8)}px`, borderRadius: '999px', background: bg, color, font: `600 ${size}px 'Golos Text'`, lineHeight: size * 1.25 + 'px' }, html: text }, d);
    return d;
  };
})();
