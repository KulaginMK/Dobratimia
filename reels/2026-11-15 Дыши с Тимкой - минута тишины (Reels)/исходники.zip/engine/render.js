// Покадровый рендер сцены в видео без потерь.
// node engine/render.js <scene.html> <out.mkv> --frames N [--fps 60] [--workers 3] [--sub 1] [--shutter 0.5] [--from 0 --to N]
// Кадр i снимается во время t = i / fps. При --sub S кадр — среднее S подкадров внутри выдержки
// (shutter — доля кадра, 0.5 = 180°): это настоящий motion blur по движению.
// Без сервера: сцена открывается как файл. Каждый работник — свой Chromium и свой ffmpeg.
const { chromium } = require('playwright');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const { once } = require('events');

const args = process.argv.slice(2);
const scene = path.resolve(args[0]);
const out = path.resolve(args[1]);
const opt = (name, def) => {
  const i = args.indexOf('--' + name);
  return i >= 0 ? Number(args[i + 1]) : def;
};
const fps = opt('fps', 60);
const frames = opt('frames', 0);
const workers = opt('workers', 3);
const sub = opt('sub', 1);
const shutter = opt('shutter', 0.5);
const from = opt('from', 0);
const to = opt('to', frames);
const query = args.includes('--query') ? args[args.indexOf('--query') + 1] : '';
if (!frames) throw new Error('--frames N обязателен');

async function worker(w, start, end, seg) {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1080, height: 1920 }, deviceScaleFactor: 1 });
  page.on('console', (m) => m.type() === 'error' && console.error('[scene]', m.text()));
  page.on('pageerror', (e) => console.error('[scene error]', e.message));
  await page.goto('file://' + scene + (query ? '?' + query : ''));
  await page.waitForFunction(() => window.READY === true, null, { timeout: 30000 });
  const cdp = await page.context().newCDPSession(page);
  // Прогрев: первый снимок свежей страницы растрирует текст иначе, чем последующие. Снимаем и выбрасываем.
  for (const x of [start / fps, (start + end) / 2 / fps, start / fps]) {
    await page.evaluate((v) => window.renderAt(v), x);
    await cdp.send('Page.captureScreenshot', { format: 'png', optimizeForSpeed: true });
  }
  const vf = sub > 1 ? ['-vf', `tmix=frames=${sub},select='eq(mod(n\\,${sub})\\,${sub - 1})',setpts=N/${fps}/TB`] : [];
  const ff = spawn('ffmpeg', ['-y', '-v', 'error', '-f', 'image2pipe', '-framerate', String(fps * sub), '-c:v', 'png', '-i', '-', ...vf, '-r', String(fps), '-c:v', 'libx264rgb', '-qp', '0', '-preset', 'ultrafast', seg], { stdio: ['pipe', 'inherit', 'inherit'] });
  const t0 = Date.now();
  for (let i = start; i < end; i++) {
    for (let k = 0; k < sub; k++) {
      const t = i / fps + (sub > 1 ? ((k + 0.5) / sub - 0.5) * (shutter / fps) : 0);
      await page.evaluate((x) => window.renderAt(x), t);
      const { data } = await cdp.send('Page.captureScreenshot', { format: 'png', optimizeForSpeed: true });
      if (!ff.stdin.write(Buffer.from(data, 'base64'))) await once(ff.stdin, 'drain');
    }
    if ((i - start) % 300 === 0) console.log(`работник ${w}: кадр ${i} (${((Date.now() - t0) / 1000).toFixed(0)} с)`);
  }
  ff.stdin.end();
  const [code] = await once(ff, 'exit');
  await browser.close();
  if (code !== 0) throw new Error('ffmpeg ' + code);
}

(async () => {
  const total = to - from;
  const per = Math.ceil(total / workers);
  const tmp = out + '.parts';
  fs.mkdirSync(tmp, { recursive: true });
  const jobs = [];
  const segs = [];
  for (let w = 0; w < workers; w++) {
    const a = from + w * per;
    const b = Math.min(to, a + per);
    if (a >= b) break;
    const seg = path.join(tmp, `seg${w}.mkv`);
    segs.push(seg);
    jobs.push(worker(w, a, b, seg));
  }
  await Promise.all(jobs);
  fs.writeFileSync(path.join(tmp, 'list.txt'), segs.map((s) => `file '${s}'`).join('\n'));
  const ff = spawn('ffmpeg', ['-y', '-v', 'error', '-f', 'concat', '-safe', '0', '-i', path.join(tmp, 'list.txt'), '-c', 'copy', out], { stdio: 'inherit' });
  const [code] = await once(ff, 'exit');
  if (code !== 0) throw new Error('concat ' + code);
  fs.rmSync(tmp, { recursive: true });
  console.log('готово:', out, total, 'кадров');
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
