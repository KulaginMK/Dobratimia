// «Тимка — сколько вы спали» (по шаблону «Тимка — как вы сегодня»). 12,5 с, петля: кадр 12,5 совпадает с кадром 0. Серия «Тимка»: без голоса.
(function () {
  if (new URLSearchParams(location.search).get('still')) return;
  const { C, clamp, lerp, ease, win, keys, svg, tr, op, set, div } = R;
  const D = 12.5;
  const TAU = Math.PI * 2;
  const per = (k) => (TAU * k) / D;
  const S = R.camStage(C.bg);

  // дальний план
  const blobs = [
    [110, 420, 230, C.soft, 0.5],
    [1010, 1180, 170, C.growthSoft, 0.85],
    [80, 1640, 260, C.soft, 0.42],
    [990, 300, 120, C.growthSoft, 0.7],
  ].map(([x, y, r, c, o]) => ({ x, y, n: svg('circle', { cx: x, cy: y, r, fill: c, opacity: o }, S.far) }));

  // ---- Тимка: позы ----
  const TX = 540;
  const TY = 700;
  const TS = 520;
  const circle = svg('circle', { cx: TX, cy: TY, r: 0, fill: C.soft }, S.world);
  const mk = (name) => {
    const g = svg('g', {}, S.top);
    return { g, p: R.poseTimka(g, name, { noShadow: true }) };
  };
  const hello = mk('hello');
  const stretch = mk('stretch');
  const sleep = mk('sleep');
  const brG = svg('g', {}, S.top);
  const br = R.breathingTimka(brG);

  // пузырь комментария
  const bubble = div({ style: { position: 'absolute', left: '800px', top: '520px', width: '190px', height: '130px', borderRadius: '40px 40px 40px 10px', background: C.choco, color: C.white, display: 'flex', alignItems: 'center', justifyContent: 'center', font: "900 72px 'Nunito'" } }, S.text);
  const bubbleDigits = ['1', '2', '3'].map((d) => div({ style: { position: 'absolute', inset: '0', display: 'flex', alignItems: 'center', justifyContent: 'center' }, html: d }, bubble));
  const caret = div({ style: { position: 'absolute', left: '118px', top: '34px', width: '6px', height: '62px', borderRadius: '3px', background: C.white } }, bubble);

  // ---- строки ответов ----
  const ROWS = [
    { text: '1 · 7 часов и больше', at: 2.0 },
    { text: '2 · 5–6 часов', at: 3.5 },
    { text: '3 · меньше 5 часов', at: 5.0 },
  ].map((r, i) => {
    const n = div({ style: { position: 'absolute', left: '130px', top: 1000 + i * 150 + 'px', width: '820px', height: '128px', borderRadius: '64px', background: C.soft, color: C.onSoft, display: 'flex', alignItems: 'center', paddingLeft: '64px', boxSizing: 'border-box', font: "900 64px 'Nunito'", whiteSpace: 'nowrap' }, html: R.typo(r.text) }, S.text);
    return { ...r, n };
  });

  // ---- тексты ----
  const title = R.textBlock(S.text, { text: 'Сколько вы спали?', y: 330, w: 1000, size: 86, line: 100, color: C.text, words: true });
  const ask = R.textBlock(S.text, { text: 'Напишите цифру\nв комментариях', y: 1470, size: 66, line: 78, color: C.text, words: true });
  const if3 = R.textBlock(S.text, { text: 'Если 3: дыхание 4-7-8\nперед сном есть в профиле', y: 1470, size: 62, line: 76, color: C.text, words: true });

  // смена поз: в момент короткого сжатия (0,1 с вниз, 0,16 с обратно) поза меняется сразу — без двоения и без пружин
  const SWAPS = [2.0, 3.5, 5.0, 7.0, 10.0, 12.0];
  const POSE_AT = (t) => (t < 2.0 ? 'hello' : t < 3.5 ? 'stretch' : t < 5.0 ? 'hold' : t < 7.0 ? 'sleep' : t < 10.0 ? 'hello' : t < 12.0 ? 'hold' : 'hello');
  const squashAt = (t) => {
    let q = 0;
    for (const b of SWAPS) {
      if (t >= b - 0.1 && t < b) q = Math.max(q, ease.inCubic((t - (b - 0.1)) / 0.1));
      if (t >= b && t < b + 0.16) q = Math.max(q, 1 - ease.outCubic((t - b) / 0.16));
    }
    return q;
  };
  const placeG = (g, on, q) => {
    op(g, on ? 1 : 0);
    const by = TY + 48 * (TS / 120);
    tr(g, `translate(${TX} ${by}) scale(${1 + 0.08 * q} ${1 - 0.12 * q}) translate(${-TX} ${-by})`);
  };

  window.renderAt = function (tRaw) {
    const t = Math.round((((tRaw % D) + D) % D) * 1e6) / 1e6;
    // ---- камера: подаётся к каждой новой строке ----
    const push = (a) => 0.03 * win(t, a, a + 0.35, a + 0.6, a + 1.3, ease.inOutSine);
    const z = 1 + push(2.0) + push(3.5) + push(5.0) + 0.02 * win(t, 7.0, 7.5, 9.6, 10.0) + 0.025 * win(t, 10.0, 10.4, 11.6, 12.1);
    const cy = 960 + 40 * win(t, 2.0, 2.6, 6.6, 7.2) - 30 * win(t, 10.0, 10.4, 11.6, 12.1);
    R.camApply(S, { cx: 540, cy, z, r: 0.4 * Math.sin(per(1) * t), x: 6 * Math.sin(per(2) * t), y: 4 * Math.sin(per(1) * t + 1) });
    blobs.forEach((b, i) => set(b.n, { cy: b.y + 12 * Math.sin(per(1) * t + i * 1.7) }));

    // ---- позы ----
    const sway = 3 * Math.sin(per(4) * t);
    const nod = (a) => 0.07 * Math.sin(Math.PI * clamp((t - a) / 0.24));
    const pose = POSE_AT(t);
    const q = squashAt(t);
    placeG(hello.g, pose === 'hello', q);
    hello.p.update({ t, x: TX, y: TY, size: TS, sway, wave: R.waveAngle(t, 0.25) + R.waveAngle(t, 7.1, 1), blink: R.blinkAt(t, D / 3, 1.2), squash: nod(8.0) + nod(8.3) });
    placeG(stretch.g, pose === 'stretch', q);
    const lift = 0.06 * win(t, 2.0, 2.32, 3.0, 3.32, ease.outCubic);
    stretch.p.update({ t, x: TX, y: TY, size: TS, sway, lift });
    placeG(sleep.g, pose === 'sleep', q);
    sleep.p.update({ t, x: TX, y: TY + 10, size: TS * 1.05, sway: 0 });
    // «держусь» и минута дыхания — дыхательная фигура
    placeG(brG, pose === 'hold', q);
    let face;
    let fill;
    if (t < 8) {
      face = { kind: 'hold', from: 'hold', shift: 1 };
      fill = 1;
    } else {
      face = R.faceAt([[0, 'hold'], [10.15, 'in'], [11.0, 'out'], [11.85, 'rest']], t);
      fill = keys(t, [[10.15, 0.2], [11.0, 1], [11.85, 0]]);
    }
    br.update({ t, fill, face, x: TX, y: TY, size: TS * 0.95, blinkEvery: D / 4, idleSpeed: per(3) });
    // круг дыхания за Тимкой в D
    set(circle, { r: 230 * ease.inOutCubic(win(t, 10.0, 10.4, 11.7, 12.15, ease.linear)) * (0.92 + 0.08 * fill) });

    // ---- строки ----
    ROWS.forEach((r, i) => {
      const k = ease.outCubic((t - r.at) / 0.45);
      const out = ease.inOutCubic((t - (11.9 + i * 0.06)) / 0.4);
      R.place(r.n, { o: k * (1 - out), x: (1 - k) * 160, y: out * 40 });
      // строка «3» в D: шоколад и белый текст
      const hi = i === 2 ? win(t, 10.0, 10.3, 11.8, 12.1) : 0;
      r.n.style.background = R.mix(C.soft, C.choco, hi);
      r.n.style.color = R.mix(C.onSoft, C.white, hi);
      // на «3» в D остальные строки отступают
      if (i < 2) r.n.style.opacity = String(k * (1 - out) * (1 - 0.55 * win(t, 10.0, 10.3, 11.8, 12.1)));
    });

    // ---- пузырь комментария: 1 → 2 → 3 ----
    const bub = win(t, 7.15, 7.45, 9.7, 10.0, ease.outCubic);
    R.place(bubble, { o: bub, y: (1 - bub) * 30, s: 0.9 + 0.1 * bub });
    const dShown = t < 7.6 ? -1 : t < 8.3 ? 0 : t < 9.0 ? 1 : 2;
    bubbleDigits.forEach((d, i) => op(d, i === dShown ? ease.outCubic((t - [7.6, 8.3, 9.0][i]) / 0.12) : 0));
    op(caret, dShown < 0 && Math.floor(t * 3) % 2 === 0 ? 1 : 0);

    // ---- тексты ----
    op(title, 1);
    R.wordsIn(title, 1);
    if (t > 7.0 && t < 10.2) {
      op(ask, 1 - ease.inOutSine((t - 9.8) / 0.3));
      R.wordsIn(ask, clamp((t - 7.1) / 0.7), { spread: 0.45 });
    } else op(ask, 0);
    if (t > 10.0 && t < 12.3) {
      op(if3, 1 - ease.inOutSine((t - 11.9) / 0.35));
      R.wordsIn(if3, clamp((t - 10.05) / 0.7), { spread: 0.5 });
    } else op(if3, 0);
  };

  R.ready().then(() => (window.READY = true));
})();
