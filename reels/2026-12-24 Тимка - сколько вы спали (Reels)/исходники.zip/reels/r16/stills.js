// Обложка (центр 1080×1350 виден в сетке профиля) и кадр сторис для репоста с местом под стикер.
(function () {
  const kind = new URLSearchParams(location.search).get('still');
  if (!kind) return;
  const { C, svg, div } = R;
  const S = R.stage(C.bg);
  [[110, 420, 230, C.soft, 0.5], [1010, 1180, 170, C.growthSoft, 0.85], [80, 1640, 260, C.soft, 0.42], [990, 300, 120, C.growthSoft, 0.7]].forEach(([x, y, r, c, o]) => svg('circle', { cx: x, cy: y, r, fill: c, opacity: o }, S.world));
  const row = (y, text) => div({ style: { position: 'absolute', left: '150px', top: y + 'px', width: '780px', height: '116px', borderRadius: '58px', background: C.soft, color: C.onSoft, display: 'flex', alignItems: 'center', paddingLeft: '58px', boxSizing: 'border-box', font: "900 58px 'Nunito'", whiteSpace: 'nowrap' }, html: R.typo(text) }, S.text);
  if (kind === 'cover') {
    R.chip(S, { text: 'Тимка спрашивает', y: 320 });
    R.textBlock(S.text, { text: 'Сколько\nвы спали?', y: 420, size: 120, line: 132, w: 1000 });
    const p = R.poseTimka(S.world, 'hello', { noShadow: true });
    p.update({ t: 0, x: 540, y: 880, size: 380, sway: 0, wave: 10 });
    row(1100, '1 · 7 часов и больше');
    row(1236, '2 · 5–6 часов');
    row(1372, '3 · меньше 5 часов');
    R.textBlock(S.text, { text: 'Ответьте цифрой', y: 1520, size: 48, line: 60, font: 'text', weight: 600, color: C.primary });
  } else {
    R.wordmark(S, { y: 300, h: 76 });
    R.textBlock(S.text, { text: 'Сколько вы спали\nэтой ночью?', y: 440, size: 96, line: 108, w: 960 });
    const p = R.poseTimka(S.world, 'hello', { noShadow: true });
    p.update({ t: 0, x: 540, y: 800, size: 340, sway: 0, wave: 10 });
    R.textBlock(S.text, { text: '1 · 7 часов и больше,\n2 · 5–6 часов, 3 · меньше 5 часов', y: 1020, size: 50, line: 64, font: 'text', weight: 600, color: C.text });
    R.textBlock(S.text, { text: 'Ответьте в опросе ниже', y: 1180, size: 44, line: 56, font: 'text', weight: 600, color: C.primary });
  }
  window.renderAt = () => {};
  R.ready().then(() => (window.READY = true));
})();
