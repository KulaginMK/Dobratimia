"""Собирает SVG из assets/ в engine/assets.js, чтобы сцена открывалась без сервера."""
import json, pathlib, sys
root = pathlib.Path(__file__).resolve().parent.parent
svgs = {p.stem: p.read_text(encoding="utf-8") for p in sorted((root / "assets").glob("*.svg"))}
(root / "engine" / "assets.js").write_text("window.ASSETS = " + json.dumps(svgs, ensure_ascii=False) + ";\n", encoding="utf-8")
print("assets:", ", ".join(svgs))
