"""Проверка готового ролика: параметры, кадры по таймкодам, петля, громкость.
python3 engine/check.py out.mp4 --times 0,1.5,... [--loop] [--sheet sheet.png]"""
import json, subprocess, sys, pathlib
import numpy as np
from PIL import Image, ImageDraw

args = sys.argv[1:]
mp4 = args[0]
get = lambda n, d=None: args[args.index("--" + n) + 1] if "--" + n in args else d
times = [float(x) for x in get("times", "0").split(",")]
sheet = get("sheet", str(pathlib.Path(mp4).with_suffix("")) + "_sheet.png")
outdir = pathlib.Path(get("frames", str(pathlib.Path(mp4).parent / "frames")))
outdir.mkdir(parents=True, exist_ok=True)

info = json.loads(subprocess.check_output(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", mp4]))
v = next(s for s in info["streams"] if s["codec_type"] == "video")
a = next((s for s in info["streams"] if s["codec_type"] == "audio"), None)
nb = int(subprocess.check_output(["ffprobe", "-v", "error", "-count_frames", "-select_streams", "v:0", "-show_entries", "stream=nb_read_frames", "-of", "csv=p=0", mp4]).decode().strip())
print(f"видео: {v['codec_name']} {v.get('profile')} {v['width']}×{v['height']} {v['pix_fmt']} {v['r_frame_rate']} кадров {nb} цвет {v.get('color_space')}/{v.get('color_primaries')}/{v.get('color_transfer')}")
if a:
    print(f"звук: {a['codec_name']} {a['sample_rate']} Гц {a['channels']} кан. {int(a.get('bit_rate', 0)) // 1000} кбит/с, длительность {float(a['duration']):.3f} с")
print(f"контейнер: длительность {float(info['format']['duration']):.3f} с")
with open(mp4, "rb") as f:
    head = f.read(4096)
moov, mdat = head.find(b"moov"), head.find(b"mdat")
print("faststart:", "да (moov в начале)" if moov != -1 and (mdat == -1 or moov < mdat) else "НЕТ")

fps = eval(v["r_frame_rate"])

def frame(i):
    raw = subprocess.check_output(["ffmpeg", "-v", "error", "-i", mp4, "-vf", f"select=eq(n\\,{i})", "-vsync", "0", "-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"])
    return np.frombuffer(raw, np.uint8).reshape(v["height"], v["width"], 3)

ims = []
for t in times:
    i = min(nb - 1, int(round(t * fps)))
    f = frame(i)
    Image.fromarray(f).save(outdir / f"t{t:06.2f}.png")
    ims.append((t, Image.fromarray(f)))

if "--loop" in args:
    f0, f1 = frame(0).astype(int), frame(nb - 1).astype(int)
    d = np.abs(f0 - f1)
    print(f"петля: первый и последний кадр — средняя разница {d.mean():.3f}, максимум {d.max()} (0–255)")

# громкость готового файла
r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", mp4, "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
summ = r[r.rfind("Summary:"):]
for line in summ.splitlines():
    if any(k in line for k in ("I:", "LRA:", "Peak:")):
        print("звук:", line.strip())

cols = 6
w, h = 270, 480
rows = (len(ims) + cols - 1) // cols
S = Image.new("RGB", (cols * w, rows * (h + 30)), "white")
d = ImageDraw.Draw(S)
for k, (t, im) in enumerate(ims):
    x, y = (k % cols) * w, (k // cols) * (h + 30)
    th = im.resize((w, h))
    dd = ImageDraw.Draw(th)
    # безопасная зона текста: 250 px сверху и снизу
    dd.line([0, 250 * h / 1920, w, 250 * h / 1920], fill=(255, 0, 0), width=1)
    dd.line([0, (1920 - 250) * h / 1920, w, (1920 - 250) * h / 1920], fill=(255, 0, 0), width=1)
    S.paste(th, (x, y))
    d.text((x + 6, y + h + 6), f"{t:.2f} с", fill=(0, 0, 0))
S.save(sheet)
print("лист:", sheet)
