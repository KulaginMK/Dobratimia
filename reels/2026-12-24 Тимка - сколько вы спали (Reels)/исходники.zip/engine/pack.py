"""Пакует исходники одного ролика в zip: движок, шрифты, SVG, папка ролика и README со сборкой.
python3 engine/pack.py <папка_ролика> <число_кадров> <подкадры> <loop|noloop> <zip> "<название>" """
import sys, zipfile, pathlib
root = pathlib.Path(__file__).resolve().parent.parent
rid, frames, sub, loop, out, title = sys.argv[1:7]
loop_arg = " loop" if loop == "loop" else ""
dur = int(frames) / 60
readme = f"""# {title} — исходники

Всё, чтобы пересобрать ролик с нуля: анимация (HTML/SVG + JavaScript), звук (Python, синтез кодом), сборка (ffmpeg).
Музыки, сэмплов и голоса со стороны нет: каждый звук генерируется в `reels/{rid}/audio.py` через `engine/synth.py`.

## Что нужно

- Node.js 18+ и Playwright с Chromium (проверено на Playwright 1.63): `npm install playwright` и `npx playwright install chromium`
- Python 3.10+ (проверено на numpy 2.5, scipy 1.18, Pillow 12.3): `pip install numpy scipy pillow`
- ffmpeg 6+ с libx264 и aac

## Сборка

```bash
bash engine/build.sh {rid} {frames} {sub}{loop_arg}
```

Результат появится в `out/{rid}/`: `reels.mp4`, `обложка.png`, `сторис_1.png`, `sheet.png` (лист контрольных кадров).

Параметры: {frames} кадров при 60 к/с = {dur:.3f} с; {sub} подкадр(а) на кадр — motion blur с выдержкой 180°.
{"Ролик закольцован: последний кадр (t = " + f"{(int(frames) - 1) / 60:.1f}" + " с) совпадает с первым." if loop == "loop" else ""}

## Как это устроено

- `reels/{rid}/scene.js` — сцена: функция `renderAt(t)` рисует кадр в момент t секунд. Время — единственный источник правды, кадры можно снимать в любом порядке.
- `reels/{rid}/stills.js` — обложка (`?still=cover`) и кадр сторис (`?still=story`).
- `reels/{rid}/audio.py` — партитура: аккорды, мотивы, звуки событий по тем же таймкодам, что в сцене.
- `reels/{rid}/раскадровка.md` — варианты по сценам и что выбрано.
- `engine/lib.js` — общая библиотека: палитра бренда, кривые, текст, камера, Тимка. Дыхание Тимки перенесено из `expo-app/src/components/brand/Timka.tsx` (спецификация «Тимка · дыхание» 1.0).
- `engine/render.js` — покадровый рендер в Chromium, несколько параллельных работников, видео без потерь.
- `engine/mux.sh` — итоговое кодирование: H.264 High, yuv420p, BT.709, постоянный квантователь 16, AAC 192 кбит/с, `+faststart`.
- `engine/check.py` — проверка готового файла: параметры, кадры, совпадение кадров петли, громкость.
- `assets/` — SVG Тимки и знака из `handoff/assets/svg/` без изменений. `engine/fonts/` — Nunito 900 и Golos Text 400/600 (@fontsource, лицензия OFL).

Открыть сцену в браузере для просмотра: `reels/{rid}/scene.html` (в консоли `renderAt(5)` покажет кадр на 5-й секунде).
"""
extra = root / "reels" / rid / "README_extra.md"
if extra.exists():
    readme += "\n" + extra.read_text(encoding="utf-8")
skip = {"__pycache__"}
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("README.md", readme)
    for p in sorted((root / "engine").rglob("*")):
        if p.is_file() and not skip & set(p.parts):
            z.write(p, p.relative_to(root))
    for p in sorted((root / "assets").glob("*.svg")):
        z.write(p, p.relative_to(root))
    for p in sorted((root / "reels" / rid).rglob("*")):
        if p.is_file() and "check" not in p.parts:
            z.write(p, p.relative_to(root))
print(out, sum(1 for _ in zipfile.ZipFile(out).namelist()), "файлов")
