"""Синтез звука для роликов: всё звучание генерируется кодом, без сэмплов и чужой музыки.

Буфер — numpy float32 формы (2, n) на 48 кГц. Функции возвращают моно-сигналы;
mix() кладёт их в стерео-буфер с панорамой. master() доводит пик до заданного уровня.
"""
import numpy as np
from scipy import signal
from scipy.io import wavfile

SR = 48000
rng = np.random.default_rng(7)


def note(name):
    """'A4' → частота. Диезы: 'F#3'."""
    names = {"C": -9, "C#": -8, "D": -7, "D#": -6, "E": -5, "F": -4, "F#": -3, "G": -2, "G#": -1, "A": 0, "A#": 1, "B": 2}
    n, o = name[:-1], int(name[-1])
    return 440.0 * 2 ** ((names[n] + 12 * (o - 4)) / 12)


def buf(dur):
    return np.zeros((2, int(round(dur * SR))), dtype=np.float64)


def tt(dur):
    return np.arange(int(round(dur * SR))) / SR


def env_adsr(n, a=0.01, d=0.1, s=0.7, r=0.2, dur=None):
    """Огибающая длиной n отсчётов; dur — где начинается затухание r."""
    t = np.arange(n) / SR
    total = n / SR
    hold_end = total - r if dur is None else dur
    e = np.where(t < a, t / max(a, 1e-6), 1.0)
    dd = (t >= a) & (t < a + d)
    e = np.where(dd, 1 - (1 - s) * (t - a) / max(d, 1e-6), e)
    e = np.where((t >= a + d), s, e)
    rel = t >= hold_end
    e = np.where(rel, s * np.clip(1 - (t - hold_end) / max(r, 1e-6), 0, 1), e)
    return e


def smooth_env(n, a, r):
    """Мягкая огибающая: синусная атака a и синусный спад r (секунды), между ними 1."""
    t = np.arange(n) / SR
    total = n / SR
    e = np.ones(n)
    if a > 0:
        m = t < a
        e[m] = 0.5 - 0.5 * np.cos(np.pi * t[m] / a)
    if r > 0:
        m = t > total - r
        e[m] *= 0.5 + 0.5 * np.cos(np.pi * (t[m] - (total - r)) / r)
    return e


def lowpass(x, fc, order=2):
    sos = signal.butter(order, min(fc, SR * 0.45), "low", fs=SR, output="sos")
    return signal.sosfilt(sos, x)


def highpass(x, fc, order=2):
    sos = signal.butter(order, fc, "high", fs=SR, output="sos")
    return signal.sosfilt(sos, x)


def bandpass(x, lo, hi, order=2):
    sos = signal.butter(order, [lo, min(hi, SR * 0.45)], "band", fs=SR, output="sos")
    return signal.sosfilt(sos, x)


def sweep_filter(x, f0, f1, kind="low", q_order=2, block=512):
    """Фильтр с плавно меняющейся частотой (f0 → f1 по экспоненте), по блокам с сохранением состояния."""
    n = len(x)
    y = np.zeros(n)
    zi = None
    for i in range(0, n, block):
        k = i / max(1, n - 1)
        fc = f0 * (f1 / f0) ** k
        sos = signal.butter(q_order, min(fc, SR * 0.45), kind, fs=SR, output="sos")
        if zi is None:
            zi = np.zeros((sos.shape[0], 2))
        y[i : i + block], zi = signal.sosfilt(sos, x[i : i + block], zi=zi)
    return y


# ---------- инструменты ----------

def pad(freqs, dur, attack=1.5, release=2.0, bright=1200, detune=0.004, voices=3, level=0.12):
    """Тёплый пэд: на каждую ноту несколько слегка расстроенных треугольников, мягкий ФНЧ."""
    t = tt(dur)
    out = np.zeros_like(t)
    for f in freqs:
        for v in range(voices):
            d = 1 + detune * (v - (voices - 1) / 2)
            ph = rng.uniform(0, 2 * np.pi)
            # треугольник через сумму нечётных гармоник
            w = np.zeros_like(t)
            for h in (1, 3, 5, 7):
                w += ((-1) ** ((h - 1) // 2)) * np.sin(2 * np.pi * f * d * h * t + ph * h) / (h * h)
            out += w
    out /= max(1, len(freqs) * voices)
    out = lowpass(out, bright, order=2)
    lfo = 1 + 0.08 * np.sin(2 * np.pi * 0.11 * t + rng.uniform(0, 6))
    return out * smooth_env(len(t), attack, release) * lfo * level * 4


def sine_pad(freqs, dur, attack=2.0, release=2.0, level=0.1):
    """Совсем мягкий пэд из синусов — для сна."""
    t = tt(dur)
    out = np.zeros_like(t)
    for f in freqs:
        for d in (0.997, 1.0, 1.003):
            out += np.sin(2 * np.pi * f * d * t + rng.uniform(0, 6))
            out += 0.18 * np.sin(2 * np.pi * 2 * f * d * t + rng.uniform(0, 6))
    out /= max(1, len(freqs) * 3)
    lfo = 1 + 0.1 * np.sin(2 * np.pi * 0.07 * t + rng.uniform(0, 6))
    return out * smooth_env(len(t), attack, release) * lfo * level * 3


def pluck(f, dur=2.5, bright=0.5, level=0.3):
    """Калимба/маримба: короткая атака, быстрый спад верхних призвуков."""
    t = tt(dur)
    partials = [(1, 1.0, 2.2), (2.0, 0.25 * bright, 5.0), (3.01, 0.12 * bright, 8.0), (5.4, 0.05 * bright, 14.0)]
    out = np.zeros_like(t)
    for m, a, dec in partials:
        out += a * np.sin(2 * np.pi * f * m * t) * np.exp(-dec * t)
    att = np.clip(t / 0.004, 0, 1)
    return out * att * level


def bell(f, dur=4.0, level=0.2):
    """Мягкий колокольчик: неровные призвуки, долгий хвост."""
    t = tt(dur)
    partials = [(1, 1.0, 0.9), (2.76, 0.35, 1.8), (5.4, 0.12, 3.5), (8.93, 0.05, 6.0)]
    out = np.zeros_like(t)
    for m, a, dec in partials:
        out += a * np.sin(2 * np.pi * f * m * t + rng.uniform(0, 6)) * np.exp(-dec * t)
    att = np.clip(t / 0.006, 0, 1)
    return out * att * level


def felt(f, dur=3.0, level=0.25):
    """«Фетровое» фортепиано: синус + немного второй гармоники, мягкая атака."""
    t = tt(dur)
    out = np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * 2 * f * t) * np.exp(-3 * t) + 0.1 * np.sin(2 * np.pi * 3 * f * t) * np.exp(-6 * t)
    att = 0.5 - 0.5 * np.cos(np.pi * np.clip(t / 0.015, 0, 1))
    return lowpass(out * att * np.exp(-1.3 * t), 2500) * level


def noise(n):
    return rng.standard_normal(n)


def breath(dur, kind="in", level=0.12):
    """Дыхание как воздух: шум в полосе, на вдохе частота растёт, на выдохе падает."""
    n = int(round(dur * SR))
    x = noise(n)
    if kind == "in":
        y = sweep_filter(x, 500, 1800, "low")
        e = np.sin(np.pi * np.linspace(0, 1, n)) ** 1.2
    else:
        y = sweep_filter(x, 1600, 380, "low")
        e = np.sin(np.pi * np.linspace(0, 1, n) ** 0.7) ** 1.5
    y = highpass(y, 150)
    return y / (np.max(np.abs(y)) + 1e-9) * e * level


def whoosh(dur=0.5, f0=300, f1=2500, level=0.15):
    n = int(round(dur * SR))
    y = sweep_filter(noise(n), f0, f1, "low")
    y = highpass(y, 120)
    e = np.sin(np.pi * np.linspace(0, 1, n)) ** 2
    return y / (np.max(np.abs(y)) + 1e-9) * e * level


def thump(f=90, dur=0.35, level=0.4):
    """Мягкий глухой удар (закрытая книга, касание)."""
    t = tt(dur)
    fr = f * (1 + 0.6 * np.exp(-30 * t))
    ph = 2 * np.pi * np.cumsum(fr) / SR
    body = np.sin(ph) * np.exp(-14 * t)
    click = lowpass(noise(len(t)), 1800) * np.exp(-60 * t) * 0.5
    return (body + click) * level


def tick(f=1800, dur=0.06, level=0.08):
    """Тихий деревянный «тик»."""
    t = tt(dur)
    return (np.sin(2 * np.pi * f * t) * np.exp(-80 * t) + 0.3 * lowpass(noise(len(t)), 4000) * np.exp(-120 * t)) * level


def pop(f=600, dur=0.12, level=0.15):
    """Мягкий «пуп» появления: синус с падающей частотой."""
    t = tt(dur)
    fr = f * (1 + 1.2 * np.exp(-40 * t))
    ph = 2 * np.pi * np.cumsum(fr) / SR
    return np.sin(ph) * np.exp(-25 * t) * np.clip(t / 0.002, 0, 1) * level


def sparkle(f=2600, dur=0.6, level=0.06):
    t = tt(dur)
    return (np.sin(2 * np.pi * f * t) + 0.5 * np.sin(2 * np.pi * f * 1.5 * t)) * np.exp(-7 * t) * np.clip(t / 0.003, 0, 1) * level


# ---------- сведение ----------

def mix(b, x, at, gain=1.0, pan=0.0):
    """Кладёт моно-сигнал x в стерео-буфер b с момента at (с). pan −1…1, равномощная панорама."""
    i = int(round(at * SR))
    if i >= b.shape[1]:
        return
    x = np.asarray(x)
    j = min(b.shape[1], i + len(x))
    if i < 0:
        x = x[-i:]
        i = 0
        j = min(b.shape[1], len(x))
    a = (pan + 1) * np.pi / 4
    b[0, i:j] += x[: j - i] * gain * np.cos(a)
    b[1, i:j] += x[: j - i] * gain * np.sin(a)


def reverb(b, seconds=2.4, wet=0.25, predelay=0.02, tone=4000):
    """Простая стерео-реверберация: свёртка с затухающим шумом (у каналов свой шум)."""
    n = int(seconds * SR)
    t = np.arange(n) / SR
    out = np.zeros((2, b.shape[1] + n + int(predelay * SR)))
    for c in range(2):
        ir = noise(n) * np.exp(-6.9 * t / seconds)
        ir = lowpass(ir, tone)
        ir /= np.sqrt(np.sum(ir ** 2)) + 1e-9
        ir = np.concatenate([np.zeros(int(predelay * SR)), ir])
        out[c, : b.shape[1] + len(ir) - 1] += signal.fftconvolve(b[c], ir) * wet
        out[c, : b.shape[1]] += b[c] * (1 - wet * 0.5)
    return out


def loop_wrap(b, length):
    """Закольцовка: хвост за концом ролика добавляется в начало — шов не слышен."""
    n = int(round(length * SR))
    out = b[:, :n].copy()
    tail = b[:, n:]
    k = 0
    while tail.shape[1] > 0:
        m = min(n, tail.shape[1])
        out[:, :m] += tail[:, :m]
        tail = tail[:, m:]
        k += 1
    return out


def fit(b, length):
    n = int(round(length * SR))
    if b.shape[1] >= n:
        return b[:, :n]
    return np.concatenate([b, np.zeros((2, n - b.shape[1]))], axis=1)


def master(b, peak_db=-1.5, drive=1.0):
    """Мягкое ограничение и нормализация пика. Итоговый пик ≤ peak_db dBFS."""
    b = b - np.mean(b, axis=1, keepdims=True)
    pk = np.max(np.abs(b)) + 1e-12
    b = b / pk
    b = np.tanh(b * drive * 1.2) / np.tanh(drive * 1.2)
    target = 10 ** (peak_db / 20)
    b = b / (np.max(np.abs(b)) + 1e-12) * target
    return b


def fade_edges(b, ms=5):
    n = int(SR * ms / 1000)
    r = np.linspace(0, 1, n)
    b[:, :n] *= r
    b[:, -n:] *= r[::-1]
    return b


def write(path, b):
    wavfile.write(path, SR, b.T.astype(np.float32))
    pk = 20 * np.log10(np.max(np.abs(b)) + 1e-12)
    print(f"{path}: {b.shape[1] / SR:.3f} с, пик {pk:.2f} dBFS")


def lufs(b):
    """Интегральная громкость по BS.1770 (K-взвешивание, стробирование), 48 кГц."""
    sh_b = [1.53512485958697, -2.69169618940638, 1.19839281085285]
    sh_a = [1.0, -1.69065929318241, 0.73248077421585]
    hp_b = [1.0, -2.0, 1.0]
    hp_a = [1.0, -1.99004745483398, 0.99007225036621]
    y = signal.lfilter(hp_b, hp_a, signal.lfilter(sh_b, sh_a, b, axis=1), axis=1)
    blk, hop = int(0.4 * SR), int(0.1 * SR)
    z = []
    for i in range(0, y.shape[1] - blk, hop):
        z.append(np.sum(np.mean(y[:, i : i + blk] ** 2, axis=1)))
    z = np.array(z) + 1e-12
    l = -0.691 + 10 * np.log10(z)
    z = z[l > -70]
    rel = -0.691 + 10 * np.log10(np.mean(z)) - 10
    z = z[(-0.691 + 10 * np.log10(z)) > rel]
    return -0.691 + 10 * np.log10(np.mean(z))


def master_lufs(b, target=-17.0, ceiling_db=-1.5, knee_db=-6.0):
    """Громкость к target LUFS, затем мягкий лимитер: выше knee пики сглаживаются, потолок ceiling."""
    b = b - np.mean(b, axis=1, keepdims=True)
    g = 10 ** ((target - lufs(b)) / 20)
    b = b * g
    ceil = 10 ** (ceiling_db / 20)
    th = 10 ** (knee_db / 20) * ceil
    a = np.abs(b)
    over = a > th
    comp = th + (ceil - th) * np.tanh((a - th) / (ceil - th))
    b = np.where(over, np.sign(b) * comp, b)
    pk = np.max(np.abs(b))
    if pk > ceil:
        b *= ceil / pk
    print(f"громкость {lufs(b):.1f} LUFS, пик {20 * np.log10(np.max(np.abs(b))):.2f} dBFS")
    return b
