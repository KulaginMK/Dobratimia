#!/usr/bin/env bash
# Последний кадр петли — заново, отдельным работником, и пересборка mp4.
# Зачем: работник, который отрисовал сотни кадров подряд, растрирует края фигур чуть иначе, чем свежий браузер;
# у петли последний кадр должен совпасть с кадром 0 до пикселя.
# bash engine/fixlast.sh <папка_ролика> <число_кадров> <подкадры>   (после engine/build.sh)
set -euo pipefail
cd "$(dirname "$0")/.."
ID=$1; N=$2; SUB=$3; L=$((N-1))
node engine/render.js reels/$ID/scene.html out/$ID/last.mkv --frames $N --from $L --to $N --workers 1 --sub $SUB >/dev/null
ffmpeg -y -v error -i out/$ID/video.mkv -i out/$ID/last.mkv -filter_complex "[0:v]trim=end_frame=$L,setpts=PTS-STARTPTS[a];[1:v]setpts=PTS-STARTPTS[b];[a][b]concat=n=2:v=1[o]" -map "[o]" -r 60 -c:v libx264rgb -qp 0 -preset ultrafast out/$ID/video2.mkv
mv out/$ID/video2.mkv out/$ID/video.mkv
bash engine/mux.sh out/$ID/video.mkv out/$ID/audio.wav out/$ID/reels.mp4 "$N"
python3 engine/check.py out/$ID/reels.mp4 --loop --times 0
