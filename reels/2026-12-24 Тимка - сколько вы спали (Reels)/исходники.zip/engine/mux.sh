#!/usr/bin/env bash
# Сборка итогового MP4: видео без потерь + звук → H.264 yuv420p (BT.709) + AAC, faststart.
# bash engine/mux.sh <video.mkv> <audio.wav> <out.mp4> [число_кадров]
# Если задано число кадров, последний кадр — опорный (I-кадр), как и первый: у петли они совпадают и после сжатия.
set -euo pipefail
KF=()
if [ "${4:-}" != "" ]; then KF=(-force_key_frames "expr:eq(n,0)+eq(n,$(( $4 - 1 )))"); fi
ffmpeg -y -v error -i "$1" -i "$2" -map 0:v:0 -map 1:a:0 \
  -vf "scale=out_color_matrix=bt709:out_range=tv:flags=lanczos+accurate_rnd+full_chroma_int,format=yuv420p" \
  -c:v libx264 -preset slow -qp 16 -profile:v high -level:v 4.2 -g 120 -x264-params mbtree=0 "${KF[@]}" \
  -colorspace bt709 -color_primaries bt709 -color_trc bt709 -color_range tv \
  -c:a aac -b:a 192k -ar 48000 -ac 2 \
  -shortest -movflags +faststart "$3"
