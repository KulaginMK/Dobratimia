// Снимок одного кадра или статичного макета (обложка, сторис).
// node engine/still.js <scene.html> <out.png> [--t секунды] [--query still=cover]
const { chromium } = require('playwright');
const path = require('path');
const args = process.argv.slice(2);
const scene = path.resolve(args[0]);
const out = path.resolve(args[1]);
const get = (n) => (args.includes('--' + n) ? args[args.indexOf('--' + n) + 1] : undefined);
const t = Number(get('t') ?? 0);
const query = get('query') ?? '';
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1080, height: 1920 }, deviceScaleFactor: 1 });
  page.on('pageerror', (e) => console.error('[scene error]', e.message));
  await page.goto('file://' + scene + (query ? '?' + query : ''));
  await page.waitForFunction(() => window.READY === true, null, { timeout: 30000 });
  const times = (get('times') ?? String(t)).split(',').map(Number);
  await page.evaluate((v) => window.renderAt(v), times[0]);
  await page.screenshot({ type: 'png' }); // прогрев
  for (const x of times) {
    await page.evaluate((v) => window.renderAt(v), x);
    const file = times.length > 1 ? out.replace(/\.png$/, `_${x.toFixed(2)}.png`) : out;
    await page.screenshot({ path: file, type: 'png' });
  }
  await browser.close();
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
