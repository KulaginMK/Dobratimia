#!/usr/bin/env bash
# Полная сборка одного ролика: звук → кадры → MP4 → обложка и сторис → проверка.
# bash engine/build.sh <папка_ролика> <число_кадров> [подкадры=1] [loop]
# Пример: bash engine/build.sh r1 3481 2 loop
set -euo pipefail
cd "$(dirname "$0")/.."
ID=$1; FRAMES=$2; SUB=${3:-1}; LOOP=${4:-}
FPS=60
DUR=$(python3 -c "print($FRAMES/$FPS)")
python3 engine/build_assets.py
mkdir -p out/$ID
python3 reels/$ID/audio.py out/$ID/audio.wav "$DUR"
node engine/render.js reels/$ID/scene.html out/$ID/video.mkv --frames "$FRAMES" --fps $FPS --workers "${WORKERS:-4}" --sub "$SUB"
bash engine/mux.sh out/$ID/video.mkv out/$ID/audio.wav out/$ID/reels.mp4 "$FRAMES"
node engine/still.js reels/$ID/scene.html "out/$ID/обложка.png" --query still=cover
node engine/still.js reels/$ID/scene.html "out/$ID/сторис_1.png" --query still=story
python3 engine/check.py out/$ID/reels.mp4 ${LOOP:+--loop} --times "0,$(python3 -c "print(round($DUR/4,2))"),$(python3 -c "print(round($DUR/2,2))"),$(python3 -c "print(round(3*$DUR/4,2))"),$DUR" --sheet out/$ID/sheet.png
echo "Готово: out/$ID/reels.mp4"
