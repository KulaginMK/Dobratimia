// «Тимка — прогноз на каникулы». 14 с, петля: кадр 14,0 совпадает с кадром 0. Серия «Тимка»: без голоса.
(function () {
  const STILL = new URLSearchParams(location.search).get('still');
  const { C, clamp, lerp, ease, win, keys, svg, tr, op, set, div } = R;
  const D = 14;
  const TAU = Math.PI * 2;
  const per = (k) => (TAU * k) / D;
  const S = R.camStage(C.bg);
  // передний план поверх Тимки: крупные билеты у камеры
  const fgSvg = svg('svg', { width: 1080, height: 1920, viewBox: '0 0 1080 1920' }, S.cam);
  fgSvg.style.cssText = 'position:absolute;left:0;top:0;overflow:visible';
  const fg = svg('g', {}, fgSvg);

  const blobs = [
    [110, 420, 230, C.soft, 0.5],
    [1010, 1450, 190, C.growthSoft, 0.85],
    [70, 1700, 260, C.soft, 0.42],
    [990, 300, 120, C.growthSoft, 0.7],
  ].map(([x, y, r, c, o]) => ({ x, y, n: svg('circle', { cx: x, cy: y, r, fill: c, opacity: o }, S.far) }));

  // ---- доска «Сессия» ----
  const BX = 440;
  const BY = 720;
  const BW = 590;
  const BH = 690;
  svg('rect', { x: BX, y: BY, width: BW, height: BH, rx: 40, fill: C.choco }, S.world);
  const bclip = svg('clipPath', { id: 'board', clipPathUnits: 'userSpaceOnUse' }, S.defs);
  svg('rect', { x: BX, y: BY, width: BW, height: BH, rx: 40 }, bclip);
  const boardTitle = R.textBlock(S.text, { text: 'Каникулы', y: BY + 36, x: BX, w: BW, size: 64, line: 76, color: C.white });
  const daysRow = div({ style: { position: 'absolute', left: BX + 'px', top: BY + 128 + 'px', width: BW + 'px', display: 'flex', justifyContent: 'center', gap: '18px', font: "600 40px 'Golos Text'", color: C.white } }, S.text);
  const days = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'].map((d) => div({ style: { position: 'relative' }, html: d }, daysRow));
  // облако
  const cloud = svg('g', {}, S.world);
  [
    [-95, 22, 72],
    [0, -22, 98],
    [98, 16, 74],
  ].forEach(([x, y, r]) => svg('circle', { cx: x, cy: y, r, fill: C.soft }, cloud));
  svg('rect', { x: -160, y: 10, width: 320, height: 80, rx: 40, fill: C.soft }, cloud);
  const CLX = BX + BW / 2;
  const CLY = BY + 400;

  // ---- билеты ----
  let seed = 12345;
  const rnd = () => {
    seed = (seed * 1664525 + 1013904223) % 4294967296;
    return seed / 4294967296;
  };
  const ticketShape = (g, layer) => {
    // плоская снежинка: белый кружок (иногда мягкая терракота) — без контуров и лучей
    // на шоколадной доске — белая, на светлом фоне — мягкая терракота (белая на #FBF5EE не видна)
    svg('circle', { r: 10, fill: layer === 'back' ? C.white : C.soft }, g);
  };
  const backG = svg('g', { 'clip-path': 'url(#board)' }, S.world);
  const tickets = [];
  // на доске: из облака
  for (let i = 0; i < 26; i++) tickets.push({ layer: 'back', x0: CLX - 140 + rnd() * 280, t0: 6.2 + rnd() * 5.6, v: 150 + rnd() * 80, y0: CLY + 60, rs: (rnd() - 0.5) * 240, s: 0.75 + rnd() * 0.2 });
  // по всему кадру
  for (let i = 0; i < 60; i++) tickets.push({ layer: 'mid', x0: 40 + rnd() * 1000, t0: 6.1 + rnd() * 2.4, v: 260 + rnd() * 140, y0: 420 - rnd() * 1300, rs: 0, s: 0.8 + rnd() * 0.7 });
  // у камеры, размыты (ближний план)
  for (let i = 0; i < 8; i++) tickets.push({ layer: 'fg', x0: 60 + rnd() * 960, t0: 6.6 + rnd() * 4.6, v: 520 + rnd() * 160, y0: -120, rs: 0, s: 3.2 + rnd() * 1.2 });

  // ---- Тимка-ведущий: дыхательная фигура (лица) + лапка из позы hello ----
  const TX = 270;
  const TY = 1340;
  const TS = 480;
  const tkG = svg('g', {}, S.top);
  const tk = R.breathingTimka(tkG);
  const hand = svg('g', {}, tk.behind);
  svg('ellipse', { cx: 103, cy: 58, rx: 7, ry: 11, transform: 'rotate(28 103 58)', fill: '#F2B28A' }, hand);
  // зонтик
  const UCX = 330;
  const UCY = 1080;
  const UR = 250;
  const UH = 200;
  const umb = svg('g', {}, S.top);
  const handle = svg('g', {}, umb);
  const hRect = svg('rect', { x: -7, y: 0, width: 14, height: 300, rx: 7, fill: C.choco }, handle);
  const canopy = svg('g', {}, umb);
  svg('path', { d: `M${-UR} 0 A${UR} ${UH} 0 0 1 ${UR} 0 Q${UR * 0.75} -26 ${UR * 0.5} 0 Q${UR * 0.25} -26 0 0 Q${-UR * 0.25} -26 ${-UR * 0.5} 0 Q${-UR * 0.75} -26 ${-UR} 0 Z`, fill: C.primary }, canopy);
  svg('rect', { x: -6, y: -UH - 30, width: 12, height: 34, rx: 6, fill: C.choco }, canopy);
  const midG = svg('g', {}, S.top);
  tickets.forEach((tk_) => {
    const g = svg('g', {}, tk_.layer === 'back' ? backG : tk_.layer === 'mid' ? midG : fg);
    ticketShape(g, tk_.layer);
    if (tk_.layer === 'fg') g.setAttribute('filter', 'url(#fgBlur)');
    tk_.n = g;
  });
  const fb = svg('filter', { id: 'fgBlur', x: '-50%', y: '-50%', width: '200%', height: '200%' }, S.defs);
  svg('feGaussianBlur', { stdDeviation: 3.2 }, fb);
  // fgBlur в defs дальнего SVG не виден из другого <svg> — копия фильтра рядом с билетами
  const fdefs = svg('defs', {}, fgSvg);
  const fb2 = svg('filter', { id: 'fgBlur', x: '-50%', y: '-50%', width: '200%', height: '200%' }, fdefs);
  svg('feGaussianBlur', { stdDeviation: 3.2 }, fb2);
  fb.remove();

  // кружка чая в лапке (на совете) — поверх Тимки
  const mug = svg('g', {}, S.top);
  const mugSteam = svg('g', {}, mug);
  for (const dx of [-14, 8]) svg('path', { d: `M${dx} -48 q-10 -15 0 -30 q10 -15 0 -30`, fill: 'none', stroke: C.soft, 'stroke-width': 8, 'stroke-linecap': 'round' }, mugSteam);
  svg('circle', { cx: 42, cy: 2, r: 20, fill: C.primary }, mug);
  svg('circle', { cx: 42, cy: 2, r: 10, fill: C.bg }, mug);
  svg('rect', { x: -42, y: -36, width: 84, height: 76, rx: 22, fill: C.primary }, mug);
  // солнце на доске: «ясно» (мёд — маленький акцент, вокруг мягкий ореол)
  const sun = svg('g', {}, S.world);
  svg('circle', { r: 92, fill: C.soft, opacity: 0.25 }, sun);
  svg('circle', { r: 48, fill: C.honey }, sun);

  // ---- заголовки (вне камеры, всегда читаются) ----
  const pov = R.chip({ text: S.ui }, { text: 'POV', y: 262, size: 54 });
  const lines = [
    { a: -10, b: 1.85, text: 'Вы смотрите прогноз\nпогоды на каникулы' },
    { a: 2.0, b: 5.85, text: 'Пн–Пт: ясно,\nбез коллоквиумов' },
    { a: 6.0, b: 9.85, text: 'Выходные:\nсон до полудня' },
    { a: 10.0, b: 13.15, text: 'Совет синоптика:\nотдых без конспектов' },
  ].map((l, i) => ({ ...l, n: R.textBlock(S.ui, { text: l.text, y: i === 0 ? 370 : 330, size: 76, line: 90, w: 1000, words: true }) }));
  const tip = R.textBlock(S.ui, { text: 'сон, прогулки и тёплый чай', y: 530, size: 50, line: 62, font: 'text', weight: 600, color: C.primary, words: true });

  const faceTrack = [
    [0, 'look'],
    [6.25, 'in'],
    [7.7, 'look'],
    [10.35, 'rest'],
    [13.3, 'look'],
  ];

  // билет в момент t: положение и поворот; для «mid» — касание купола и соскальзывание
  const canopyY = (x) => UCY - UH * Math.sqrt(Math.max(0, 1 - ((x - UCX) / UR) ** 2));
  const umbOpen = (t) => ease.inOutCubic((t - 10.05) / 0.35) * (1 - ease.inOutCubic((t - 13.2) / 0.3));
  function ticketAt(k, t) {
    const dt = t - k.t0;
    if (dt < 0) return null;
    let x = k.x0 + 26 * Math.sin(dt * 1.6 + k.x0);
    let y = k.y0 + k.v * dt;
    let r = k.rs * dt;
    if (false) { // купола нет: снег падает свободно
      const yc = canopyY(k.x0) - 18;
      const tc = k.t0 + (yc - k.y0) / k.v;
      if (tc > 10.4 && tc < 13.15) {
        if (t >= tc) {
          // соскальзывает по куполу наружу, потом снова падает с края
          const dir = k.x0 < UCX ? -1 : 1;
          const slide = 360;
          const edge = UR + 10 - Math.abs(k.x0 - UCX);
          const te = tc + edge / slide;
          if (t < te) {
            x = k.x0 + dir * slide * (t - tc);
            y = canopyY(x) - 18;
            r = k.rs * (tc - k.t0) + dir * 40 * (t - tc);
          } else {
            x = UCX + dir * (UR + 10 + 60 * (t - te));
            y = canopyY(UCX + dir * UR) - 18 + k.v * 0.8 * (t - te);
            r = k.rs * (tc - k.t0) + dir * 90 * (t - te);
          }
        }
      }
    }
    return { x, y, r };
  }

  window.renderAt = function (tRaw) {
    const t = Math.round((((tRaw % D) + D) % D) * 1e6) / 1e6;
    // ---- камера ----
    const z = keys(t, [[0, 1.0], [2.0, 1.0], [2.6, 1.05], [5.8, 1.05], [6.5, 1.06], [7.4, 1.0], [10.0, 1.0], [10.6, 1.06], [13.0, 1.06], [14, 1.0]]);
    const cx = keys(t, [[0, 540], [2.0, 540], [2.6, 600], [5.8, 600], [6.5, 585], [7.4, 550], [10.0, 550], [10.6, 480], [13.0, 480], [14, 540]]);
    const cy = keys(t, [[0, 960], [2.0, 960], [2.6, 980], [5.8, 980], [6.5, 920], [7.4, 980], [10.0, 980], [10.6, 1020], [13.0, 1020], [14, 960]]);
    R.camApply(S, { cx, cy, z, r: 0.4 * Math.sin(per(1) * t), x: 6 * Math.sin(per(2) * t), y: 4 * Math.sin(per(1) * t + 1) });
    blobs.forEach((b, i) => set(b.n, { cy: b.y + 12 * Math.sin(per(1) * t + i * 1.7) }));

    // ---- доска: дни недели и облако ----
    const f1 = win(t, 2.0, 2.4, 5.8, 6.1);
    const f2 = win(t, 6.0, 6.3, 9.8, 10.1);
    days.forEach((dEl, i) => {
      const on = i < 5 ? f1 : f2;
      dEl.style.opacity = String(0.55 + 0.45 * on);
      dEl.style.transform = `translateY(${-6 * on}px)`;
    });
    const sunK = ease.outCubic((t - 2.1) / 0.6) * (1 - ease.inOutSine((t - 5.9) / 0.4));
    tr(sun, `translate(${CLX + (1 - sunK) * 360} ${CLY - 20 + 6 * Math.sin(per(3) * t)}) scale(${0.9 + 0.1 * sunK})`);
    op(sun, sunK);
    const cl = ease.outCubic((t - 5.95) / 0.6) * (1 - ease.inOutSine((t - 13.2) / 0.5));
    tr(cloud, `translate(${CLX + (1 - cl) * 360} ${CLY + 6 * Math.sin(per(3) * t)}) scale(${0.9 + 0.1 * cl})`);
    op(cloud, cl);

    // ---- билеты ----
    tickets.forEach((k) => {
      const p = ticketAt(k, t);
      if (!p || p.y > 2100 || (k.layer === 'back' && p.y > BY + BH + 60)) return op(k.n, 0);
      // снег не заходит под заголовки: проявляется ниже 640 px
      const below = k.layer === 'back' ? 1 : clamp((p.y - 640) / 140);
      op(k.n, below * (1 - ease.inOutSine((t - 12.9) / 0.5)) * (k.layer === 'fg' ? 0.8 : 1));
      tr(k.n, `translate(${p.x} ${p.y}) rotate(${p.r}) scale(${k.s})`);
    });

    // ---- Тимка ----
    const point = (a, b) => win(t, a, a + 0.3, b - 0.3, b, ease.inOutSine);
    // лапка: машет в хуке, показывает на доску в прогнозах, держит зонтик в совете
    const wave = R.waveAngle(t, 0.3);
    const show = 26 * Math.max(point(2.2, 5.8), point(6.1, 9.6));
    const hold = -20 * win(t, 9.9, 10.1, 13.3, 13.6);
    const ang = wave + show + hold;
    tr(hand, `rotate(${ang} 98 68)`);
    const eyeDx = keys(t, [[2.2, 0], [2.5, 2.4], [5.6, 2.4], [5.9, 0]]);
    const eyeDy = keys(t, [[6.2, 0], [6.4, -2.2], [7.6, -2.2], [7.9, 0]]);
    const fill = 0.3 + 0.08 * Math.sin(per(5) * t) + 0.5 * win(t, 6.2, 6.5, 7.5, 8.0);
    tk.update({ t, fill, face: R.faceAt(faceTrack, t), x: TX, y: TY, size: TS, eyeDx, eyeDy, noPuffs: true, blinkEvery: D / 4, idleSpeed: per(3) });

    // ---- зонтик: растёт из лапки, раскрывается, в конце складывается ----
    const uo = umbOpen(t);
    const appear = ease.outCubic((t - 9.95) / 0.2) * (1 - ease.inOutSine((t - 13.45) / 0.25));
    op(umb, 0); // зонтик не нужен: вместо него кружка чая
    op(mug, appear);
    // лапка в координатах кадра (поворот вокруг плеча 98, 68)
    const k = TS / 120;
    const a = (ang * Math.PI) / 180;
    const hx = 98 + 5 * Math.cos(a) + 10 * Math.sin(a);
    const hy = 68 + 5 * Math.sin(a) - 10 * Math.cos(a);
    const HX = TX - 60 * k + hx * k;
    const HY = TY - 60 * k + (hy + 6) * k;
    const top = { x: lerp(HX, UCX, 0.2 + 0.8 * appear), y: lerp(HY - 60, UCY, appear) };
    const len = Math.hypot(HX - top.x, HY - top.y);
    tr(handle, `translate(${top.x} ${top.y}) rotate(${(Math.atan2(HX - top.x, HY - top.y) * -180) / Math.PI})`);
    set(hRect, { height: Math.max(10, len + 10) });
    tr(canopy, `translate(${top.x} ${top.y}) scale(${0.12 + 0.88 * uo} ${0.5 + 0.5 * uo})`);
    tr(mug, `translate(${HX + 4} ${HY - 26}) scale(${0.7 + 0.3 * appear})`);
    tr(mugSteam, `translate(0 ${-6 * Math.sin(per(7) * t)})`);

    // ---- заголовки ----
    lines.forEach((l, i) => {
      if (i === 0) {
        if (t < 2.0) {
          op(l.n, 1 - ease.inOutSine((t - 1.85) / 0.15));
          R.wordsIn(l.n, 1);
        } else if (t >= 13.45) {
          op(l.n, 1);
          R.wordsIn(l.n, clamp((t - 13.45) / 0.5));
        } else op(l.n, 0);
        return;
      }
      const kIn = (t - l.a) / 0.6;
      const out = clamp((t - l.b) / 0.15);
      if (kIn <= 0 || out >= 1) return op(l.n, 0);
      op(l.n, 1 - out);
      R.wordsIn(l.n, clamp(kIn), { spread: 0.45 });
    });
    const povO = t < 2.0 ? 1 - ease.inOutSine((t - 1.85) / 0.15) : t >= 13.45 ? ease.inOutSine((t - 13.45) / 0.4) : 0;
    op(pov, povO);
    if (t > 10.5 && t < 13.2) {
      op(tip, 1 - clamp((t - 13.0) / 0.15));
      R.wordsIn(tip, clamp((t - 10.6) / 0.6), { spread: 0.4, rise: 20 });
    } else op(tip, 0);
  };

  if (STILL) {
    const base = window.renderAt;
    window.renderAt = function () {
      base(11.2); // Тимка с чаем под снегом
      [pov, tip, ...lines.map((l) => l.n)].forEach((n) => op(n, 0));
      const k = 0.9; // доска с днями недели: 40 px × 0,9 = 36 px — не мельче правила
      const y = STILL === 'cover' ? 1510 : 1400;
      S.cam.style.transform = `translate(540px, ${y}px) scale(${k}) translate(-540px, -1530px)`;
      // в макете билеты только внутри сцены: не под заголовками
      const [lo, hi] = STILL === 'cover' ? [780, 1480] : [700, 1360];
      tickets.forEach((tk_) => {
        const p = ticketAt(tk_, 11.2);
        const sy = p ? y + (p.y - 1530) * k : -1;
        if (!p || sy < lo || sy > hi || tk_.layer === 'fg') op(tk_.n, 0);
      });
      if (STILL === 'cover') {
        R.chip({ text: S.ui }, { text: 'Тимка', y: 300, size: 44 });
        R.textBlock(S.ui, { text: 'Прогноз\nна каникулы', y: 390, size: 130, line: 140, w: 1000 });
        R.textBlock(S.ui, { text: 'Выходные: сон до полудня', y: 1585, size: 46, line: 58, w: 900, font: 'text', weight: 600 });
      } else {
        const wsvg = svg('svg', { width: 1080, height: 1920, viewBox: '0 0 1080 1920' }, S.ui);
        wsvg.style.cssText = 'position:absolute;left:0;top:0';
        R.wordmark({ world: wsvg, text: S.ui }, { y: 280, h: 76 });
        R.textBlock(S.ui, { text: 'Как пройдут\nваши каникулы?', y: 390, size: 88, line: 100, w: 1000 });
        R.textBlock(S.ui, { text: 'Ответьте в опросе ниже', y: 1440, size: 44, line: 56, font: 'text', weight: 600, color: C.primary });
      }
      window.renderAt = () => {};
    };
  }
  R.ready().then(() => (window.READY = true));
})();
