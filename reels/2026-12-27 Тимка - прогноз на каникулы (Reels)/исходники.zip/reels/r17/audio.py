"""Звук «Тимка — прогноз на каникулы»: позывные прогноза, солнце, тихий снег, кружка чая; всё синтезировано кодом.
14 с = 7 тактов по 2 с (120 уд/мин). python3 reels/r6/audio.py out/audio.wav [длительность]"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "engine"))
import numpy as np
import synth as s
from synth import note as N

D = 14.0
out = sys.argv[1]
length = float(sys.argv[2]) if len(sys.argv) > 2 else D
BEAT = 0.5
b = s.buf(D + 4)

def shaker(at, level):
    n = int(0.04 * s.SR)
    x = s.highpass(s.noise(n), 6000) * np.exp(-np.arange(n) / s.SR * 80)
    s.mix(b, x * level, at, pan=0.3)

# такты: G — D — Em — C — G — D — G (последний ведёт в начало петли)
bars = [("G", ["G3", "B3", "D4"], "G2"), ("D", ["F#3", "A3", "D4"], "D2"), ("Em", ["G3", "B3", "E4"], "E2"), ("C", ["G3", "C4", "E4"], "C2"),
        ("G", ["G3", "B3", "D4"], "G2"), ("D", ["F#3", "A3", "D4"], "D2"), ("G", ["G3", "B3", "D4"], "G2")]
for i, (_, ch, bass) in enumerate(bars):
    t0 = i * 2.0
    rain = 6.0 <= t0 < 10.0
    for k in range(8):
        f = N(ch[[0, 1, 2, 1, 0, 2, 1, 2][k]])
        s.mix(b, s.pluck(f, 0.7 if rain else 1.0, bright=0.6, level=0.07 if k % 2 else 0.09), t0 + k * BEAT / 2, pan=-0.3 + 0.6 * (k % 4) / 3)
        shaker(t0 + k * BEAT / 2 + BEAT / 4, 0.018)
    for k in (0, 2):
        s.mix(b, s.felt(N(bass), 0.9, level=0.22), t0 + k * BEAT)
        s.mix(b, s.thump(62, 0.25, level=0.12), t0 + k * BEAT)
# позывные «прогноза» на старте и после каждого прогноза
for t0 in (0.05, 13.45):
    for i, x in enumerate(["G5", "B5", "D6", "G6"]):
        s.mix(b, s.bell(N(x), 1.6, level=0.05), t0 + i * 0.11, pan=-0.3 + 0.2 * i)
s.mix(b, s.whoosh(0.22, 900, 3000, level=0.05), 0.3, pan=-0.3)  # взмах
s.mix(b, s.whoosh(0.22, 900, 3000, level=0.05), 0.78, pan=-0.3)
# солнце выплывает на «ясно»
s.mix(b, s.whoosh(0.7, 300, 1500, level=0.06), 2.1, pan=0.3)
for i, x in enumerate(["D6", "G6"]):
    s.mix(b, s.sparkle(s.note(x), 0.6, level=0.04), 2.5 + 0.12 * i, pan=0.3)
# выходные: облако и тихий снег — мягкий шорох и редкие «динь»
s.mix(b, s.whoosh(0.7, 300, 1200, level=0.05), 5.95, pan=0.3)
n = int(6.8 * s.SR)
snow = s.lowpass(s.noise(n), 2500)
envl = np.interp(np.arange(n) / s.SR, [0, 0.8, 6.0, 6.8], [0, 1, 0.8, 0])
s.mix(b, snow * envl * 0.018, 6.2)
rng = np.random.default_rng(3)
for t0 in np.sort(rng.uniform(6.4, 12.6, 14)):
    s.mix(b, s.bell(float(rng.choice([1568.0, 1976.0, 2349.0, 2637.0])), 1.2, level=0.022), float(t0), pan=float(rng.uniform(-0.6, 0.6)))
s.mix(b, s.pop(820, 0.12, level=0.09), 6.25)  # Тимка: «о»
# совет: кружка чая — тёплый «тук» и колокольчик
s.mix(b, s.thump(140, 0.25, level=0.14), 10.15)
s.mix(b, s.pop(1200, 0.08, level=0.06), 10.2, pan=-0.2)
s.mix(b, s.bell(N("B5"), 2.5, level=0.05), 10.6, pan=0.2)
s.mix(b, s.whoosh(0.3, 2000, 600, level=0.04), 13.2)

b = s.reverb(b, seconds=1.6, wet=0.18)
b = s.loop_wrap(b, D)
nn = int(round(length * s.SR))
if nn > b.shape[1]:
    b = np.concatenate([b, b[:, : nn - b.shape[1]]], axis=1)
b = b[:, :nn]
b = s.master_lufs(b, target=-15.0, ceiling_db=-1.5)
b = s.fade_edges(b, ms=30)  # без ступеньки в начале потока: иначе AAC даёт выброс пика
s.write(out, b)
