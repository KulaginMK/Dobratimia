// «Тимка — чат группы в 2 ночи». 13 с, петля: кадр 13,0 совпадает с кадром 0. Серия «Тимка»: без голоса.
// Тимка в кровати с телефоном, из телефона всплывают сообщения (полоски без имён и текста) → кладёт телефон
// экраном вниз, засыпает → фраза spicy-5 из «Доброго слова» дословно → тёмная пауза и снова кадр 0.
(function () {
  const { C, svg, tr, op, set } = R;
  const NIGHT = C.text; // мебель темнее фона-шоколада
  /** Ночная спальня: кровать, тумбочка, месяц, звёзды. */
  window.buildNight = function (far, g, opts = {}) {
    const moon = svg('g', { transform: 'translate(900 760)' }, far);
    svg('circle', { r: 46, fill: C.honey }, moon);
    svg('circle', { cx: 22, cy: -14, r: 41, fill: C.choco }, moon);
    const stars = [
      [150, 760, 12],
      [250, 880, 8],
      [960, 930, 9],
      [110, 1010, 9],
      [800, 700, 7],
    ].filter(([x, y]) => !opts.noStarsAbove || y > opts.noStarsAbove);
    const st = stars.map(([x, y, r]) => svg('rect', { x: -r, y: -r, width: 2 * r, height: 2 * r, rx: r * 0.2, fill: C.honey, transform: `translate(${x} ${y}) rotate(45)` }, far));
    const bed = svg('g', {}, g);
    svg('rect', { x: 130, y: 930, width: 48, height: 330, rx: 18, fill: NIGHT }, bed);
    svg('rect', { x: 130, y: 1160, width: 680, height: 66, rx: 18, fill: NIGHT }, bed);
    svg('rect', { x: 160, y: 1216, width: 32, height: 50, rx: 8, fill: NIGHT }, bed);
    svg('rect', { x: 750, y: 1216, width: 32, height: 50, rx: 8, fill: NIGHT }, bed);
    svg('rect', { x: 174, y: 1124, width: 636, height: 46, rx: 18, fill: C.soft }, bed);
    svg('ellipse', { cx: 268, cy: 1094, rx: 80, ry: 40, fill: C.white }, bed);
    const slot = svg('g', {}, g);
    svg('rect', { x: 330, y: 1096, width: 500, height: 92, rx: 32, fill: C.primary }, g);
    svg('rect', { x: 330, y: 1096, width: 500, height: 22, rx: 11, fill: C.soft, opacity: 0.4 }, g);
    svg('rect', { x: 860, y: 1110, width: 190, height: 150, rx: 16, fill: NIGHT }, g);
    svg('circle', { cx: 955, cy: 1170, r: 9, fill: C.choco }, g);
    return { slot, stars: st, moon };
  };
  /** Телефон: корпус, экран, значок счётчика. Центр (0,0), высота 150. */
  window.buildPhone = function (g) {
    const ph = svg('g', {}, g);
    const flip = svg('g', {}, ph);
    const glow = svg('circle', { r: 78, fill: C.soft, opacity: 0.1 }, flip);
    svg('rect', { x: -44, y: -75, width: 88, height: 150, rx: 16, fill: NIGHT }, flip);
    const backSide = svg('rect', { x: -40, y: -71, width: 80, height: 142, rx: 13, fill: C.primary }, flip);
    const backDot = svg('circle', { cx: -14, cy: -46, r: 9, fill: NIGHT }, flip);
    const screen = svg('rect', { x: -36, y: -66, width: 72, height: 132, rx: 10, fill: C.soft }, flip);
    const rows = svg('g', {}, flip);
    for (let i = 0; i < 5; i++) svg('rect', { x: i % 2 ? -10 : -28, y: -54 + i * 24, width: 38, height: 14, rx: 7, fill: i % 2 ? C.primary : C.white }, rows);
    const badge = svg('g', { transform: 'translate(40 -70)' }, flip);
    svg('rect', { x: -40, y: -26, width: 80, height: 52, rx: 26, fill: C.primary }, badge);
    const num = svg('text', { x: 0, y: 14, 'text-anchor': 'middle', 'font-family': 'Nunito', 'font-weight': 900, 'font-size': 38, fill: C.white }, badge);
    num.textContent = '87';
    return {
      g: ph,
      update({ x, y, rot = 0, sx = 1, n = 87, scroll = 0, screenOn = 1 }) {
        tr(ph, `translate(${x} ${y}) rotate(${rot})`);
        tr(flip, `scale(${sx} 1)`);
        const front = sx > 0;
        op(screen, front ? screenOn : 0);
        op(rows, front ? screenOn : 0);
        op(badge, front ? screenOn : 0);
        op(glow, front ? screenOn : 0);
        op(backSide, front ? 0 : 1);
        op(backDot, front ? 0 : 1);
        tr(rows, `translate(0 ${-((scroll % 48) + 48) % 48})`);
        num.textContent = String(n);
      },
    };
  };
})();

(function () {
  if (new URLSearchParams(location.search).get('still')) return;
  const { C, clamp, lerp, ease, win, svg, tr, op, set } = R;
  const D = 13;
  const TAU = Math.PI * 2;
  const per = (k) => (TAU * k) / D;
  const S = R.camStage(C.choco);
  const room = window.buildNight(S.far, S.world);
  // screen-clip для прокрутки строк — без него строки выходят за экран телефона
  const mk = (name) => {
    const g = svg('g', {}, room.slot);
    return { g, p: R.poseTimka(g, name, { noShadow: true }) };
  };
  const hello = mk('hello');
  const sleep = mk('sleep');
  const bubblesG = svg('g', {}, S.world);
  const phone = window.buildPhone(S.world);
  const clipDef = svg('clipPath', { id: 'scr', clipPathUnits: 'userSpaceOnUse' }, S.defs);

  // ---- сообщения: полоски в пузырях ----
  const rnd = ((seed) => () => ((seed = (seed * 16807) % 2147483647) - 1) / 2147483646)(11);
  const BUB = [];
  let at = 0.35;
  for (let i = 0; i < 18; i++) {
    const side = i % 2 ? 1 : -1;
    const w = 170 + Math.round(rnd() * 90);
    BUB.push({ at, w, tx: 560 + side * (40 + rnd() * 300), ty: 712 + rnd() * 130, mine: rnd() < 0.25, pop: 6.45 + rnd() * 0.5, sw: rnd() * 6 });
    at += Math.max(0.16, 0.62 - i * 0.04);
  }
  BUB.forEach((b) => {
    b.g = svg('g', {}, bubblesG);
    const fill = b.mine ? C.soft : C.white;
    svg('rect', { x: -b.w / 2, y: -34, width: b.w, height: 68, rx: 26, fill }, b.g);
    svg('path', { d: `M${-b.w / 2 + 18} 22 L${-b.w / 2 + 6} 44 L${-b.w / 2 + 40} 30 Z`, fill }, b.g);
    svg('rect', { x: -b.w / 2 + 24, y: -18, width: b.w * 0.62, height: 13, rx: 6.5, fill: C.choco, opacity: 0.3 }, b.g);
    svg('rect', { x: -b.w / 2 + 24, y: 5, width: b.w * 0.4, height: 13, rx: 6.5, fill: C.choco, opacity: 0.3 }, b.g);
  });

  // ---- тексты ----
  const chip = (text, y) => {
    const d = R.div({ style: { position: 'absolute', left: '0', top: y + 'px', width: '1080px', textAlign: 'center' } }, S.ui);
    R.div({ style: { display: 'inline-block', padding: '12px 34px', borderRadius: '999px', background: C.soft, color: C.onSoft, font: "600 42px 'Golos Text'", lineHeight: '52px' }, html: text }, d);
    return d;
  };
  const pov = chip('POV', 300);
  const hook = R.textBlock(S.ui, { text: '2:00, в чате группы\n87 новых сообщений', y: 390, w: 1000, size: 84, line: 98, color: C.white, words: true });
  const kind = chip('Доброе слово', 300);
  const phrase = R.textBlock(S.ui, { text: 'Отвечать в чате группы\nв два часа ночи\nнеобязательно.', y: 390, w: 1000, size: 76, line: 90, color: C.white, words: true });
  const phrase2 = R.textBlock(S.ui, { text: 'Чат переживёт.', y: 1480, w: 1000, size: 84, line: 98, color: C.soft, words: true });
  const dip = R.div({ style: { position: 'absolute', left: '0', top: '0', width: '1080px', height: '1920px', background: C.choco } }, S.ui);

  const TX = 520;
  const TY = 990;
  const TS = 360;
  const SWAP = 7.35;

  window.renderAt = function (tRaw) {
    const t = Math.round((((tRaw % D) + D) % D) * 1e6) / 1e6;
    // ---- камера: близко к Тимке и телефону, приподнимается за сообщениями, отъезжает, когда телефон лёг ----
    const up = ease.inOutSine(clamp((t - 0.8) / 5.4));
    const back = ease.inOutSine(clamp((t - 6.3) / 1.2));
    const rest = ease.inOutSine(clamp((t - 7.6) / 4.6));
    const reset = ease.inOutSine(clamp((t - 12.35) / 0.25));
    let cx = lerp(lerp(600, 590, up), 590, back);
    let cy = lerp(lerp(1000, 950, up), 1020, back);
    let z = lerp(lerp(1.22, 1.12, up), 1.0, back) + 0.1 * rest;
    cx = lerp(cx, 600, reset);
    cy = lerp(cy, 1000, reset);
    z = lerp(z, 1.22, reset);
    R.camApply(S, { cx, cy, z, x: 5 * Math.sin(per(2) * t), y: 4 * Math.sin(per(1) * t + 1), r: 0.3 * Math.sin(per(1) * t) }, 0.4);
    room.stars.forEach((s, i) => op(s, 0.45 + 0.4 * (0.5 + 0.5 * Math.sin(per(4 + i) * t + i))));

    // ---- телефон: в лапке → кладётся на тумбочку экраном вниз ----
    const hold = { x: 722, y: 990, rot: -8 };
    // с 12,6 (под тёмной паузой) — снова кадр 0: телефон в лапке, экраном к Тимке
    const k = t >= 12.6 ? 0 : ease.inOutSine(clamp((t - 6.35) / 0.75));
    const flipK = t >= 12.6 ? 0 : clamp((t - 6.55) / 0.35);
    const shown = BUB.filter((b) => t >= b.at && t < 12.35).length;
    phone.update({
      x: lerp(hold.x, 955, k),
      y: lerp(hold.y, 1100, k) - 120 * Math.sin(Math.PI * k),
      rot: lerp(hold.rot, 90, k),
      sx: Math.cos(Math.PI * flipK) * 0.999 + (flipK >= 1 ? -0.001 : 0.001),
      n: 87 + shown,
      scroll: 160 * t,
      screenOn: 1,
    });

    // ---- сообщения ----
    BUB.forEach((b, i) => {
      const x = t - b.at;
      if (x < 0 || t >= 12.35) return op(b.g, 0);
      const fly = ease.outCubic(clamp(x / 0.55));
      const popK = clamp((t - b.pop) / 0.18);
      const s = (0.3 + 0.7 * ease.outCubic(clamp(x / 0.35))) * (1 + 0.15 * Math.sin(Math.PI * popK)) * (1 - ease.inCubic(popK));
      if (s <= 0.001) return op(b.g, 0);
      op(b.g, 1);
      const bx = lerp(hold.x, b.tx, fly) + 8 * Math.sin(per(3) * t + b.sw);
      const by = lerp(hold.y - 60, b.ty, fly) - 70 * fly * Math.sin(Math.PI * fly);
      tr(b.g, `translate(${bx} ${by}) scale(${s})`);
    });

    // ---- Тимка: hello с телефоном → сжатие → sleep ----
    const sq = t >= SWAP - 0.1 && t < SWAP ? ease.inCubic((t - (SWAP - 0.1)) / 0.1) * 0.12 : t >= SWAP && t < SWAP + 0.16 ? (1 - ease.outCubic((t - SWAP) / 0.16)) * 0.12 : 0;
    const asleep = t >= SWAP && t < 12.6;
    op(hello.g, asleep ? 0 : 1);
    op(sleep.g, asleep ? 1 : 0);
    const breathe = 0.5 - 0.5 * Math.cos(per(4) * t);
    if (!asleep) {
      // взгляд за всплывающими сообщениями, лапка держит телефон, потом опускается
      const last = BUB.filter((b) => t >= b.at).pop();
      const look = last && t < 6.4 ? clamp(1 - (t - last.at) / 0.6) : 0;
      const ex = t < 6.4 ? lerp(3, -1, look) : lerp(3, 0, clamp((t - 6.4) / 0.3));
      const ey = t < 6.4 ? lerp(1.5, -3, look) : 0;
      const handRot = -48 * (1 - k) - 20 * win(t, 6.35, 6.6, 6.9, 7.2);
      hello.p.update({ t, x: TX, y: TY, size: TS, squash: sq, sway: 3 * Math.sin(per(3) * t), wave: handRot + 48, blink: R.blinkAt(t, D / 5, 0.7) });
      const bl = R.blinkAt(t, D / 5, 0.7);
      tr(hello.p.parts.eyes, `translate(${ex} ${ey}) translate(60 64) scale(1 ${bl}) translate(-60 -64)`);
    } else {
      sleep.p.update({ t, x: TX, y: TY + 6, size: TS, squash: sq, lift: 0.015 * breathe, sway: 2 * Math.sin(per(3) * t), zzz: breathe });
      op(sleep.p.parts.zzz, ease.inOutSine((t - 7.6) / 0.5) * (1 - 0.4 * breathe));
    }

    // ---- тексты ----
    op(pov, t >= 12.6 ? 1 : t < 6.5 ? 1 - ease.inOutSine((t - 6.2) / 0.3) : 0);
    op(hook, t >= 12.6 ? 1 : t < 6.5 ? 1 - ease.inOutSine((t - 6.2) / 0.3) : 0);
    R.wordsIn(hook, 1);
    const pIn = clamp((t - 7.8) / 1.0);
    op(kind, t > 7.7 && t < 12.6 ? ease.inOutSine((t - 7.7) / 0.3) : 0);
    op(phrase, t > 7.8 && t < 12.6 ? 1 : 0);
    R.wordsIn(phrase, pIn, { spread: 0.6 });
    op(phrase2, t > 9.6 && t < 12.6 ? 1 : 0);
    R.wordsIn(phrase2, clamp((t - 9.6) / 0.5), { spread: 0.3 });
    // тёмная пауза-шов: 12,35 → 12,6 темнеет, 12,6 → 13,0 открывается кадр 0
    const d = t < 12.35 ? 0 : t < 12.6 ? ease.inOutSine((t - 12.35) / 0.25) : 1 - ease.inOutSine((t - 12.6) / 0.4);
    op(dip, d);
  };

  R.ready().then(() => {
    window.READY = true;
  });
})();
