"""Звук «чат группы в 2 ночи»: ночной пэд, частые «пинги» сообщений, телефон ложится на тумбочку, тишина и колыбельная; всё синтезировано кодом.
python3 reels/r11/audio.py out/audio.wav [длительность]"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "engine"))
import numpy as np
import synth as s
from synth import note as N

D = 13.0
out = sys.argv[1]
length = float(sys.argv[2]) if len(sys.argv) > 2 else D
b = s.buf(D + 6)

# моменты сообщений — как в сцене (18 пузырей, интервал сокращается)
at, ats = 0.35, []
for i in range(18):
    ats.append(at)
    at += max(0.16, 0.62 - i * 0.04)

s.mix(b, s.sine_pad([N(x) for x in ["E2", "B2", "G3", "D4"]], 7.0, attack=0.6, release=1.5, level=0.06), -0.3)
notes = ["E5", "G5", "B5", "D6", "A5", "F#5"]
for i, a in enumerate(ats):
    s.mix(b, s.pop(900 + 120 * (i % 4), 0.08, level=0.07), a, pan=0.3 if i % 2 else -0.3)
    s.mix(b, s.sparkle(s.note(notes[i % len(notes)]), 0.35, level=0.035 + 0.002 * i), a + 0.01, pan=0.3 if i % 2 else -0.3)
# телефон ложится экраном вниз
s.mix(b, s.whoosh(0.5, 1800, 400, level=0.05), 6.35)
for i in range(18):
    s.mix(b, s.pop(1400 - 40 * i, 0.06, level=0.03), 6.45 + 0.03 * i, pan=0.2 * ((-1) ** i))
s.mix(b, s.thump(120, 0.3, level=0.28), 7.08, pan=0.3)
# засыпает
s.mix(b, s.felt(N("E3"), 2.0, level=0.10), 7.35)
s.mix(b, s.sine_pad([N(x) for x in ["C2", "G2", "E3", "B3"]], 5.6, attack=1.0, release=1.6, level=0.07), 7.4)
for x, t0 in [("G5", 7.9), ("E5", 8.4), ("B4", 8.9), ("C5", 9.6), ("E5", 10.1), ("D5", 10.8)]:
    s.mix(b, s.bell(N(x), 2.5, level=0.055), t0, pan=0.25)
    s.mix(b, s.pluck(N(x) / 2, 1.8, bright=0.2, level=0.04), t0, pan=-0.25)
s.mix(b, s.whoosh(0.4, 600, 200, level=0.03), 12.35)

b = s.reverb(b, seconds=2.4, wet=0.28)
b = s.loop_wrap(b, D)
n = int(round(length * s.SR))
if n > b.shape[1]:
    b = np.concatenate([b, b[:, : n - b.shape[1]]], axis=1)
b = b[:, :n]
b = s.master_lufs(b, target=-17.0, ceiling_db=-1.5)
b = s.fade_edges(b, ms=30)
s.write(out, b)
