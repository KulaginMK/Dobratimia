// Обложка и кадр сторис: ночь, Тимка с телефоном, пузыри сообщений.
(function () {
  const kind = new URLSearchParams(location.search).get('still');
  if (!kind) return;
  const { C, svg } = R;
  const S = R.stage(C.choco);
  const scene = (tf, bubbles) => {
    const far = svg('g', { transform: tf }, S.world);
    const g = svg('g', { transform: tf }, S.world);
    const room = window.buildNight(far, g, { noStarsAbove: 0 });
    const p = R.poseTimka(room.slot, 'hello', { noShadow: true });
    p.update({ t: 0, x: 520, y: 990, size: 360, wave: 0 });
    p.parts.eyes.setAttribute('transform', 'translate(3 -2)');
    const ph = window.buildPhone(g);
    ph.update({ x: 722, y: 990, rot: -8, n: 87 });
    for (const [x, y, w, mine] of bubbles) {
      const b = svg('g', { transform: `translate(${x} ${y})` }, g);
      const fill = mine ? C.soft : C.white;
      svg('rect', { x: -w / 2, y: -34, width: w, height: 68, rx: 26, fill }, b);
      svg('path', { d: `M${-w / 2 + 18} 22 L${-w / 2 + 6} 44 L${-w / 2 + 40} 30 Z`, fill }, b);
      svg('rect', { x: -w / 2 + 24, y: -18, width: w * 0.62, height: 13, rx: 6.5, fill: C.choco, opacity: 0.3 }, b);
      svg('rect', { x: -w / 2 + 24, y: 5, width: w * 0.4, height: 13, rx: 6.5, fill: C.choco, opacity: 0.3 }, b);
    }
  };
  const B = [[330, 760, 220, 0], [760, 740, 200, 1], [470, 830, 180, 0], [880, 840, 170, 0], [250, 880, 160, 1]];
  if (kind === 'cover') {
    R.chip(S, { text: 'POV', y: 300 });
    R.textBlock(S.text, { text: '2:00, в чате группы\n87 новых сообщений', y: 390, w: 1000, size: 84, line: 98, color: C.white });
    scene('translate(540 1080) scale(1.1) translate(-560 -960)', B);
    R.textBlock(S.text, { text: 'Чат переживёт.', y: 1500, size: 64, line: 76, color: C.soft });
  } else {
    R.wordmark(S, { y: 300, h: 76, color: C.white, mark: 'logo-mark-white' });
    R.textBlock(S.text, { text: 'Отвечаете в чате\nпосле полуночи?', y: 440, size: 88, line: 102, w: 1000, color: C.white });
    scene('translate(540 980) scale(0.6) translate(-560 -960)', B);
    R.textBlock(S.text, { text: 'Ответьте в опросе ниже', y: 1250, size: 44, line: 56, font: 'text', weight: 600, color: C.soft });
  }
  window.renderAt = () => {};
  R.ready().then(() => (window.READY = true));
})();
