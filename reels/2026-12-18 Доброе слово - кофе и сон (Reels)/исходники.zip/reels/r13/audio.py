"""Звук «Доброе слово — кофе и сон»: лёгкий грув 100 уд/мин, соль мажор; всё синтезировано кодом.
python3 reels/r3/audio.py out/audio.wav [длительность]"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "engine"))
import numpy as np
import synth as s
from synth import note as N

D = 18.0
out = sys.argv[1]
length = float(sys.argv[2]) if len(sys.argv) > 2 else D
BEAT = 0.6  # 100 уд/мин; сильная доля «С перчиком» — 8,2 с, «Сахарный» — 3,4 с
b = s.buf(D + 4)

def shaker(at, level=0.03):
    n = int(0.045 * s.SR)
    x = s.highpass(s.noise(n), 5000) * np.exp(-np.arange(n) / s.SR * 70)
    s.mix(b, x * level, at, pan=0.25)

def bar(t0, chord, bass, spicy=False):
    # арпеджио маримбы восьмыми, бас на 1 и 3, лёгкий удар, шейкер
    for k in range(8):
        f = N(chord[k % len(chord)])
        dur = 0.5 if spicy else 1.4
        lv = 0.11 if k % 2 == 0 else 0.08
        s.mix(b, s.pluck(f, dur, bright=0.75 if spicy else 0.55, level=lv), t0 + k * BEAT / 2, pan=-0.3 + 0.6 * ((k % 4) / 3))
        shaker(t0 + k * BEAT / 2 + BEAT / 4, 0.025 if k % 2 else 0.018)
    for k in (0, 2):
        s.mix(b, s.felt(N(bass), 1.0, level=0.22), t0 + k * BEAT)
        s.mix(b, s.thump(58, 0.3, level=0.16), t0 + k * BEAT)
    if spicy:
        for k in (1, 3):
            s.mix(b, s.tick(2400, 0.05, level=0.06), t0 + k * BEAT, pan=-0.2)

# ---- A: три чашки опускаются на стол ----
s.mix(b, s.pluck(N("D4"), 2.0, bright=0.3, level=0.12), 0.05)
for i, at in enumerate([0.45, 0.85, 1.25]):
    s.mix(b, s.thump(120 - 15 * i, 0.3, level=0.30 + 0.06 * i), at)
    s.mix(b, s.pop(1300 + 200 * i, 0.07, level=0.08), at + 0.01, pan=-0.3 + 0.3 * i)  # фарфор звякнул
    s.mix(b, s.felt(N(["B2", "A2", "G2"][i]), 1.2, level=0.12), at)
# ---- B: интерфейс въезжает ----
s.mix(b, s.whoosh(0.8, 250, 2600, level=0.07), 2.6)
for i, x in enumerate(["G4", "B4", "D5"]):
    s.mix(b, s.pluck(N(x), 1.2, level=0.09), 2.95 + i * 0.12)
# ---- C: «Сахарный» ----
sweet = [(["G3", "B3", "D4", "F#4"], "G2"), (["E3", "G3", "B3", "D4"], "E2")]
for i in range(2):
    ch, bs = sweet[i % 2]
    bar(3.4 + i * 4 * BEAT, ch, bs)
for i, x in enumerate(["B5", "D6", "F#5", "G5", "B5"]):  # челеста на появлении слов
    s.mix(b, s.bell(N(x), 2.0, level=0.05), 3.4 + i * 0.22, pan=0.3)
s.mix(b, s.pad([N(x) for x in ["G3", "B3", "D4", "F#4"]], 5.0, attack=0.8, release=1.2, level=0.05), 3.3)
# ---- D: касание и раскрытие ----
s.mix(b, s.tick(3200, 0.04, level=0.12), 7.85)
s.mix(b, s.whoosh(0.6, 400, 3000, level=0.08), 8.0)
t = s.tt(0.18)
fwip = np.sin(2 * np.pi * np.cumsum(400 * (4 ** (t / 0.18))) / s.SR) * np.exp(-t * 8) * 0.12  # «перчёный» подъём
s.mix(b, fwip, 8.5, pan=0.2)
s.mix(b, s.sparkle(2600, 0.6, level=0.05), 8.62, pan=0.4)
# ---- E: «С перчиком» ----
spicy = [(["G3", "B3", "D4", "F4"], "G2"), (["C4", "E4", "G4", "A#4"], "C3"), (["G3", "B3", "D4", "F4"], "G2")]
for i in range(3):
    ch, bs = spicy[i]
    bar(8.2 + i * 4 * BEAT, ch, bs, spicy=True)
for t0 in (10.6, 13.0):
    s.mix(b, s.sparkle(2800, 0.5, level=0.035), t0 + 0.3, pan=0.4)
# ---- F: финал ----
s.mix(b, s.whoosh(0.7, 2200, 300, level=0.06), 14.35)
s.mix(b, s.pad([N(x) for x in ["G2", "D3", "A3", "B3", "F#4"]], 3.8, attack=0.6, release=1.5, level=0.08), 14.6)
for t0 in (15.3, 16.5):
    s.mix(b, s.tick(3200, 0.04, level=0.10), t0)
s.mix(b, s.bell(N("G5"), 3.0, level=0.07), 15.4)
s.mix(b, s.bell(N("D6"), 3.0, level=0.06), 16.0, pan=0.3)
s.mix(b, s.bell(N("B5"), 3.0, level=0.06), 16.6, pan=-0.3)
for i, x in enumerate(["G4", "B4", "D5", "G5"]):
    s.mix(b, s.pluck(N(x), 2.0, level=0.08), 16.6 + i * 0.15)

b = s.reverb(b, seconds=1.8, wet=0.2)
n = int(round(length * s.SR))
b = s.fit(b, length)
fade = int(0.6 * s.SR)
b[:, -fade:] *= np.linspace(1, 0, fade) ** 2
b = s.master_lufs(b, target=-15.0, ceiling_db=-1.5)
s.write(out, b)
