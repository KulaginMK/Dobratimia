# 2026-12-18 Доброе слово - кофе и сон (Reels) — исходники

Всё, чтобы пересобрать ролик с нуля: анимация (HTML/SVG + JavaScript), звук (Python, синтез кодом), сборка (ffmpeg).
Музыки, сэмплов и голоса со стороны нет: каждый звук генерируется в `reels/r13/audio.py` через `engine/synth.py`.

## Что нужно

- Node.js 18+ и Playwright с Chromium (проверено на Playwright 1.63): `npm install playwright` и `npx playwright install chromium`
- Python 3.10+ (проверено на numpy 2.5, scipy 1.18, Pillow 12.3): `pip install numpy scipy pillow`
- ffmpeg 6+ с libx264 и aac

## Сборка

```bash
bash engine/build.sh r13 1081 3
```

Результат появится в `out/r13/`: `reels.mp4`, `обложка.png`, `сторис_1.png`, `sheet.png` (лист контрольных кадров).

Параметры: 1081 кадров при 60 к/с = 18.017 с; 3 подкадр(а) на кадр — motion blur с выдержкой 180°.


## Как это устроено

- `reels/r13/scene.js` — сцена: функция `renderAt(t)` рисует кадр в момент t секунд. Время — единственный источник правды, кадры можно снимать в любом порядке.
- `reels/r13/stills.js` — обложка (`?still=cover`) и кадр сторис (`?still=story`).
- `reels/r13/audio.py` — партитура: аккорды, мотивы, звуки событий по тем же таймкодам, что в сцене.
- `reels/r13/раскадровка.md` — варианты по сценам и что выбрано.
- `engine/lib.js` — общая библиотека: палитра бренда, кривые, текст, камера, Тимка. Дыхание Тимки перенесено из `expo-app/src/components/brand/Timka.tsx` (спецификация «Тимка · дыхание» 1.0).
- `engine/render.js` — покадровый рендер в Chromium, несколько параллельных работников, видео без потерь.
- `engine/mux.sh` — итоговое кодирование: H.264 High, yuv420p, BT.709, постоянный квантователь 16, AAC 192 кбит/с, `+faststart`.
- `engine/check.py` — проверка готового файла: параметры, кадры, совпадение кадров петли, громкость.
- `assets/` — SVG Тимки и знака из `handoff/assets/svg/` без изменений. `engine/fonts/` — Nunito 900 и Golos Text 400/600 (@fontsource, лицензия OFL).

Открыть сцену в браузере для просмотра: `reels/r13/scene.html` (в консоли `renderAt(5)` покажет кадр на 5-й секунде).
