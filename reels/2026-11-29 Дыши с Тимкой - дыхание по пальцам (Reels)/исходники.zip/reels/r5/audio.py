"""Звук «Дыхание по пальцам»: эмбиент ля мажор, аккорд на каждый палец; всё синтезировано кодом.
python3 reels/r5/audio.py out/audio.wav [длительность]"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "engine"))
import numpy as np
import synth as s
from synth import note as N

D = 52.0
out = sys.argv[1]
length = float(sys.argv[2]) if len(sys.argv) > 2 else D
START = 6.0
b = s.buf(D + 8)

# ---- хук: волнение — частое мягкое «сердце» в такт мелкому дыханию Тимки ----
beat = D / 70
k = 0
while k * beat < 2.9:
    s.mix(b, s.thump(75, 0.25, level=0.10 if k % 2 == 0 else 0.06), k * beat)
    k += 1
s.mix(b, s.pad([N(x) for x in ["A2", "E3", "B3", "C#4"]], 4.5, attack=0.3, release=1.5, level=0.06), 0)
# ---- дверь уезжает, контур прорисовывается ----
s.mix(b, s.whoosh(0.8, 300, 2200, level=0.06), 3.0)
for i, x in enumerate(["A4", "C#5", "E5", "A5", "C#6"]):
    s.mix(b, s.pluck(N(x), 2.0, bright=0.4, level=0.07), 3.6 + i * 0.32, pan=-0.4 + 0.2 * i)
s.mix(b, s.pop(700, 0.12, level=0.10), 5.3)

# ---- пять пальцев ----
chords = [["A2", "E3", "A3", "C#4"], ["F#2", "C#3", "A3", "E4"], ["D2", "A2", "F#3", "A3"], ["E2", "B2", "G#3", "B3"], ["A2", "E3", "C#4", "E4"]]
for i, ch in enumerate(chords):
    t0 = START + 8 * i
    s.mix(b, s.pad([N(x) for x in ch], 9.6, attack=1.4, release=1.8, bright=1300, level=0.07), t0 - 0.8)
    s.mix(b, s.breath(4.0, "in", level=0.07), t0)
    s.mix(b, s.felt(N("E4"), 2.6, level=0.08), t0, pan=-0.2)
    s.mix(b, s.felt(N("A4"), 2.6, level=0.07), t0 + 1.6, pan=0.2)
    s.mix(b, s.pluck(N("E5"), 1.6, bright=0.3, level=0.06), t0 + 4.0, pan=0.3)  # кончик пальца
    s.mix(b, s.breath(4.0, "out", level=0.08), t0 + 4.0)
    s.mix(b, s.felt(N("C#4"), 2.6, level=0.07), t0 + 4.2, pan=0.1)
    s.mix(b, s.felt(N("A3"), 2.6, level=0.07), t0 + 6.0, pan=-0.1)
    s.mix(b, s.pluck(N("A3"), 1.4, bright=0.2, level=0.05), t0 + 8.0 - 0.02, pan=-0.3)  # впадина
# ---- финал ----
s.mix(b, s.pad([N(x) for x in ["A2", "E3", "B3", "C#4", "E4"]], 6.5, attack=1.0, release=2.0, level=0.07), 45.8)
for i, x in enumerate(["A5", "C#6", "E6"]):
    s.mix(b, s.bell(N(x), 3.5, level=0.05), 46.0 + i * 0.18, pan=-0.3 + 0.3 * i)
s.mix(b, s.bell(N("A6"), 3.0, level=0.035), 48.0)
s.mix(b, s.whoosh(0.8, 1800, 300, level=0.05), 51.25)

b = s.reverb(b, seconds=2.6, wet=0.28)
b = s.loop_wrap(b, D)
n = int(round(length * s.SR))
if n > b.shape[1]:
    b = np.concatenate([b, b[:, : n - b.shape[1]]], axis=1)
b = b[:, :n]
b = s.master_lufs(b, target=-17.0, ceiling_db=-1.5)
s.write(out, b)
