// «Дыши с Тимкой — дыхание по пальцам». 52 с, петля: кадр 52,0 совпадает с кадром 0.
(function () {
  const STILL = new URLSearchParams(location.search).get('still');
  const { C, clamp, lerp, ease, win, keys, svg, tr, op, set } = R;
  const D = 52;
  const TAU = Math.PI * 2;
  const per = (k) => (TAU * k) / D;
  const S = R.stage(C.bg);
  const far = svg('g', {}, S.world);
  const scene = svg('g', {}, S.world);
  const ui = svg('g', {}, S.world);

  // ---- дальний план ----
  const blobs = [
    [110, 430, 230, C.soft, 0.5],
    [1010, 1260, 170, C.growthSoft, 0.85],
    [70, 1700, 270, C.soft, 0.42],
    [990, 280, 120, C.growthSoft, 0.7],
  ].map(([x, y, r, c, o]) => ({ x, y, n: svg('circle', { cx: x, cy: y, r, fill: c, opacity: o }, far) }));

  // ---- ладонь: пальцы-капсулы, контур — путь для пальца зрителя ----
  const V = (x, y) => ({ x, y });
  const add = (a, b) => V(a.x + b.x, a.y + b.y);
  const sub = (a, b) => V(a.x - b.x, a.y - b.y);
  const mul = (a, k) => V(a.x * k, a.y * k);
  const len = (a) => Math.hypot(a.x, a.y);
  const nrm = (a) => mul(a, 1 / len(a));
  const P = (p) => `${p.x.toFixed(2)} ${p.y.toFixed(2)}`;
  const FINGERS = [
    { B: V(350, 1260), T: V(205, 1000), r: 58 }, // большой
    { B: V(415, 1100), T: V(360, 725), r: 52 },
    { B: V(510, 1090), T: V(512, 655), r: 55 },
    { B: V(605, 1100), T: V(650, 705), r: 51 },
    { B: V(690, 1130), T: V(775, 830), r: 45 }, // мизинец
  ].map((f) => {
    const u = nrm(sub(f.T, f.B));
    const L = V(u.y, -u.x); // влево от направления «вверх по пальцу»
    return { ...f, u, L, lb: add(f.B, mul(L, f.r)), lt: add(f.T, mul(L, f.r)), rt: sub(f.T, mul(L, f.r)), rb: sub(f.B, mul(L, f.r)), apex: add(f.T, mul(u, f.r)) };
  });
  // пересечение правого края пальца i и левого края пальца i+1 — «впадина»
  function cross(p, d, q, e) {
    const den = d.x * e.y - d.y * e.x;
    const k = ((q.x - p.x) * e.y - (q.y - p.y) * e.x) / den;
    return add(p, mul(d, k));
  }
  const WRIST_L = V(400, 1480);
  const WRIST_R = V(665, 1480);
  let d = `M${P(WRIST_L)} C385 1420 300 1360 ${P(FINGERS[0].lb)}`;
  const keysAt = []; // строки пути до ключевых точек: вершина пальца, впадина
  const valleys = [];
  FINGERS.forEach((f, i) => {
    d += ` L${P(f.lt)} A${f.r} ${f.r} 0 0 1 ${P(f.apex)}`;
    keysAt.push(d);
    d += ` A${f.r} ${f.r} 0 0 1 ${P(f.rt)}`;
    if (i < FINGERS.length - 1) {
      const g = FINGERS[i + 1];
      const X = cross(f.rt, mul(f.u, -1), g.lt, mul(g.u, -1));
      const p1 = add(X, mul(f.u, 26));
      const p2 = add(X, mul(g.u, 26));
      const m = add(add(mul(p1, 0.25), mul(X, 0.5)), mul(p2, 0.25));
      d += ` L${P(p1)} Q${P(mul(add(p1, X), 0.5))} ${P(m)}`;
      keysAt.push(d);
      d += ` Q${P(mul(add(X, p2), 0.5))} ${P(p2)}`;
      valleys.push(X);
    } else {
      d += ` L${P(f.rb)} C775 1250 720 1440 ${P(WRIST_R)}`;
      keysAt.push(d);
    }
  });
  const handG = svg('g', {}, scene);
  // силуэт руки (контур, замкнутый по запястью): заливки не выходят за него
  const hc = svg('clipPath', { id: 'handClip', clipPathUnits: 'userSpaceOnUse' }, S.defs);
  svg('path', { d: d + ' Z' }, hc);
  const fillsG = svg('g', { 'clip-path': 'url(#handClip)' }, handG);
  // заливки: ладонь и пальцы (плоские, без обводки)
  const palmD = `M${P(WRIST_L)} C385 1420 300 1360 ${P(FINGERS[0].lb)} L${P(FINGERS[0].B)} ${valleys.map(P).map((s) => 'L' + s).join(' ')} L${P(FINGERS[4].B)} L${P(FINGERS[4].rb)} C775 1250 720 1440 ${P(WRIST_R)} Z`;
  const palm = svg('path', { d: d + ' Z', fill: C.soft }, fillsG); // в финале заливается весь силуэт
  const fingerFills = FINGERS.map((f, i) => {
    // заливка начинается у линии впадин (ниже — ладонь): проекция соседних впадин на ось пальца
    const near = [valleys[i - 1], valleys[i]].filter(Boolean).map((X) => (X.x - f.B.x) * f.u.x + (X.y - f.B.y) * f.u.y);
    const b0 = add(f.B, mul(f.u, Math.min(...near) - 12));
    const cp = svg('clipPath', { id: 'fc' + i, clipPathUnits: 'userSpaceOnUse' }, S.defs);
    const poly = svg('polygon', { points: '' }, cp);
    const n = svg('path', { d: `M${P(add(b0, mul(f.L, f.r)))} L${P(f.lt)} A${f.r} ${f.r} 0 0 1 ${P(f.rt)} L${P(sub(b0, mul(f.L, f.r)))} Z`, fill: C.soft, 'clip-path': `url(#fc${i})` }, fillsG);
    return { f, b0, poly, n, h: len(sub(f.T, b0)) + f.r };
  });
  const track = svg('path', { d, fill: 'none', stroke: C.primary, 'stroke-width': 14, 'stroke-linecap': 'round', 'stroke-linejoin': 'round', opacity: 0.28 }, handG);
  const traced = svg('path', { d, fill: 'none', stroke: C.primary, 'stroke-width': 14, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, handG);
  const dotRing = svg('circle', { r: 34, fill: C.primary, opacity: 0.18 }, handG);
  const dot = svg('circle', { r: 21, fill: C.choco }, handG);
  const TOTAL = track.getTotalLength();
  const tmp = svg('path', {}, S.defs);
  const K = [0];
  keysAt.forEach((s) => {
    set(tmp, { d: s });
    K.push(tmp.getTotalLength());
  });
  K[K.length - 1] = TOTAL;

  // ---- дверь зачёта ----
  const door = svg('g', {}, scene);
  svg('rect', { x: 650, y: 740, width: 300, height: 690, rx: 26, fill: C.choco }, door);
  svg('rect', { x: 705, y: 830, width: 190, height: 84, rx: 16, fill: C.bg }, door);
  svg('circle', { cx: 690, cy: 1110, r: 15, fill: C.honey }, door);
  const sign = R.textBlock(S.text, { text: 'Зачёт', y: 846, x: 705, w: 190, size: 44, line: 52, color: C.text });

  // ---- Тимка в маленьком дыхательном круге ----
  const tkC = svg('circle', { cx: 0, cy: 0, r: 150, fill: C.soft }, scene);
  const tkG = svg('g', {}, scene);
  const tk = R.breathingTimka(tkG);

  // ---- интерфейс ----
  const dots = [0, 1, 2, 3, 4].map((i) => svg('circle', { cx: 540 + (i - 2) * 66, cy: 1532, r: 14, fill: C.soft }, ui));
  const mark = R.logo(ui, 'logo-mark');
  const hook = R.textBlock(S.text, { text: 'Через 5 минут\nзаходить на зачёт?', y: 300, size: 84, line: 98, words: true });
  const guide = R.textBlock(S.text, { text: 'Ведите пальцем\nпо контуру ладони', y: 300, size: 80, line: 94, words: true });
  const phaseNames = ['Вдох', 'Выдох'].map((n) => R.textBlock(S.text, { text: n, y: 290, size: 80, line: 96 }));
  const digits = [];
  for (let k = 1; k <= 4; k++) digits[k] = R.textBlock(S.text, { text: String(k), y: 392, size: 150, line: 170 });
  const dizzy = R.textBlock(S.text, { text: 'Если закружилась голова,\nвернитесь к обычному дыханию', y: 1570, w: 900, font: 'text', size: 38, line: 46, color: C.text });
  const fin = R.textBlock(S.text, { text: 'Пять пальцев, пять вдохов.\nМожно незаметно в коридоре', y: 300, w: 1000, size: 64, line: 78, words: true });
  const save = R.textBlock(S.text, { text: 'Сохраните перед зачётом', y: 470, size: 46, line: 58, font: 'text', weight: 600, color: C.primary, words: true });
  const word = R.textBlock(S.text, { text: 'Добратимия', y: 1533, x: 0, w: 400, size: 44, line: 76, align: 'left' });

  // ---- время ----
  const START = 6;
  function phaseAt(t) {
    if (t < START || t >= START + 40) return null;
    const i = Math.floor((t - START) / 8);
    const x = (t - START) % 8;
    const up = x < 4;
    const px = up ? x : x - 4;
    return { i, up, x: px, left: Math.ceil(4 - px - 1e-9), t0: t - px };
  }
  function along(t) {
    const p = phaseAt(t);
    if (!p) return t < START ? 0 : TOTAL;
    const k = 2 * p.i + (p.up ? 0 : 1);
    return lerp(K[k], K[k + 1], ease.inOutSine(p.x / 4));
  }
  const faceTrack = [[0, 'in'], [3.2, 'look']];
  for (let i = 0; i < 5; i++) faceTrack.push([START + 8 * i, 'in'], [START + 8 * i + 4, 'out']);
  faceTrack.push([46.1, 'rest'], [48.2, 'look'], [51.4, 'in']);

  let probeW = 250;
  window.renderAt = function (tRaw) {
    const t = Math.round((((tRaw % D) + D) % D) * 1e6) / 1e6;
    const p = phaseAt(t);
    const s = along(t);
    const pt = track.getPointAtLength(clamp(s, 0, TOTAL));
    // ---- камера: дрейф, лёгкий подъезд и слабое следование за точкой ----
    const wF = win(t, 6, 7.5, 45, 47);
    const cam = {
      cx: 540 + 0.08 * (pt.x - 540) * wF,
      cy: 960 + 0.08 * (pt.y - 1050) * wF,
      z: 1 + 0.04 * wF * clamp((t - 6) / 40),
      x: 6 * Math.sin(per(3) * t),
      y: 5 * Math.sin(per(2) * t + 1),
      r: 0.35 * Math.sin(per(2) * t + 0.5),
    };
    tr(scene, R.camera(cam, 1));
    tr(far, R.camera(cam, 0.4));
    blobs.forEach((b, i) => set(b.n, { cy: b.y + 14 * Math.sin(per(1) * t + i * 1.9) }));

    // ---- дверь и Тимка: в хуке — у двери, дальше — в углу ----
    const toCorner = ease.inOutCubic((t - 3.1) / 1.0);
    const toDoor = ease.inOutCubic((t - 51.25) / 0.75);
    const k = t < 40 ? toCorner : 1 - toDoor;
    const doorDx = t < 40 ? 560 * ease.inCubic((t - 3.0) / 0.8) : 560 * (1 - ease.outCubic((t - 51.3) / 0.7));
    tr(door, `translate(${doorDx} 0)`);
    sign.style.transform = `translate(${doorDx * (1 + (cam.z - 1))}px, 0)`;
    op(sign, doorDx < 400 ? 1 : 0);
    const cx = lerp(380, 905, k);
    const cy = lerp(1080, 610, k);
    const size = lerp(400, 225, k);
    // наполненность: в хуке — частое мелкое дыхание (волнение), на практике — по фазам
    let L;
    if (p) L = p.up ? ease.inOutSine(p.x / 4) : 1 - ease.inOutSine(p.x / 4);
    else L = 0.35 + 0.22 * Math.sin(per(70) * t) * (1 - k);
    const circR = lerp(230, 140, k) * (0.86 + 0.14 * L);
    set(tkC, { cx, cy, r: circR });
    tk.update({ t, fill: L, face: R.faceAt(faceTrack, t), x: cx, y: cy, size, blinkEvery: D / 14, idleSpeed: per(14), noPuffs: !p });

    // ---- ладонь ----
    const handIn = ease.inOutSine((t - 3.4) / 0.6) * (1 - ease.inOutSine((t - 51.2) / 0.45));
    op(handG, handIn);
    const handS = 0.96 + 0.04 * handIn;
    tr(handG, `translate(540 1100) scale(${handS}) translate(-540 -1100)`);
    const draw = ease.inOutSine((t - 3.6) / 1.6);
    set(track, { 'stroke-dasharray': `${draw * TOTAL} ${TOTAL}` });
    set(traced, { 'stroke-dasharray': `${s} ${TOTAL + 10}`, opacity: s > 0.5 ? 1 : 0 });
    const dotIn = ease.outCubic((t - 5.3) / 0.4);
    set(dot, { cx: pt.x, cy: pt.y, r: 21 * dotIn });
    const pulse = t < START ? 0.5 + 0.5 * Math.sin((t - 5.3) * 8) : 0;
    set(dotRing, { cx: pt.x, cy: pt.y, r: (34 + 8 * pulse) * dotIn });
    fingerFills.forEach((ff, i) => {
      let h = 0;
      if (p && p.i === i) h = p.up ? ease.inOutSine(p.x / 4) : 1;
      else if ((p && p.i > i) || t >= START + 40) h = 1;
      const { f, b0 } = ff;
      const top = add(b0, mul(f.u, ff.h * h + 1));
      const pts = [add(b0, mul(f.L, 400)), sub(b0, mul(f.L, 400)), sub(top, mul(f.L, 400)), add(top, mul(f.L, 400))].map(P).join(' ');
      set(ff.poly, { points: pts });
    });
    op(palm, ease.inOutSine((t - 46.0) / 0.8));

    // ---- точки циклов ----
    const dotsO = win(t, 5.6, 6.2, 46.4, 47.0);
    dots.forEach((dd, i) => {
      const cur = p ? p.i : -1;
      const act = i === cur ? ease.outCubic((t - (START + 8 * i)) / 0.4) : 0;
      set(dd, { r: 14 + 6 * act, fill: i < cur || i === cur ? C.primary : C.soft });
      op(dd, dotsO);
    });

    // ---- тексты ----
    if (t < 3.0) {
      op(hook, 1 - ease.inOutSine((t - 2.65) / 0.3));
      R.wordsIn(hook, 1);
      hook.style.transform = `translateY(${-20 * ease.inOutSine((t - 2.65) / 0.3)}px)`;
    } else if (t >= 51.45) {
      op(hook, 1);
      R.wordsIn(hook, clamp((t - 51.45) / 0.55));
      hook.style.transform = '';
    } else op(hook, 0);
    const gIn = (t - 3.1) / 0.8;
    const gOut = clamp((t - 5.75) / 0.25);
    if (gIn > 0 && gOut < 1) {
      op(guide, 1 - gOut);
      R.wordsIn(guide, clamp(gIn), { spread: 0.45 });
      guide.style.transform = `translateY(${-18 * gOut}px)`;
    } else op(guide, 0);
    phaseNames.forEach((n, i) => {
      if (!p || (i === 0) !== p.up) return op(n, 0);
      const kk = ease.outCubic((t - p.t0) / 0.3);
      const out = ease.inOutSine(clamp((p.x - 3.8) / 0.2));
      R.place(n, { o: kk * (1 - out), y: 14 * (1 - kk) });
    });
    for (let dgt = 1; dgt <= 4; dgt++) {
      const n = digits[dgt];
      if (!p) {
        op(n, 0);
        continue;
      }
      const sec = p.x - (4 - dgt);
      if (sec < 0 || sec > 1) {
        op(n, 0);
        continue;
      }
      const kk = ease.outCubic(sec / 0.2);
      const last = dgt === 1 ? 0.2 : 0.12;
      const out = ease.inOutSine(clamp((sec - (1 - last)) / last));
      const first = dgt === 4 ? 0 : 0.5;
      R.place(n, { o: (first + (1 - first) * kk) * (1 - out), y: 10 * (1 - kk), s: 0.96 + 0.04 * kk });
    }
    R.place(dizzy, { o: win(t, 6.0, 6.8, 46.2, 47.0) });
    if (t > 46.3 && t < 51.5) {
      op(fin, 1 - ease.inOutSine((t - 51.15) / 0.3));
      R.wordsIn(fin, clamp((t - 46.4) / 1.0), { spread: 0.5 });
      op(save, 1 - ease.inOutSine((t - 51.15) / 0.3));
      R.wordsIn(save, clamp((t - 47.6) / 0.8), { spread: 0.4, rise: 20 });
    } else {
      op(fin, 0);
      op(save, 0);
    }
    const mk = win(t, 48.0, 48.7, 51.15, 51.45);
    const total = 76 + 8 + probeW;
    const x0 = 540 - total / 2;
    mark.at(x0 + 38, 1571, 76, mk);
    word.style.left = x0 + 84 + 'px';
    op(word, mk);
  };

  if (STILL) {
    // статичный макет: все пальцы закрашены, линия пройдена, тексты свои
    const base = window.renderAt;
    window.renderAt = function () {
      base(47.6);
      [hook, guide, fin, save, dizzy, word, sign].forEach((n) => op(n, 0));
      phaseNames.forEach((n) => op(n, 0));
      digits.forEach((n) => n && op(n, 0));
      mark.at(0, 0, 1, 0);
      dots.forEach((dd) => op(dd, 0));
      op(dot, 0);
      op(dotRing, 0);
      // ладонь меньше и ниже, Тимка — справа внизу, чтобы заголовок был свободен
      const k = STILL === 'cover' ? 0.86 : 0.6;
      const by = STILL === 'cover' ? 1490 : 1190;
      tr(scene, `translate(540 ${by}) scale(${k}) translate(-540 -1480)`);
      const sx = 540 + ((STILL === 'cover' ? 935 : 830) - 540) / k;
      const sy = 1480 - (by - (STILL === 'cover' ? 1330 : 1090)) / k;
      op(door, 0);
      set(tkC, { cx: sx, cy: sy, r: STILL === 'cover' ? 140 : 160 });
      tk.update({ t: 0.5, fill: 0.4, face: { kind: STILL === 'cover' ? 'rest' : 'look', from: 'rest', shift: 1 }, x: sx, y: sy, size: STILL === 'cover' ? 230 : 270, noBlink: true });
    };
    if (STILL === 'cover') {
      R.chip(S, { text: 'Дыши с Тимкой', y: 300 });
      R.textBlock(S.text, { text: 'Дыхание\nпо пальцам', y: 390, size: 108, line: 118, w: 1000 });
      R.textBlock(S.text, { text: 'Пять пальцев, пять вдохов —\nперед зачётом, прямо в коридоре', y: 1515, size: 46, line: 58, w: 980, font: 'text', weight: 600 });
    } else {
      R.wordmark(S, { y: 280, h: 76 });
      R.textBlock(S.text, { text: 'Попробовали\nдышать по пальцам?', y: 390, size: 84, line: 96, w: 1000 });
      R.textBlock(S.text, { text: 'Ответьте в опросе ниже', y: 1250, size: 44, line: 56, font: 'text', weight: 600, color: C.primary });
    }
  }
  R.ready().then(() => {
    const pr = document.createElement('span');
    pr.style.cssText = "font:900 44px 'Nunito';position:absolute;visibility:hidden;white-space:nowrap";
    pr.textContent = 'Добратимия';
    document.body.appendChild(pr);
    probeW = pr.getBoundingClientRect().width;
    pr.remove();
    window.READY = true;
  });
})();
