// Обложка (центр 1080×1350 виден в сетке профиля) и кадр сторис для репоста с местом под стикер.
(function () {
  const kind = new URLSearchParams(location.search).get('still');
  if (!kind) return;
  // берём ладонь из сцены: та же геометрия, все пальцы закрашены
  window.STILL_KIND = kind;
})();
