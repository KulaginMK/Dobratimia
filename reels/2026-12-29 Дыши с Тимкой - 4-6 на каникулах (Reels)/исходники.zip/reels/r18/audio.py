"""Звук «4-6 на каникулах»: пэд ля мажор, ноты фаз, дыхание, тихий зимний ветер; всё синтезировано кодом.
python3 reels/r8/audio.py out/audio.wav [длительность]"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "engine"))
import numpy as np
import synth as s
from synth import note as N

D = 60.0
out = sys.argv[1]
length = float(sys.argv[2]) if len(sys.argv) > 2 else D
START, CYCLE = 5.0, 10.0

b = s.buf(D + 8)

# ---- пэды: аккорд на цикл ----
chords = [
    (-1.0, 6.2, ["A2", "E3", "C#4", "E4"]),
    (4.6, 16.2, ["A2", "E3", "B3", "C#4", "E4"]),
    (14.6, 26.2, ["F#2", "C#3", "A3", "E4"]),
    (24.6, 36.2, ["D2", "A2", "F#3", "C#4", "E4"]),
    (34.6, 46.2, ["B1", "F#2", "D3", "A3", "C#4"]),
    (44.6, 56.2, ["E2", "B2", "G#3", "B3", "E4"]),
    (54.6, 62.0, ["A2", "E3", "C#4", "E4"]),
]
for a, z, ch in chords:
    s.mix(b, s.sine_pad([N(x) for x in ch], z - a, attack=2.2, release=2.8, level=0.085), a)

# ---- хук: снег за окном — редкие колокольчики ----
for i, (x, t0) in enumerate([("E5", 0.3), ("C#5", 1.1), ("A4", 1.9)]):
    s.mix(b, s.bell(N(x), 3.0, level=0.035), t0, pan=0.4 - 0.4 * i)
# схема: три ноты вверх
for i, x in enumerate(["A4", "C#5", "E5"]):
    s.mix(b, s.pluck(N(x), 2.5, bright=0.4, level=0.11), 2.95 + i * 0.22, pan=-0.2 + 0.2 * i)

# ---- пять циклов ----
for c in range(5):
    t0 = START + c * CYCLE
    s.mix(b, s.felt(N("E4"), 3.0, level=0.10), t0, pan=-0.15)
    s.mix(b, s.felt(N("A4"), 3.0, level=0.09), t0 + 0.5, pan=0.15)
    s.mix(b, s.breath(4.0, "in", level=0.075), t0)
    for i, x in enumerate(["C#5", "A4", "E4"]):
        s.mix(b, s.felt(N(x), 3.5, level=0.085), t0 + 4 + i * 0.6, pan=0.2 - 0.2 * i)
    s.mix(b, s.breath(6.0, "out", level=0.09), t0 + 4)

# ---- финал: знак и тихая мелодия ----
for x, t0 in [("E5", 55.2), ("C#5", 55.6), ("B4", 56.0), ("A4", 56.5)]:
    s.mix(b, s.bell(N(x), 3.0, level=0.06), t0, pan=0.2)
s.mix(b, s.bell(N("A5"), 4.0, level=0.035), 56.0)
s.mix(b, s.felt(N("E4"), 3.0, level=0.06), 59.35)

b = s.reverb(b, seconds=3.0, wet=0.3)
b = s.loop_wrap(b, D)

# ---- зимний ветер за окном: периодический шум длиной ровно D (фильтр в частотной области — шов без щелчка) ----
n = int(round(D * s.SR))
rng = np.random.default_rng(3)
for ch in range(2):
    X = np.fft.rfft(rng.standard_normal(n))
    f = np.fft.rfftfreq(n, 1 / s.SR)
    X *= 1 / (1 + (f / 500) ** 4) * (f > 120)
    hum = np.fft.irfft(X, n)
    hum /= np.max(np.abs(hum)) + 1e-9
    # мягкая «волна» покачивания салона: период кратен D
    tt = np.arange(n) / s.SR
    hum *= 0.6 + 0.4 * np.sin(2 * np.pi * 3 * tt / D + ch)
    b[ch] += hum * 0.02

if int(round(length * s.SR)) > b.shape[1]:
    b = np.concatenate([b, b[:, : int(round(length * s.SR)) - b.shape[1]]], axis=1)
b = b[:, : int(round(length * s.SR))]
b = s.master_lufs(b, target=-18.0, ceiling_db=-1.5)
b = s.fade_edges(b, ms=30)
s.write(out, b)
