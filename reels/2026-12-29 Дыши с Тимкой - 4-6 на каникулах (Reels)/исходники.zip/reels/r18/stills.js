// Обложка (центр 1080×1350 виден в сетке профиля) и кадр сторис для репоста с местом под стикер.
(function () {
  const kind = new URLSearchParams(location.search).get('still');
  if (!kind) return;
  const { C, svg } = R;
  const S = R.stage(C.choco);
  const busG = svg('g', {}, S.world);
  const bus = window.buildBus(busG, S.defs);
  bus.update([380, 150, 520], 0, 0.7);
  const breathing = (cx, cy, r, size) => {
    svg('circle', { cx, cy, r, fill: C.soft }, S.world);
    const tk = R.breathingTimka(svg('g', {}, S.world));
    tk.update({ t: 0.5, fill: 0.2, face: { kind: 'look', from: 'look', shift: 1 }, x: cx, y: cy, size, eyeDx: -1.5, eyeDy: -0.8, noBlink: true });
  };
  if (kind === 'cover') {
    // плашки поверх салона, окно внизу
    R.chip(S, { text: 'Дыши с Тимкой', y: 300, bg: C.soft, color: C.onSoft });
    R.textBlock(S.text, { text: '4-6', y: 380, size: 190, line: 200, color: C.white });
    R.textBlock(S.text, { text: 'на каникулах', y: 580, size: 96, line: 110, color: C.white });
    busG.setAttribute('transform', 'translate(0 120)');
    breathing(540, 1150, 270, 380);
    R.textBlock(S.text, { text: 'Пять спокойных вдохов у окна', y: 1610, size: 46, line: 58, w: 820, font: 'text', weight: 600, color: C.white });
  } else {
    R.wordmark(S, { y: 300, h: 76, color: C.white, mark: 'logo-mark-white' });
    R.textBlock(S.text, { text: 'Подышите 4-6\nна каникулах?', y: 440, size: 88, line: 102, w: 960, color: C.white });
    busG.setAttribute('transform', 'translate(540 720) scale(0.62) translate(-540 -600)');
    breathing(540, 980, 180, 250);
    R.textBlock(S.text, { text: 'Ответьте в опросе ниже', y: 1290, size: 44, line: 56, font: 'text', weight: 600, color: C.soft });
  }
  window.renderAt = () => {};
  R.ready().then(() => (window.READY = true));
})();
