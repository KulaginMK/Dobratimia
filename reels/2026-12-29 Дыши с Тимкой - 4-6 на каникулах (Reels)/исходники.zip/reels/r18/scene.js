// «Дыши с Тимкой — 4-6 на каникулах». 60 с, зимний вечер у окна, петля: кадр 60,0 совпадает с кадром 0.
// Снег за окном: три слоя (мелкий, средний, крупные мягкие хлопья), каждое смещение за 60 с кратно высоте повтора.
(function () {
  const { C, svg, tr, op } = R;
  const WIN = { x: 60, y: 600, w: 960, h: 840, rx: 60 };
  const P = 1440; // ширина повтора всех слоёв огней
  // детерминированный генератор
  const rng = (seed) => () => ((seed = (seed * 16807) % 2147483647) - 1) / 2147483646;

  /** Окно дома зимним вечером: домики с огнями и снег в три слоя. update(shift, dx): shift — смещение снега вниз по слоям. */
  window.buildBus = function (parent, defs, id = 'win') {
    const clip = svg('clipPath', { id, clipPathUnits: 'userSpaceOnUse' }, defs);
    svg('rect', { x: WIN.x, y: WIN.y, width: WIN.w, height: WIN.h, rx: WIN.rx }, clip);
    const g = svg('g', { 'clip-path': `url(#${id})` }, parent);
    svg('rect', { x: WIN.x, y: WIN.y, width: WIN.w, height: WIN.h, fill: C.text }, g);
    const bottom = WIN.y + WIN.h;
    const flakes = (seed, n, r0, r1, fill, o) => {
      const r = rng(seed);
      const lay = svg('g', {}, g);
      const inner = svg('g', {}, lay);
      for (const off of [0, -P]) {
        const sub = svg('g', { transform: `translate(0 ${off})` }, inner);
        for (let k = 0; k < n; k++) svg('circle', { cx: WIN.x - 40 + r() * (WIN.w + 80), cy: WIN.y + r() * P, r: r0 + r() * (r1 - r0), fill, opacity: o }, sub);
      }
      return { lay, inner };
    };
    const far = flakes(5, 70, 3, 6, C.white, 0.55);
    // домики: силуэты (шоколад поверх ночи), окна-огоньки, снежные шапки
    const r1 = rng(7);
    const houses = svg('g', {}, g);
    let x = -20;
    while (x < WIN.w + 40) {
      const w = Math.round(130 + r1() * 120);
      const h = Math.round(110 + r1() * 170);
      svg('rect', { x: WIN.x + x, y: bottom - h, width: w - 16, height: h + 20, fill: C.choco, opacity: 0.8 }, houses);
      svg('rect', { x: WIN.x + x - 6, y: bottom - h - 12, width: w - 4, height: 24, rx: 12, fill: C.white, opacity: 0.85 }, houses);
      for (let yy = bottom - h + 34; yy < bottom - 40; yy += 52) {
        for (let xx = x + 22; xx < x + w - 50; xx += 44) {
          if (r1() < 0.38) svg('rect', { x: WIN.x + xx, y: yy, width: 16, height: 20, rx: 3, fill: C.honey, opacity: 0.55 + 0.35 * r1() }, houses);
        }
      }
      x += w;
    }
    const mid = flakes(17, 46, 6, 10, C.white, 0.85);
    const near = flakes(29, 9, 26, 46, C.soft, 0.14);
    const layers = [far, mid, near];
    // гирлянда по верху окна: медовые огоньки (мелкий акцент)
    const bulbs = [];
    for (let k = 0; k < 13; k++) bulbs.push(svg('circle', { cx: WIN.x + 50 + k * 72, cy: WIN.y + 34 + 10 * Math.sin(k * 1.3), r: 9, fill: C.honey }, g));
    // рама: стойка и форточка — часть салона, поверх огней
    svg('rect', { x: 526, y: WIN.y, width: 28, height: WIN.h, fill: C.choco }, parent);
    svg('rect', { x: WIN.x, y: 742, width: WIN.w, height: 18, fill: C.choco }, parent);
    // подоконник
    svg('rect', { x: WIN.x - 30, y: bottom - 6, width: WIN.w + 60, height: 34, rx: 14, fill: C.primary }, parent);
    return {
      /** shift — смещение снега вниз по слоям (px), dx — сдвиг против качания камеры, tw — фаза мерцания гирлянды (рад) */
      update(shift, dx = 0, tw = 0) {
        layers.forEach((l, i) => {
          const y = ((shift[i] % P) + P) % P;
          tr(l.inner, `translate(${dx * (i + 1) * 0.5 + 14 * (i + 1) * Math.sin(tw * (i + 1) * 0.5 + i)} ${y})`);
        });
        bulbs.forEach((b, k) => op(b, 0.55 + 0.45 * Math.sin(tw * 3 + k * 1.7)));
      },
    };
  };
})();

(function () {
  if (new URLSearchParams(location.search).get('still')) return; // обложка и сторис — в stills.js
  const { C, clamp, lerp, ease, win, svg, tr, op, set } = R;
  const place = R.place;
  const D = 60;
  const TAU = Math.PI * 2;
  const per = (k) => (TAU * k) / D;
  const CX = 540;
  const CY = 1030;
  const R1 = 360; // радиус круга на полном вдохе; пустой — 0,72 от него (как в приложении)
  const TK = 430;
  const IDLE = { idleSpeed: per(18), blinkEvery: D / 17 };

  // ---- схема 4-6: пять циклов с 5 с ----
  const START = 5;
  const PH = [
    ['in', 4, 'Вдох'],
    ['out', 6, 'Выдох'],
  ];
  const CYCLE = 10;
  const N = 5;
  const END = START + N * CYCLE; // 55
  function phaseAt(t) {
    if (t < START || t >= END) return null;
    const c = Math.floor((t - START) / CYCLE);
    let x = (t - START) % CYCLE;
    for (let i = 0; i < PH.length; i++) {
      const [kind, len, name] = PH[i];
      if (x < len) return { cycle: c, i, kind, len, name, x, t0: t - x };
      x -= len;
    }
    return null;
  }
  function levelAt(t) {
    const p = phaseAt(t);
    if (!p) return 0;
    if (p.kind === 'in') return ease.inOutSine(p.x / p.len);
    return 1 - ease.inOutSine(p.x / p.len);
  }

  const S = R.stage(C.choco);
  const scene = svg('g', {}, S.world);
  const bus = window.buildBus(scene, S.defs);
  const circle = svg('circle', { cx: CX, cy: CY, r: R1 * 0.72, fill: C.soft }, scene);
  const tkG = svg('g', {}, scene);
  const tk = R.breathingTimka(tkG);
  const ui = svg('g', {}, S.world);
  const dots = [0, 1, 2, 3, 4].map((i) => svg('circle', { cx: CX + (i - 2) * 64, cy: 1500, r: 14, fill: C.soft }, ui));
  const mark = R.logo(ui, 'logo-mark-white');

  const W = C.white;
  const hook = R.textBlock(S.text, { text: 'Каникулы, а отдыхать\nне получается?', y: 300, w: 1000, size: 82, line: 98, color: W, words: true });
  const scheme = R.textBlock(S.text, { text: 'Вдох на 4, выдох на 6.\nПять раз', y: 300, w: 1000, size: 76, line: 92, color: W, words: true });
  const phaseNames = PH.map(([, , name]) => R.textBlock(S.text, { text: name, y: 290, size: 80, line: 96, color: W }));
  const digits = [];
  for (let d = 1; d <= 6; d++) digits[d] = R.textBlock(S.text, { text: String(d), y: 392, size: 150, line: 170, color: W });
  const dizzy = R.textBlock(S.text, { text: 'Если закружилась голова,\nвернитесь к обычному дыханию', y: 1562, w: 900, font: 'text', size: 38, line: 48, color: W });
  const help = R.textBlock(S.text, { text: 'Когда выдох длиннее вдоха,\nэто может помочь\nзамедлиться', y: 296, w: 1000, size: 66, line: 80, color: W, words: true });
  const save = R.textBlock(S.text, { text: 'Сохраните\nна каникулы', y: 1532, w: 860, font: 'text', weight: 600, size: 44, line: 58, color: W, words: true });

  const faceTrack = [[0, 'look']];
  for (let c = 0; c < N; c++) {
    const t0 = START + c * CYCLE;
    faceTrack.push([t0, 'in'], [t0 + 4, 'out']);
  }
  faceTrack.push([END, 'rest'], [59.3, 'look']);

  // взгляд за огнями: медленно влево вслед за огнём, быстро обратно (период 1 с)
  const saw = (u) => {
    const x = ((u % 1) + 1) % 1;
    return x < 0.86 ? lerp(2.6, -2.6, ease.inOutSine(x / 0.86)) : lerp(-2.6, 2.6, ease.inOutSine((x - 0.86) / 0.14));
  };

  window.renderAt = function (tRaw) {
    const t = Math.round((((tRaw % D) + D) % D) * 1e6) / 1e6;
    // салон покачивается; огни за стеклом — против качания (глубина)
    const cam = { cx: CX, cy: 960, z: 1, x: 6 * Math.sin(per(3) * t), y: 4 * Math.sin(per(2) * t + 1), r: 0.25 * Math.sin(per(2) * t + 0.5) };
    tr(scene, R.camera(cam, 1));
    tr(ui, R.camera(cam, 1));
    bus.update([(P_ * 1 * t) / D, (P_ * 3 * t) / D, (P_ * 7 * t) / D], -cam.x * 0.6, per(4) * t);

    const L = levelAt(t);
    set(circle, { r: R1 * (0.72 + 0.28 * L) });
    const gaze = t < 3.4 ? 1 - ease.inOutSine((t - 2.9) / 0.5) : t > 59.2 ? ease.inOutSine((t - 59.2) / 0.5) : 0;
    tk.update({ t, fill: L, face: R.faceAt(faceTrack, t), x: CX, y: CY, size: TK, eyeDx: gaze * (1.2 + 0.4 * Math.sin(t * 2)), eyeDy: gaze * (0.6 * saw(t) + 0.6), ...IDLE });

    // точки циклов
    const p = phaseAt(t);
    const dotsO = win(t, 4.6, 5.2, 55.0, 55.5);
    dots.forEach((d, i) => {
      const cur = p ? p.cycle : t >= END ? N : -1;
      const act = i === cur ? ease.outCubic((t - (START + i * CYCLE)) / 0.4) : 0;
      set(d, { r: 14 + 6 * act, opacity: i <= cur ? 1 : 0.3 });
      op(d, dotsO);
    });

    // хук: виден с кадра 0, возвращается на шве
    if (t < 3.0) {
      const k = ease.inOutSine((t - 2.6) / 0.3);
      op(hook, 1 - k);
      R.wordsIn(hook, 1);
      hook.style.transform = `translateY(${-20 * k}px)`;
    } else if (t >= 59.35) {
      op(hook, 1);
      R.wordsIn(hook, clamp((t - 59.35) / 0.6));
      hook.style.transform = '';
    } else op(hook, 0);
    const sIn = (t - 2.95) / 0.6;
    const sOut = clamp((t - 4.75) / 0.25);
    if (sIn > 0 && sOut < 1) {
      op(scheme, 1 - sOut);
      R.wordsIn(scheme, clamp(sIn), { spread: 0.45 });
      scheme.style.transform = `translateY(${-20 * sOut}px)`;
    } else op(scheme, 0);
    phaseNames.forEach((n, i) => {
      if (!p || p.i !== i) return op(n, 0);
      const k = ease.outCubic((t - p.t0) / 0.3);
      const out = ease.inOutSine(clamp((p.x - (p.len - 0.2)) / 0.2));
      place(n, { o: k * (1 - out), y: 14 * (1 - k) });
    });
    // счёт: новая цифра с половины яркости, прежняя гаснет за 0,12 с — без пустого кадра
    for (let d = 1; d <= 6; d++) {
      const n = digits[d];
      if (!p || d > p.len) {
        op(n, 0);
        continue;
      }
      const sec = p.x - (p.len - d);
      if (sec < 0 || sec > 1) {
        op(n, 0);
        continue;
      }
      const k = ease.outCubic(sec / 0.2);
      const last = d === 1 ? 0.2 : 0.12;
      const out = ease.inOutSine(clamp((sec - (1 - last)) / last));
      const first = d === p.len ? 0 : 0.5;
      place(n, { o: (first + (1 - first) * k) * (1 - out), y: 10 * (1 - k), s: 0.96 + 0.04 * k });
    }
    place(dizzy, { o: win(t, 5.0, 5.8, 54.6, 55.3) * 0.92 });
    // финал
    if (t > 55.1 && t < 59.45) {
      op(help, 1 - ease.inOutSine((t - 59.1) / 0.35));
      R.wordsIn(help, clamp((t - 55.2) / 1.0), { spread: 0.5 });
    } else op(help, 0);
    const endO = win(t, 56.0, 56.7, 59.1, 59.45);
    mark.at(CX, 1392, 130 * (0.94 + 0.06 * ease.outCubic((t - 56.0) / 0.7)), endO);
    if (t > 56.4 && t < 59.45) {
      op(save, 1 - ease.inOutSine((t - 59.1) / 0.35));
      R.wordsIn(save, clamp((t - 56.5) / 0.8), { spread: 0.45, rise: 22 });
    } else op(save, 0);
  };
  const P_ = 1440;

  R.ready().then(() => {
    window.READY = true;
  });
})();
