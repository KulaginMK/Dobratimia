// Обложка и кадр сторис: листок «Экзамен» с галочками и Тимка.
(function () {
  const kind = new URLSearchParams(location.search).get('still');
  if (!kind) return;
  const { C, svg, tr, op, set } = R;
  const S = R.camStage(C.bg);
  [[110, 430, 230, C.soft, 0.45], [1010, 1250, 170, C.growthSoft, 0.8], [80, 1700, 240, C.soft, 0.35]].forEach(([x, y, r, c, o]) => svg('circle', { cx: x, cy: y, r, fill: c, opacity: o }, S.far));
  const list = window.buildList(S.world, S.text);
  list.tr('rotate(-1.5 540 970)');
  list.rows.forEach((r, i) => {
    set(r.tick, { 'stroke-dashoffset': i === 2 ? 64 * 0.55 : 0 });
    op(r.t, 1);
  });
  op(list.almost, 1);
  list.almost.style.transform = 'rotate(-8deg)';
  const hello = R.poseTimka(svg('g', {}, S.top), 'hello', { noShadow: true });
  hello.update({ t: 0, x: 860, y: 1330, size: 290, wave: 14 });
  if (kind === 'cover') {
    R.chip({ text: S.ui }, { text: 'Тимка', y: 300, size: 44 });
    R.textBlock(S.ui, { text: 'Утро\nэкзамена', y: 380, size: 104, line: 116, w: 1000 });
    S.cam.style.transform = 'translate(0px, 30px)';
    R.textBlock(S.ui, { text: 'Удачи на экзамене!', y: 1560, size: 60, line: 72, w: 1000, color: C.primary });
  } else {
    const wsvg = svg('svg', { width: 1080, height: 1920, viewBox: '0 0 1080 1920' }, S.ui);
    wsvg.style.cssText = 'position:absolute;left:0;top:0';
    R.wordmark({ world: wsvg, text: S.ui }, { y: 280, h: 76 });
    R.textBlock(S.ui, { text: 'Что из списка\nуже готово у вас?', y: 390, size: 84, line: 98, w: 1000 });
    S.cam.style.transform = 'translate(540px, 900px) scale(0.8) translate(-540px, -970px)';
    R.textBlock(S.ui, { text: 'Ответьте в опросе ниже', y: 1320, size: 44, line: 56, font: 'text', weight: 600, color: C.primary });
  }
  window.renderAt = () => {};
  R.ready().then(() => (window.READY = true));
})();
