// Честная запись экрана КРИКа из веб-версии expo-app. Микрофон подменён синтезированным WAV (флаги Chromium),
// интерфейс не перерисовывается: кадры — CDP-скринкаст настоящей страницы, с отметками времени.
// node rec.js <url> <mic.wav> <папка кадров>
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const [url, wav, outDir] = process.argv.slice(2);
fs.mkdirSync(outDir, { recursive: true });
(async () => {
  const browser = await chromium.launch({
    args: ['--force-device-scale-factor=2', '--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', `--use-file-for-fake-audio-capture=${path.resolve(wav)}%noloop`, '--disable-partial-raster'],
  });
  const ctx = await browser.newContext({ viewport: { width: 412, height: 915 }, deviceScaleFactor: 2, permissions: ['microphone'], locale: 'ru-RU' });
  await ctx.addInitScript(() => localStorage.setItem('app:onboarded', '1'));
  const page = await ctx.newPage();
  page.on('pageerror', (e) => console.log('ERR', e.message));
  await page.goto(url);
  await page.waitForTimeout(3500);
  const cdp = await ctx.newCDPSession(page);
  const frames = [];
  let n = 0;
  cdp.on('Page.screencastFrame', async (f) => {
    const file = path.join(outDir, `f${String(n++).padStart(5, '0')}.jpg`);
    fs.writeFileSync(file, Buffer.from(f.data, 'base64'));
    frames.push({ file: path.basename(file), t: f.metadata.timestamp });
    try {
      await cdp.send('Page.screencastFrameAck', { sessionId: f.sessionId });
    } catch {}
  });
  const t0 = Date.now() / 1000;
  const events = [];
  const mark = (name) => events.push({ name, t: Date.now() / 1000 });
  await cdp.send('Page.startScreencast', { format: 'jpeg', quality: 92, maxWidth: 824, maxHeight: 1830, everyNthFrame: 1 });
  mark('start');
  await page.waitForTimeout(1500);
  // нажатие на микрофон: центр круга
  await page.mouse.move(206, 304);
  await page.waitForTimeout(300);
  mark('tap-mic');
  await page.mouse.click(206, 304);
  // ждём, пока «крик» из файла закончится (1,2 с тишины + ~3,9 с звука), и останавливаем замер
  await page.waitForTimeout(5600);
  const stop = page.getByLabel('Отпустить');
  const box = (await stop.count()) ? await stop.first().boundingBox() : null;
  if (box) {
    await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
    await page.waitForTimeout(250);
    mark('tap-stop');
    await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
  } else mark('no-stop-button');
  await page.waitForTimeout(7000);
  mark('result');
  console.log((await page.evaluate(() => document.body.innerText)).slice(0, 900));
  await cdp.send('Page.stopScreencast');
  await page.waitForTimeout(300);
  fs.writeFileSync(path.join(outDir, 'frames.json'), JSON.stringify({ t0, frames, events }, null, 1));
  console.log('кадров', frames.length, 'события', events.map((e) => `${e.name}@${(e.t - t0).toFixed(2)}`).join(' '));
  await browser.close();
})();
