## КРИК: запись экрана

В архиве уже есть запись — `reels/r7/rec.mkv` (60 к/с, кадр k показывает последний кадр скринкаста к моменту k/60) и `reels/r7/rec_events.json` (моменты касаний). Чтобы собрать ролик из неё:

```bash
bash reels/r7/prepare.sh
bash engine/build.sh r7 1081 2
```

`prepare.sh` синтезирует «микрофон» (`reels/r7/mic.py` → `out/r7/mic.wav`), распаковывает кадры записи и пишет индекс для сцены.

### Как записать заново

1. Собрать веб-версию приложения: в папке `expo-app` ветки main — `npm ci`, затем `npx expo export --platform web` (появится `dist/`). Без `.env.local` приложение работает на заглушках; для КРИКа сервер не нужен.
2. Отдать сборку: `node reels/r7/serve.js <путь>/expo-app/dist 8099`.
3. Записать: `node reels/r7/rec.js http://localhost:8099/scream out/r7/mic.wav out/r7/rec`. Скрипт открывает КРИК в Chromium с флагами `--use-fake-ui-for-media-stream --use-fake-device-for-media-stream --use-file-for-fake-audio-capture=out/r7/mic.wav%noloop --force-device-scale-factor=2`, ставит `app:onboarded=1` (режим без входа), нажимает на микрофон, через 5,6 с — «Отпустить», и пишет CDP-скринкаст с отметками времени.
4. Упаковать запись: `python3 reels/r7/pack_rec.py pack out/r7/rec reels/r7/rec.mkv`, дальше — как выше.

Интерфейс в ролике не перерисовывается: сцена (`scene.js`) рисует в «телефон» кадры записи по их времени и добавляет только рамку, подписи, движение камеры и полупрозрачный круг в местах касаний.
