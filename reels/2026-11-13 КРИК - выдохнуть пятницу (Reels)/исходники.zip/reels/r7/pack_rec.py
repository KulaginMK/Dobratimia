"""Запись экрана ↔ видео 60 к/с.
pack: кадры скринкаста (JPEG, у каждого своё время) → rec.mkv, ровные 60 к/с: кадр k показывает последний
      настоящий кадр к моменту k/60 (так же их выбирает сцена). События записи → rec_events.json.
unpack: rec.mkv → кадры f00000.jpg… и frames.json (время кадра k = k/60) для сцены и звука.
python3 reels/r7/pack_rec.py pack <папка скринкаста> <rec.mkv>
python3 reels/r7/pack_rec.py unpack <папка кадров> <rec.mkv>"""
import json, subprocess, sys, pathlib, bisect
mode, folder, mkv = sys.argv[1], pathlib.Path(sys.argv[2]), pathlib.Path(sys.argv[3])
events_file = mkv.with_name("rec_events.json")
FPS = 60
if mode == "pack":
    d = json.load(open(folder / "frames.json"))
    t0 = d["t0"]
    ts = [f["t"] - t0 for f in d["frames"]]
    n = int(ts[-1] * FPS) + 1
    lst = []
    for k in range(n):
        i = max(0, bisect.bisect_right(ts, k / FPS) - 1)
        lst.append(str((folder / d["frames"][i]["file"]).resolve()))
    # кадры по порядку через image2pipe: без пропусков и склеек
    p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "image2pipe", "-framerate", str(FPS), "-c:v", "mjpeg", "-i", "-", "-c:v", "libx264", "-preset", "slow", "-crf", "10", "-pix_fmt", "yuv420p", str(mkv)], stdin=subprocess.PIPE)
    for f in lst:
        p.stdin.write(open(f, "rb").read())
    p.stdin.close()
    p.wait()
    json.dump({e["name"]: round(e["t"] - t0, 4) for e in d["events"]}, open(events_file, "w"), ensure_ascii=False, indent=1)
    print("pack:", n, "кадров 60 к/с →", mkv)
else:
    folder.mkdir(parents=True, exist_ok=True)
    subprocess.check_call(["ffmpeg", "-v", "error", "-y", "-i", str(mkv), "-fps_mode", "passthrough", "-q:v", "1", "-start_number", "0", str(folder / "f%05d.jpg")])
    files = sorted(p.name for p in folder.glob("f*.jpg"))
    ev = json.load(open(events_file))
    frames = [{"file": f, "t": k / FPS} for k, f in enumerate(files)]
    json.dump({"t0": 0, "frames": frames, "events": [{"name": k, "t": v} for k, v in ev.items()]}, open(folder / "frames.json", "w"))
    print("unpack:", len(files), "кадров →", folder)
