#!/usr/bin/env bash
# Подготовка КРИКа к сборке: кадры записи из rec.mkv, индекс для сцены, синтезированный «микрофон».
# Запускать перед engine/build.sh r7 1081 2.
set -euo pipefail
cd "$(dirname "$0")/../.."
mkdir -p out/r7
python3 reels/r7/mic.py out/r7/mic.wav
python3 reels/r7/pack_rec.py unpack out/r7/rec60 reels/r7/rec.mkv
python3 reels/r7/index_rec.py out/r7/rec60
