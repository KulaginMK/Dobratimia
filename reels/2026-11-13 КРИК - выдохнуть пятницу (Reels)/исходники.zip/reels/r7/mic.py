"""Синтезированный «крик» для подмены микрофона: не голос, а нарастающий гул — шум воздуха и медный тон.
Громкость подобрана так, чтобы пик КРИКа был около 90 усл. дБ (шкала expo-app/src/features/scream/loudness.ts).
python3 mic.py out.wav"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "engine"))
import numpy as np
import synth as s
from scipy.io import wavfile

dur = 20.0
t = s.tt(dur)
# огибающая: 1,2 с тишины → нарастание 0,6 с → 2,4 с громко → спад 0,9 с → тишина
env = np.interp(t, [0, 1.2, 1.8, 2.4, 3.6, 4.2, 5.1, dur], [0, 0, 0.75, 1.0, 1.0, 0.8, 0, 0])
f = 165 * (1 + 0.04 * np.sin(2 * np.pi * 5.5 * t)) * np.interp(t, [0, 1.2, 2.4, 4.2, dur], [0.9, 0.9, 1.08, 0.95, 0.95])
ph = 2 * np.pi * np.cumsum(f) / s.SR
tone = sum(np.sin(k * ph) / k ** 0.9 for k in range(1, 12))
roar = s.bandpass(s.noise(len(t)), 300, 3500)
x = (0.55 * tone / np.max(np.abs(tone)) + 0.45 * roar / np.max(np.abs(roar))) * env
# цель: RMS на пике ≈ −10,5 dBFS (≈ 92 усл. дБ)
loud = (t > 2.4) & (t < 3.6)
rms = np.sqrt(np.mean(x[loud] ** 2))
x *= 10 ** (-10.5 / 20) / rms
x = np.clip(x, -0.98, 0.98)
x += s.noise(len(t)) * 10 ** (-62 / 20)  # тишина комнаты около нуля шкалы
wavfile.write(sys.argv[1], s.SR, (x * 32767).astype(np.int16))
print("peak dBFS", 20 * np.log10(np.max(np.abs(x))), "loud RMS dBFS", 20 * np.log10(np.sqrt(np.mean(x[loud] ** 2))))
