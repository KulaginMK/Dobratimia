// «КРИК — выдохнуть пятницу». 18 с. В телефоне — честная запись экрана КРИКа из веб-версии expo-app
// (кадры скринкаста по их настоящему времени, интерфейс не перерисован). Вокруг — подписи и камера.
(function () {
  const STILL = new URLSearchParams(location.search).get('still');
  const { C, clamp, lerp, ease, win, keys, svg, tr, op, set, div } = R;
  const D = 18;
  const S = R.camStage(C.bg);
  const REC = window.REC;

  const blobs = [
    [110, 420, 230, C.soft, 0.5],
    [1010, 1300, 190, C.growthSoft, 0.85],
    [70, 1700, 260, C.soft, 0.42],
    [990, 280, 120, C.growthSoft, 0.7],
  ].map(([x, y, r, c, o]) => ({ x, y, n: svg('circle', { cx: x, cy: y, r, fill: c, opacity: o }, S.far) }));

  // ---- телефон: шоколадная рамка, внутри — кадр записи ----
  const K = 0.66; // 824 px кадра записи → 544 px на экране
  const PW = 824 * K;
  const PH = 1830 * K;
  const PX = (1080 - PW) / 2;
  const PY = 500;
  const BEZ = 16;
  div({ style: { position: 'absolute', left: PX - BEZ + 'px', top: PY - BEZ + 'px', width: PW + 2 * BEZ + 'px', height: PH + 2 * BEZ + 'px', borderRadius: '64px', background: C.choco } }, S.text);
  const screen = div({ style: { position: 'absolute', left: PX + 'px', top: PY + 'px', width: PW + 'px', height: PH + 'px', borderRadius: '50px', overflow: 'hidden', background: C.bg } }, S.text);
  const canvas = document.createElement('canvas');
  canvas.width = 824;
  canvas.height = 1830;
  canvas.style.cssText = `width:${PW}px;height:${PH}px;display:block`;
  screen.appendChild(canvas);
  const g2 = canvas.getContext('2d');
  // касание: полупрозрачный круг поверх записи (пометка, а не часть интерфейса)
  const touch = div({ style: { position: 'absolute', width: '120px', height: '120px', marginLeft: '-60px', marginTop: '-60px', borderRadius: '50%', background: C.text } }, S.text);
  const css2screen = (x, y) => [PX + x * 2 * K, PY + y * 2 * K];

  const images = REC.frames.map(([file]) => {
    const im = new Image();
    im.src = REC.dir + file;
    return im;
  });
  const times = REC.frames.map(([, t]) => t);
  const TAP = REC.events['tap-mic'];
  const STOP = REC.events['tap-stop'];
  const T_TAP = 2.2; // в ролике касание микрофона на 2,2 с
  const OFF = T_TAP - TAP; // сдвиг записи
  const T_END = 13.6;
  function recTime(T) {
    if (T < T_TAP) return Math.min(TAP - 0.3, 1.0); // экран готовности стоит без изменений до касания
    return Math.min(T - OFF, T_END - OFF);
  }
  let last = -1;
  function drawRec(r) {
    let lo = 0;
    let hi = times.length - 1;
    while (lo < hi) {
      const mid = (lo + hi + 1) >> 1;
      if (times[mid] <= r) lo = mid;
      else hi = mid - 1;
    }
    if (lo !== last) {
      g2.drawImage(images[lo], 0, 0, 824, 1830);
      last = lo;
    }
    return lo;
  }

  // ---- подписи (вне камеры) ----
  const backdrop = div({ style: { position: 'absolute', left: '0', top: '0', width: '1080px', height: '480px', background: C.bg } }, S.ui);
  const caps = [
    { a: -1, b: 2.15, text: 'Конец недели.\nПора выдохнуть' },
    { a: 2.35, b: 4.6, text: 'Нажали —\nи выдохнули' },
    { a: 4.75, b: 7.85, text: 'Мы не записываем ваш голос,\nанализируется только громкость', size: 58 },
    { a: 9.75, b: 13.5, text: '93 усл. дБ.\nСосед, простите' },
    { a: 13.75, b: 99, text: 'Выдохните пятницу\nв КРИКе' },
  ].map((c) => ({ ...c, n: R.textBlock(S.ui, { text: c.text, y: 280, size: c.size || 70, line: c.size ? 72 : 84, w: 1010, words: true }) }));
  const wsvg = svg('svg', { width: 1080, height: 1920, viewBox: '0 0 1080 1920' }, S.ui);
  wsvg.style.cssText = 'position:absolute;left:0;top:0';
  const mark = R.logo(wsvg, 'logo-mark');
  const word = R.textBlock(S.ui, { text: 'Добратимия', y: 1543, x: 0, w: 400, size: 44, line: 76, align: 'left' });
  let probeW = 250;

  window.renderAt = function (tRaw) {
    const T = clamp(tRaw, 0, D);
    // ---- камера ----
    const PRIV_Y = PY + 862 * 2 * K; // строка «Мы не записываем…» внизу экрана КРИКа
    const z = keys(T, [[0, 1.0], [2.3, 1.0], [3.0, 1.12], [4.6, 1.12], [5.4, 2.3], [7.4, 2.3], [8.0, 1.0], [9.7, 1.0], [10.4, 1.3], [13.3, 1.33], [14.3, 0.72], [18, 0.74]], ease.inOutCubic);
    const cy = keys(T, [[0, 960], [2.3, 960], [3.0, 860], [4.6, 860], [5.4, PRIV_Y], [7.4, PRIV_Y], [8.0, 960], [9.7, 960], [10.4, 850], [13.3, 850], [14.3, 1000], [18, 1000]], ease.inOutCubic);
    // подложка под подписью на крупных планах: запись не просвечивает за текстом
    op(backdrop, clamp((z - 1.25) / 0.3));
    R.camApply(S, { cx: 540, cy, z, r: 0.3 * Math.sin(T * 0.6), x: 5 * Math.sin(T * 0.8), y: 4 * Math.sin(T * 0.5 + 1) });
    blobs.forEach((b, i) => set(b.n, { cy: b.y + 12 * Math.sin(T * 0.4 + i * 1.7) }));

    // ---- запись ----
    drawRec(recTime(T));

    // касания: микрофон (центр круга) и «Отпустить»
    const taps = [
      [T_TAP, 206, 304],
      [STOP + OFF, 206, 460],
    ];
    let shown = false;
    for (const [at, x, y] of taps) {
      const q = (T - at + 0.15) / 0.55;
      if (q > 0 && q < 1) {
        const [sx, sy] = css2screen(x, y);
        touch.style.left = sx + 'px';
        touch.style.top = sy + 'px';
        touch.style.transform = `scale(${0.35 + 0.65 * ease.outCubic(q)})`;
        op(touch, 0.2 * (1 - ease.inCubic(q)));
        shown = true;
      }
    }
    if (!shown) op(touch, 0);

    // ---- подписи ----
    caps.forEach((c) => {
      const kIn = c.a < 0 ? 1 : (T - c.a) / 0.6;
      const out = clamp((T - c.b) / 0.2);
      if (kIn <= 0 || out >= 1) return op(c.n, 0);
      op(c.n, 1 - out);
      R.wordsIn(c.n, clamp(kIn), { spread: 0.45 });
    });
    const mk = ease.outCubic((T - 14.4) / 0.7);
    const total = 76 + 8 + probeW;
    const x0 = 540 - total / 2;
    mark.at(x0 + 38, 1581, 76, mk);
    word.style.left = x0 + 84 + 'px';
    op(word, mk);
  };

  if (STILL) {
    const base = window.renderAt;
    window.renderAt = function () {
      base(STILL === 'cover' ? 11.2 : 11.2);
      caps.forEach((c) => op(c.n, 0));
      op(word, 0);
      mark.at(0, 0, 1, 0);
      if (STILL === 'cover') {
        R.camApply(S, { cx: 540, cy: 803, z: 0.88 });
        op(backdrop, 0);
        R.chip({ text: S.ui }, { text: 'КРИК', y: 290, size: 48 });
        R.textBlock(S.ui, { text: 'Выдохнуть\nпятницу', y: 380, size: 124, line: 134, w: 1000 });
      } else {
        R.camApply(S, { cx: 540, cy: 1193, z: 0.45 });
        op(backdrop, 0);
        R.wordmark({ world: wsvg, text: S.ui }, { y: 280, h: 76 });
        R.textBlock(S.ui, { text: 'Сколько усл. дБ\nвыдохнете вы?', y: 400, size: 88, line: 100, w: 1000 });
        R.textBlock(S.ui, { text: 'Ответьте в опросе ниже', y: 1235, size: 44, line: 56, font: 'text', weight: 600, color: C.primary });
      }
      window.renderAt = () => {};
    };
  }

  // готовность: шрифты и все кадры записи загружены
  Promise.all([R.ready(), ...images.map((im) => (im.complete ? Promise.resolve() : new Promise((res) => (im.onload = im.onerror = res))))]).then(() => {
    const pr = document.createElement('span');
    pr.style.cssText = "font:900 44px 'Nunito';position:absolute;visibility:hidden;white-space:nowrap";
    pr.textContent = 'Добратимия';
    document.body.appendChild(pr);
    probeW = pr.getBoundingClientRect().width;
    pr.remove();
    window.READY = true;
  });
})();
