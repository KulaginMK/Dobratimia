"""Индекс записи для сцены: reels/r7/rec_index.js (кадры и их время от начала записи).
python3 reels/r7/index_rec.py <папка кадров>"""
import json, sys, pathlib
d = json.load(open(pathlib.Path(sys.argv[1]) / "frames.json"))
t0 = d["t0"]
idx = {"dir": "../../out/r7/rec60/", "frames": [[f["file"], round(f["t"] - t0, 4)] for f in d["frames"]], "events": {e["name"]: round(e["t"] - t0, 3) for e in d["events"]}}
out = pathlib.Path(__file__).with_name("rec_index.js")
out.write_text("window.REC = " + json.dumps(idx) + ";\n")
print(out, len(idx["frames"]), idx["events"])
