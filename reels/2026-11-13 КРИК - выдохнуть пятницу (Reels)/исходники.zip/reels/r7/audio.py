"""Звук «КРИК — выдохнуть пятницу»: пятничный грув 120 уд/мин фа мажор и тот же синтезированный «крик»,
который слышало приложение (mic.wav), — в момент, когда он звучал при записи. Голоса нет.
python3 reels/r7/audio.py out/audio.wav [длительность]"""
import sys, json, pathlib
here = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(here.parents[1] / "engine"))
import numpy as np
import synth as s
from synth import note as N
from scipy.io import wavfile

D = 18.0
out = sys.argv[1]
length = float(sys.argv[2]) if len(sys.argv) > 2 else D
root = here.parents[1]
rec = json.load(open(root / "out/r7/rec60/frames.json"))
ev = {e["name"]: e["t"] - rec["t0"] for e in rec["events"]}
T_TAP = 2.2
OFF = T_TAP - ev["tap-mic"]
# файл «микрофона» начинает играть, когда приложение открывает микрофон: ~0,15 с после касания
MIC_START = T_TAP + 0.15
b = s.buf(D + 4)
BEAT = 0.5

def shaker(at, level):
    n = int(0.04 * s.SR)
    x = s.highpass(s.noise(n), 6000) * np.exp(-np.arange(n) / s.SR * 80)
    s.mix(b, x * level, at, pan=0.3)

# грув: до касания и после результата; под «криком» и огнём — тише
bars = [(0, ["F3", "A3", "C4"], "F2"), (2, ["A#3", "D4", "F4"], "A#1"), (4, ["C4", "E4", "G4"], "C2"), (6, ["F3", "A3", "C4"], "F2"),
        (8, ["D4", "F4", "A4"], "D2"), (10, ["A#3", "D4", "F4"], "A#1"), (12, ["C4", "E4", "G4"], "C2"), (14, ["F3", "A3", "C4"], "F2"), (16, ["F3", "A3", "C4"], "F2")]
for t0, ch, bass in bars:
    duck = 0.35 if 3.4 <= t0 + 1 < 9.6 else 1.0
    for k in range(8):
        f = N(ch[[0, 1, 2, 1, 0, 2, 1, 2][k]])
        s.mix(b, s.pluck(f, 0.9, bright=0.6, level=(0.07 if k % 2 else 0.09) * duck), t0 + k * BEAT / 2, pan=-0.3 + 0.6 * (k % 4) / 3)
        shaker(t0 + k * BEAT / 2 + BEAT / 4, 0.018 * duck)
    for k in (0, 2):
        s.mix(b, s.felt(N(bass), 0.9, level=0.22 * duck), t0 + k * BEAT)
        s.mix(b, s.thump(60, 0.25, level=0.12 * duck), t0 + k * BEAT)

# «крик»: тот же файл, что подавался в микрофон
sr, mic = wavfile.read(root / "out/r7/mic.wav")
mic = mic.astype(np.float64) / 32768.0
s.mix(b, mic[: int(6.0 * sr)] * 0.42, MIC_START)
# касания
s.mix(b, s.tick(3000, 0.04, level=0.12), T_TAP)
s.mix(b, s.tick(3000, 0.04, level=0.12), ev["tap-stop"] + OFF)
# огонь после «Отпустить»: шум пламени нарастает и уходит
t_fire = ev["tap-stop"] + OFF + 0.1
n = int(1.6 * s.SR)
fire = s.sweep_filter(s.noise(n), 300, 2500, "low") * np.sin(np.pi * np.linspace(0, 1, n)) ** 1.5
s.mix(b, fire / np.max(np.abs(fire)) * 0.12, t_fire)
s.mix(b, s.whoosh(0.9, 400, 3000, level=0.07), t_fire + 0.5)
# результат: колокольчик и аккорд
t_res = 9.7
for i, x in enumerate(["F5", "A5", "C6"]):
    s.mix(b, s.bell(N(x), 2.5, level=0.06), t_res + i * 0.1, pan=-0.3 + 0.3 * i)
s.mix(b, s.pop(700, 0.12, level=0.10), t_res)
# финал
for i, x in enumerate(["C5", "F5", "A5", "C6"]):
    s.mix(b, s.bell(N(x), 2.0, level=0.05), 14.4 + i * 0.12)

b = s.reverb(b, seconds=1.6, wet=0.18)
b = s.fit(b, length)
fade = int(0.8 * s.SR)
b[:, -fade:] *= np.linspace(1, 0, fade) ** 2
b = s.master_lufs(b, target=-15.0, ceiling_db=-1.5)
b = s.fade_edges(b, ms=30)
s.write(out, b)
