# 2026-11-13 КРИК - выдохнуть пятницу (Reels) — исходники

Всё, чтобы пересобрать ролик с нуля: анимация (HTML/SVG + JavaScript), звук (Python, синтез кодом), сборка (ffmpeg).
Музыки, сэмплов и голоса со стороны нет: каждый звук генерируется в `reels/r7/audio.py` через `engine/synth.py`.

## Что нужно

- Node.js 18+ и Playwright с Chromium (проверено на Playwright 1.63): `npm install playwright` и `npx playwright install chromium`
- Python 3.10+ (проверено на numpy 2.5, scipy 1.18, Pillow 12.3): `pip install numpy scipy pillow`
- ffmpeg 6+ с libx264 и aac

## Сборка

```bash
bash engine/build.sh r7 1081 2
```

Результат появится в `out/r7/`: `reels.mp4`, `обложка.png`, `сторис_1.png`, `sheet.png` (лист контрольных кадров).

Параметры: 1081 кадров при 60 к/с = 18.017 с; 2 подкадр(а) на кадр — motion blur с выдержкой 180°.


## Как это устроено

- `reels/r7/scene.js` — сцена: функция `renderAt(t)` рисует кадр в момент t секунд. Время — единственный источник правды, кадры можно снимать в любом порядке.
- `reels/r7/stills.js` — обложка (`?still=cover`) и кадр сторис (`?still=story`).
- `reels/r7/audio.py` — партитура: аккорды, мотивы, звуки событий по тем же таймкодам, что в сцене.
- `reels/r7/раскадровка.md` — варианты по сценам и что выбрано.
- `engine/lib.js` — общая библиотека: палитра бренда, кривые, текст, камера, Тимка. Дыхание Тимки перенесено из `expo-app/src/components/brand/Timka.tsx` (спецификация «Тимка · дыхание» 1.0).
- `engine/render.js` — покадровый рендер в Chromium, несколько параллельных работников, видео без потерь.
- `engine/mux.sh` — итоговое кодирование: H.264 High, yuv420p, BT.709, постоянный квантователь 16, AAC 192 кбит/с, `+faststart`.
- `engine/check.py` — проверка готового файла: параметры, кадры, совпадение кадров петли, громкость.
- `assets/` — SVG Тимки и знака из `handoff/assets/svg/` без изменений. `engine/fonts/` — Nunito 900 и Golos Text 400/600 (@fontsource, лицензия OFL).

Открыть сцену в браузере для просмотра: `reels/r7/scene.html` (в консоли `renderAt(5)` покажет кадр на 5-й секунде).

## КРИК: запись экрана

В архиве уже есть запись — `reels/r7/rec.mkv` (60 к/с, кадр k показывает последний кадр скринкаста к моменту k/60) и `reels/r7/rec_events.json` (моменты касаний). Чтобы собрать ролик из неё:

```bash
bash reels/r7/prepare.sh
bash engine/build.sh r7 1081 2
```

`prepare.sh` синтезирует «микрофон» (`reels/r7/mic.py` → `out/r7/mic.wav`), распаковывает кадры записи и пишет индекс для сцены.

### Как записать заново

1. Собрать веб-версию приложения: в папке `expo-app` ветки main — `npm ci`, затем `npx expo export --platform web` (появится `dist/`). Без `.env.local` приложение работает на заглушках; для КРИКа сервер не нужен.
2. Отдать сборку: `node reels/r7/serve.js <путь>/expo-app/dist 8099`.
3. Записать: `node reels/r7/rec.js http://localhost:8099/scream out/r7/mic.wav out/r7/rec`. Скрипт открывает КРИК в Chromium с флагами `--use-fake-ui-for-media-stream --use-fake-device-for-media-stream --use-file-for-fake-audio-capture=out/r7/mic.wav%noloop --force-device-scale-factor=2`, ставит `app:onboarded=1` (режим без входа), нажимает на микрофон, через 5,6 с — «Отпустить», и пишет CDP-скринкаст с отметками времени.
4. Упаковать запись: `python3 reels/r7/pack_rec.py pack out/r7/rec reels/r7/rec.mkv`, дальше — как выше.

Интерфейс в ролике не перерисовывается: сцена (`scene.js`) рисует в «телефон» кадры записи по их времени и добавляет только рамку, подписи, движение камеры и полупрозрачный круг в местах касаний.
