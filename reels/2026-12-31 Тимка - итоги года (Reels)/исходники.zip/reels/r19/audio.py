"""Звук «Тимка — итоги года»: тёплый грув маримбы (фа мажор, 100 уд/мин), щелчки галочек, «почти», хлопушка конфетти, колокольчики; всё синтезировано кодом.
python3 reels/r19/audio.py out/audio.wav [длительность]"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "engine"))
import numpy as np
import synth as s
from synth import note as N

D = 13.0
out = sys.argv[1]
length = float(sys.argv[2]) if len(sys.argv) > 2 else D
b = s.buf(D + 6)
beat = 0.65
prog = [["F2", "A2", "C3", "E3"], ["D2", "F2", "A2", "C3"], ["A#1", "D2", "F2", "A2"], ["C2", "E2", "G2", "A#2"]]
tb, k = 0.0, 0
while tb < 7.2:
    ch = prog[k % 4]
    s.mix(b, s.sine_pad([N(x) for x in ch], 4 * beat * 0.5, attack=0.05, release=0.5, level=0.05), tb)
    s.mix(b, s.felt(N(ch[0]), 0.9, level=0.11), tb)
    s.mix(b, s.felt(N(ch[2]), 0.7, level=0.06), tb + beat)
    tb += 2 * beat
    k += 1
# список: каждая строка — лёгкий шорох, галочка — щелчок и нота вверх
for i, (a, x) in enumerate(zip([1.9, 3.5, 5.1, 6.7], [2.3, 3.9, 5.5, 7.1])):
    s.mix(b, s.whoosh(0.25, 800, 2600, level=0.03), a, pan=-0.2)
    s.mix(b, s.tick(2600, 0.04, level=0.06), x)
    if i == 2:
        # «почти»: галочка обрывается — две ноты вниз, смешной «пуп»
        s.mix(b, s.pluck(N("A4"), 1.0, bright=0.5, level=0.10), x + 0.05)
        s.mix(b, s.pluck(N("F#4"), 1.2, bright=0.4, level=0.09), x + 0.3)
        s.mix(b, s.pop(420, 0.15, level=0.10), 6.0)
    else:
        s.mix(b, s.pluck(N(["C5", "E5", "", "A5"][i]), 1.4, bright=0.6, level=0.11), x + 0.05)
# хлопушка конфетти и праздничные колокольчики
s.mix(b, s.thump(160, 0.25, level=0.22), 7.2)
s.mix(b, s.whoosh(0.5, 600, 4000, level=0.08), 7.2)
rng = np.random.default_rng(7)
for t0 in np.sort(rng.uniform(7.25, 8.4, 16)):
    s.mix(b, s.sparkle(float(rng.uniform(2200, 3600)), 0.4, level=0.03), float(t0), pan=float(rng.uniform(-0.7, 0.7)))
s.mix(b, s.sine_pad([N(x) for x in ["F2", "C3", "A3", "C4", "F4"]], 5.0, attack=0.1, release=1.5, level=0.07), 7.3)
for i, x in enumerate(["C5", "F5", "A5", "C6", "A5", "G5", "F5"]):
    s.mix(b, s.bell(N(x), 2.2, level=0.06), 7.6 + i * 0.33, pan=0.2 * ((-1) ** i))
s.mix(b, s.sparkle(2800, 0.8, level=0.05), 9.0)
s.mix(b, s.whoosh(0.4, 2000, 500, level=0.04), 12.3)

b = s.reverb(b, seconds=1.8, wet=0.22)
b = s.loop_wrap(b, D)
n = int(round(length * s.SR))
if n > b.shape[1]:
    b = np.concatenate([b, b[:, : n - b.shape[1]]], axis=1)
b = b[:, :n]
b = s.master_lufs(b, target=-16.0, ceiling_db=-1.5)
b = s.fade_edges(b, ms=30)
s.write(out, b)
