// «Тимка — итоги года». 13 с, петля: кадр 13,0 совпадает с кадром 0. Серия «Тимка»: без голоса.
// POV: подводите итоги года → чек-лист: галочки по очереди, у «Спать по 8 часов» — «почти» → конфетти →
// «Доброе слово» sweet-3 дословно, «С наступающим!», знак → список очищается, кадр 0.
(function () {
  const { C, svg, div, tr, op, set } = R;
  const SKIN = '#F2B28A';
  const CARD = { x: 150, y: 640, w: 780, h: 660 };
  const ROWS = ['Пережить сессию', 'Не потерять зачётку', 'Спать по 8 часов', 'Дожить до 31 декабря'];
  /** Листок «2026» с чек-листом. g — SVG-слой, text — HTML-слой той же камеры. */
  window.buildList = function (g, text) {
    const card = svg('g', {}, g);
    svg('rect', { x: CARD.x, y: CARD.y, width: CARD.w, height: CARD.h, rx: 44, fill: C.white }, card);
    const head = R.textBlock(text, { text: '2026', y: CARD.y + 34, x: CARD.x + 70, w: 400, size: 76, line: 88, color: C.primary, align: 'left' });
    const rows = ROWS.map((label, i) => {
      const y = CARD.y + 170 + i * 120;
      const box = svg('rect', { x: CARD.x + 70, y: y - 32, width: 64, height: 64, rx: 16, fill: C.soft }, card);
      const tick = svg('path', { d: `M${CARD.x + 84} ${y + 2} L${CARD.x + 99} ${y + 18} L${CARD.x + 124} ${y - 16}`, fill: 'none', stroke: C.primary, 'stroke-width': 10, 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'stroke-dasharray': 64, 'stroke-dashoffset': 64 }, card);
      const t = R.textBlock(text, { text: label, y: y - 29, x: CARD.x + 160, w: 560, font: 'text', weight: 600, size: 46, line: 58, color: C.text, align: 'left', balance: false });
      t.style.whiteSpace = 'nowrap';
      return { box, tick, t, y };
    });
    const almost = div({ style: { position: 'absolute', left: CARD.x + 575 + 'px', top: CARD.y + 170 + 2 * 120 - 42 + 'px', font: "900 54px 'Nunito'", color: C.primary, transformOrigin: '0 50%' }, html: 'почти' }, text);
    return {
      card,
      head,
      rows,
      almost,
      tr(s) {
        tr(card, s);
      },
    };
  };
  window.R.SKIN = SKIN;
})();

(function () {
  if (new URLSearchParams(location.search).get('still')) return;
  const { C, clamp, lerp, ease, win, svg, tr, op, set } = R;
  const D = 13;
  const TAU = Math.PI * 2;
  const per = (k) => (TAU * k) / D;
  const S = R.camStage(C.bg);
  [
    [110, 430, 230, C.soft, 0.45],
    [1010, 1250, 170, C.growthSoft, 0.8],
    [80, 1700, 240, C.soft, 0.35],
    [990, 300, 120, C.growthSoft, 0.7],
  ].forEach(([x, y, r, c, o]) => svg('circle', { cx: x, cy: y, r, fill: c, opacity: o }, S.far));
  const confG = svg('g', {}, S.world);
  const list = window.buildList(S.world, S.text);
  S.world.appendChild(confG); // конфетти поверх листка, но под текстом строк
  // Тимка перед листком: дыхательная фигура (лица) с лапкой-ручкой, на финале — поза hello
  const tkG = svg('g', {}, S.top);
  const tk = R.breathingTimka(tkG);
  const paw = svg('g', {}, S.top);
  svg('rect', { x: -6, y: -58, width: 12, height: 62, rx: 6, fill: C.honey, transform: 'rotate(-20)' }, paw);
  svg('ellipse', { cx: 0, cy: 0, rx: 22, ry: 17, fill: R.SKIN }, paw);
  const hiG = svg('g', {}, S.top);
  const hello = R.poseTimka(hiG, 'hello', { noShadow: true });
  const TX = 860;
  const TY = 1330;
  const TS = 290;

  // конфетти: вылетают из четвёртой галочки и падают; всё гаснет к 12,3
  const rnd = ((s) => () => ((s = (s * 16807) % 2147483647) - 1) / 2147483646)(21);
  const COLORS = [C.primary, C.soft, C.choco, C.honey, C.primary, C.soft];
  const conf = [];
  for (let i = 0; i < 46; i++) {
    const n = svg('rect', { x: -9, y: -14, width: 18, height: 28, rx: 5, fill: COLORS[i % COLORS.length] }, confG);
    const a = -Math.PI / 2 + (rnd() - 0.5) * 2.0;
    const v = 1000 + rnd() * 1000;
    conf.push({ n, t0: 7.2 + rnd() * 0.25, vx: Math.cos(a) * v * 1.1, vy: Math.sin(a) * v, rs: (rnd() - 0.5) * 900, sw: rnd() * 6, s: 0.7 + rnd() * 0.6 });
  }
  const CX0 = 540;
  const CY0 = 640 + 170 + 3 * 120;

  // ---- тексты поверх камеры ----
  const chip = (text) => {
    const d = R.div({ style: { position: 'absolute', left: '0', top: '300px', width: '1080px', textAlign: 'center' } }, S.ui);
    R.div({ style: { display: 'inline-block', padding: '12px 34px', borderRadius: '999px', background: C.soft, color: C.onSoft, font: "600 42px 'Golos Text'", lineHeight: '52px' }, html: text }, d);
    return d;
  };
  const pov = chip('POV');
  const hook = R.textBlock(S.ui, { text: 'Вы подводите\nитоги года', y: 390, w: 1000, size: 92, line: 106, color: C.text, words: true });
  const kind = chip('Доброе слово');
  const phrase = R.textBlock(S.ui, { text: 'Даже маленький шаг вперёд —\nэто уже движение.', y: 400, w: 1040, x: 20, size: 62, line: 76, color: C.text, words: true });
  const hny = R.textBlock(S.ui, { text: 'С наступающим!', y: 1478, w: 1000, size: 72, line: 84, color: C.primary, words: true });
  const markSvg = svg('svg', { width: 1080, height: 1920, viewBox: '0 0 1080 1920' }, S.ui);
  markSvg.style.cssText = 'position:absolute;left:0;top:0';
  const mark = R.logo(markSvg, 'logo-mark');

  const TICK = [2.3, 3.9, 5.5, 7.1]; // когда рисуется галочка
  const SHOW = [1.9, 3.5, 5.1, 6.7]; // когда появляется строка
  const SWAP_A = 7.4; // look → hello
  const SWAP_B = 12.45; // hello → look (под шов)

  window.renderAt = function (tRaw) {
    const t = Math.round((((tRaw % D) + D) % D) * 1e6) / 1e6;
    // ---- камера: лёгкий подъезд к листку, пока идёт список; заголовки (вне камеры) не перекрываются ----
    const listK = win(t, 1.6, 2.4, 11.8, 12.6);
    R.camApply(S, { cx: 540, cy: 960 + 12 * listK, z: 1 + 0.035 * listK, x: 5 * Math.sin(per(2) * t), y: 4 * Math.sin(per(1) * t + 1), r: 0.3 * Math.sin(per(1) * t) }, 0.4);
    list.tr(`rotate(${-1.5 + 0.4 * Math.sin(per(1) * t)} 540 970)`);

    // ---- чек-лист: строки появляются, галочки рисуются, на шве — всё очищается ----
    const clear = ease.inOutSine(clamp((t - 12.3) / 0.35));
    list.rows.forEach((r, i) => {
      const s = clamp((t - SHOW[i]) / 0.35);
      op(r.t, ease.outCubic(s) * (1 - clear));
      r.t.style.transform = `translateX(${24 * (1 - ease.outCubic(s))}px)`;
      // «Спать по 8 часов»: галочка доходит до половины и останавливается
      const full = i === 2 ? 0.45 : 1;
      const k = ease.outCubic(clamp((t - TICK[i]) / 0.3)) * full * (1 - clear);
      set(r.tick, { 'stroke-dashoffset': 64 * (1 - k) });
      op(r.tick, k > 0.01 ? 1 : 0);
      const pop = Math.sin(Math.PI * clamp((t - TICK[i]) / 0.25)) * (t > TICK[i] && t < TICK[i] + 0.25 ? 1 : 0);
      set(r.box, { transform: `translate(${150 + 102} ${r.y}) scale(${1 + 0.15 * pop}) translate(${-(150 + 102)} ${-r.y})` });
    });
    const al = clamp((t - 6.0) / 0.3);
    op(list.almost, ease.outCubic(al) * (1 - clear));
    list.almost.style.transform = `rotate(-8deg) scale(${lerp(1.4, 1, ease.outCubic(al))})`;

    // ---- Тимка ----
    const sq = (t0) => (t >= t0 - 0.1 && t < t0 ? ease.inCubic((t - (t0 - 0.1)) / 0.1) * 0.12 : t >= t0 && t < t0 + 0.16 ? (1 - ease.outCubic((t - t0) / 0.16)) * 0.12 : 0);
    const squash = sq(SWAP_A) + sq(SWAP_B);
    const waving = t >= SWAP_A && t < SWAP_B;
    op(tkG, waving ? 0 : 1);
    op(paw, waving ? 0 : 1);
    op(hiG, waving ? 1 : 0);
    if (!waving) {
      // смотрит на строку, которую отмечает; на «почти» — лицо hold (щёки надуты), без грусти
      let row = -1;
      for (let i = 0; i < 4; i++) if (t >= SHOW[i] - 0.1 && t < 7.4) row = i;
      const face = t >= 5.95 && t < 6.8 ? { kind: 'hold', from: 'look', shift: ease.inOutSine((t - 5.95) / 0.28) } : t >= 6.8 && t < 7.1 ? { kind: 'look', from: 'hold', shift: ease.inOutSine((t - 6.8) / 0.28) } : { kind: 'look', from: 'look', shift: 1 };
      const eyeDx = row < 0 ? 0 : -2.6;
      const eyeDy = row < 0 ? 0 : -2.6 + row * 1.3;
      tk.update({ t, fill: 0.3 + 0.06 * Math.sin(per(6) * t), face, x: TX, y: TY, size: TS, eyeDx, eyeDy, noPuffs: true, idleSpeed: per(9), blinkEvery: D / 4, extraY: -squash, extraX: squash * 0.6 });
      const writing = TICK.some((a) => t > a - 0.15 && t < a + 0.35);
      tr(paw, `translate(${TX - 120 + (writing ? 10 * Math.sin(t * 40) : 0)} ${TY + 40 + (writing ? 4 * Math.sin(t * 27) : 0)})`);
    } else {
      hello.update({ t, x: TX, y: TY, size: TS, squash, wave: R.waveAngle(t, 7.7) + R.waveAngle(t, 10.2), blink: R.blinkAt(t, D / 4, 0.4), sway: 3 * Math.sin(per(5) * t) });
    }

    // ---- конфетти ----
    const g = 2200;
    const fade = 1 - ease.inOutSine(clamp((t - 11.6) / 0.7));
    conf.forEach((c) => {
      const dt = t - c.t0;
      if (dt < 0 || t > 12.35) return op(c.n, 0);
      const drag = 1 - Math.exp(-2.2 * dt);
      const x = CX0 + (c.vx / 2.2) * drag + 30 * Math.sin(dt * 3 + c.sw) * Math.min(1, dt);
      const y = CY0 + (c.vy / 2.2) * drag + 0.5 * 420 * dt * dt;
      if (y > 2050) return op(c.n, 0);
      op(c.n, fade);
      tr(c.n, `translate(${x} ${y}) rotate(${c.rs * dt}) scale(${c.s} ${c.s * (0.6 + 0.4 * Math.abs(Math.cos(dt * 6 + c.sw)))})`);
    });

    // ---- тексты ----
    const hookO = t < 7.5 ? 1 - ease.inOutSine((t - 7.2) / 0.3) : t >= 12.4 ? ease.inOutSine((t - 12.4) / 0.3) : 0;
    op(pov, hookO);
    op(hook, hookO);
    R.wordsIn(hook, t >= 12.4 ? clamp((t - 12.4) / 0.55) : 1);
    const pO = win(t, 7.5, 7.6, 12.1, 12.4);
    op(kind, pO);
    op(phrase, pO);
    if (pO > 0) R.wordsIn(phrase, clamp((t - 7.55) / 1.0), { spread: 0.55 });
    const hO = win(t, 8.6, 8.7, 12.1, 12.4);
    op(hny, hO);
    if (hO > 0) R.wordsIn(hny, clamp((t - 8.6) / 0.5), { spread: 0.3 });
    mark.at(540, 1608, 96 * (0.94 + 0.06 * ease.outCubic((t - 9.0) / 0.6)), win(t, 9.0, 9.5, 12.1, 12.4));
  };

  R.ready().then(() => {
    window.READY = true;
  });
})();
