"""Звук «посплю 20 минут»: колыбельная маримба, будильник (три звонка), толчки лапкой, круг-переход; всё синтезировано кодом.
python3 reels/r10/audio.py out/audio.wav [длительность]"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "engine"))
import numpy as np
import synth as s
from synth import note as N

D = 13.0
out = sys.argv[1]
length = float(sys.argv[2]) if len(sys.argv) > 2 else D
b = s.buf(D + 6)


def alarm(dur, level=0.05):
    """Звонок будильника: два тона, частая трель 14 Гц."""
    t = s.tt(dur)
    tone = np.sin(2 * np.pi * 2093 * t) + 0.6 * np.sin(2 * np.pi * 2637 * t) + 0.3 * np.sin(2 * np.pi * 4186 * t)
    trill = 0.5 + 0.5 * np.sign(np.sin(2 * np.pi * 14 * t))
    env = np.clip(t / 0.01, 0, 1) * np.clip((dur - t) / 0.04, 0, 1)
    return s.lowpass(tone * trill * env, 6000) * level


# ---- ожидание: колыбельная (фа мажор), «Z» — мягкие ноты ----
s.mix(b, s.sine_pad([N(x) for x in ["F2", "C3", "A3"]], 2.8, attack=0.3, release=1.0, level=0.07), -0.2)
for x, t0 in [("A4", 0.0), ("C5", 0.5), ("F5", 1.0), ("E5", 1.5), ("C5", 2.0)]:
    s.mix(b, s.pluck(N(x), 1.6, bright=0.3, level=0.12), t0, pan=-0.1)
# круг-переходы
for t0 in (2.15, 8.15, 12.3):
    s.mix(b, s.whoosh(0.35, 400, 2600, level=0.06), t0)
    s.mix(b, s.thump(110, 0.25, level=0.18), t0 + 0.3)

# ---- реальность: стрелки бегут (быстрое тиканье), три звонка, три толчка ----
s.mix(b, s.sine_pad([N(x) for x in ["D2", "A2", "F3"]], 6.0, attack=0.4, release=1.0, level=0.05), 2.45)
k = 0
tt0 = 2.5
while tt0 < 8.1:
    s.mix(b, s.tick(1900 if k % 2 else 1500, 0.04, level=0.035), tt0, pan=0.3)
    tt0 += 0.11
    k += 1
for i, r in enumerate([3.3, 4.9, 6.5]):
    s.mix(b, alarm(0.75, level=0.045 + 0.01 * i), r, pan=0.35)
    s.mix(b, s.pop(380, 0.12, level=0.12), r + 0.62, pan=0.2)     # лапка
    s.mix(b, s.whoosh(0.3, 1400, 500, level=0.04), r + 0.68, pan=0.3)  # будильник отъезжает
    # «Z» растут: низкая мягкая нота
    s.mix(b, s.felt(N(["A2", "G2", "F2"][i]), 1.5, level=0.12), r + 0.75, pan=-0.2)
    if i:
        s.mix(b, s.pluck(N(["C5", "F5"][i - 1]), 1.0, bright=0.6, level=0.10), r + 0.72)

# ---- совет: звонок у табурета, Тимка потягивается, прыгает, машет ----
s.mix(b, s.sine_pad([N(x) for x in ["F2", "C3", "A3", "E4"]], 4.6, attack=0.3, release=1.2, level=0.07), 8.45)
s.mix(b, alarm(1.75, level=0.04), 8.85, pan=0.4)
for i, x in enumerate(["F4", "A4", "C5", "F5"]):
    s.mix(b, s.pluck(N(x), 1.4, bright=0.5, level=0.10), 9.2 + i * 0.12, pan=-0.2 + 0.13 * i)
s.mix(b, s.whoosh(0.5, 500, 2200, level=0.05), 10.0)
s.mix(b, s.thump(140, 0.3, level=0.25), 10.55)
s.mix(b, s.pop(700, 0.1, level=0.10), 10.62, pan=0.3)
s.mix(b, s.sparkle(2600, 0.6, level=0.05), 11.25)
s.mix(b, s.sparkle(3100, 0.6, level=0.04), 11.6)
for x, t0 in [("C5", 11.0), ("A4", 11.4), ("F4", 11.8)]:
    s.mix(b, s.bell(N(x), 2.0, level=0.05), t0, pan=0.2)

b = s.reverb(b, seconds=1.8, wet=0.22)
b = s.loop_wrap(b, D)
n = int(round(length * s.SR))
if n > b.shape[1]:
    b = np.concatenate([b, b[:, : n - b.shape[1]]], axis=1)
b = b[:, :n]
b = s.master_lufs(b, target=-16.0, ceiling_db=-1.5)
b = s.fade_edges(b, ms=30)
s.write(out, b)
