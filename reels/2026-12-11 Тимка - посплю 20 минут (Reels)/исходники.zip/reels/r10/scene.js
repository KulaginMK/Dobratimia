// «Тимка — посплю 20 минут». 13 с, петля: кадр 13,0 совпадает с кадром 0. Серия «Тимка»: без голоса.
// Ожидание (0–2,45) → Реальность (2,45–8,45): будильник звенит трижды, Тимка трижды отодвигает его →
// Совет (8,45–12,6): будильник подальше от кровати, Тимка встаёт выспавшимся → раскрытие кругом обратно.
(function () {
  const { C, svg, tr, op, set } = R;
  const SKIN = '#F2B28A'; // цвет тела Тимки из timka-*.svg — для лапки
  /** Комната: кровать, тумбочка/табурет, будильник. layout(mode): 'near' — будильник у кровати, 'far' — подальше. */
  window.buildBedroom = function (g) {
    const bed = svg('g', {}, g);
    svg('rect', { x: 150, y: 960, width: 44, height: 290, rx: 16, fill: C.choco }, bed);
    svg('rect', { x: 150, y: 1150, width: 620, height: 64, rx: 16, fill: C.choco }, bed);
    svg('rect', { x: 176, y: 1206, width: 30, height: 48, rx: 8, fill: C.choco }, bed);
    svg('rect', { x: 716, y: 1206, width: 30, height: 48, rx: 8, fill: C.choco }, bed);
    svg('rect', { x: 190, y: 1116, width: 580, height: 44, rx: 18, fill: C.white }, bed);
    svg('ellipse', { cx: 285, cy: 1088, rx: 78, ry: 38, fill: C.white }, bed);
    const tkSlot = svg('g', {}, g); // Тимка между кроватью и одеялом
    const pawSlot = svg('g', {}, g); // лапка под одеялом
    const blanket = svg('rect', { x: 380, y: 1088, width: 412, height: 84, rx: 30, fill: C.primary }, g);
    const blanketFold = svg('rect', { x: 380, y: 1088, width: 412, height: 22, rx: 11, fill: C.soft, opacity: 0.55 }, g);
    const stand = svg('rect', { x: 800, y: 1110, width: 200, height: 140, rx: 16, fill: C.choco }, g);
    const knob = svg('circle', { cx: 900, cy: 1160, r: 9, fill: C.soft }, g);
    const stool = svg('g', {}, g);
    svg('rect', { x: 840, y: 1110, width: 180, height: 26, rx: 12, fill: C.choco }, stool);
    svg('rect', { x: 860, y: 1130, width: 22, height: 120, rx: 8, fill: C.choco }, stool);
    svg('rect', { x: 978, y: 1130, width: 22, height: 120, rx: 8, fill: C.choco }, stool);
    // будильник: центр (0,0)
    const clockG = svg('g', {}, g);
    const shake = svg('g', {}, clockG);
    const rings = svg('g', {}, shake);
    for (const s of [-1, 1]) {
      for (const r of [74, 94]) {
        const a0 = (-40 * Math.PI) / 180;
        const a1 = (40 * Math.PI) / 180;
        const p = (a) => [s * r * Math.cos(a), r * Math.sin(a) - 10];
        const [x0, y0] = p(a0);
        const [x1, y1] = p(a1);
        svg('path', { d: `M${x0} ${y0} A${r} ${r} 0 0 ${s > 0 ? 1 : 0} ${x1} ${y1}`, fill: 'none', stroke: C.text, 'stroke-width': 7, 'stroke-linecap': 'round' }, rings);
      }
    }
    svg('rect', { x: -36, y: 36, width: 14, height: 22, rx: 6, fill: C.choco, transform: 'rotate(20 -29 47)' }, shake);
    svg('rect', { x: 22, y: 36, width: 14, height: 22, rx: 6, fill: C.choco, transform: 'rotate(-20 29 47)' }, shake);
    const bellL = svg('circle', { cx: -36, cy: -44, r: 20, fill: C.honey }, shake);
    const bellR = svg('circle', { cx: 36, cy: -44, r: 20, fill: C.honey }, shake);
    svg('circle', { r: 54, fill: C.primary }, shake);
    svg('circle', { r: 42, fill: C.white }, shake);
    const arc = svg('path', { d: `M0 0 L0 -36 A36 36 0 0 1 ${36 * Math.sin((2 * Math.PI) / 3)} ${-36 * Math.cos((2 * Math.PI) / 3)} Z`, fill: C.honey, opacity: 0.55 }, shake);
    const hourH = svg('rect', { x: -4, y: -22, width: 8, height: 26, rx: 4, fill: C.text }, shake);
    const minH = svg('rect', { x: -3, y: -34, width: 6, height: 38, rx: 3, fill: C.text }, shake);
    svg('circle', { r: 5, fill: C.text }, shake);
    // лапка (поверх всего)
    const paw = svg('ellipse', { cx: 0, cy: 0, rx: 10, ry: 18, fill: SKIN }, pawSlot);
    return {
      tkSlot,
      layout(mode) {
        const far = mode === 'far';
        tr(bed, far ? 'translate(-110 0)' : '');
        tr(blanket, far ? 'translate(-110 0)' : '');
        tr(blanketFold, far ? 'translate(-110 0)' : '');
        op(stand, far ? 0 : 1);
        op(knob, far ? 0 : 1);
        op(stool, far ? 1 : 0);
      },
      /** c: { x, y, rot, ringK 0…1, min°, hour°, arc 0…1, wobble } */
      clock(c) {
        tr(clockG, `translate(${c.x} ${c.y})`);
        tr(shake, `rotate(${c.rot || 0} 0 50)`);
        op(rings, c.ringK || 0);
        tr(rings, `scale(${0.9 + 0.1 * (c.ringK || 0)})`);
        tr(minH, `rotate(${c.min || 0})`);
        tr(hourH, `rotate(${c.hour ?? 300})`);
        op(arc, (c.arc ?? 1) * 0.55);
        tr(bellL, `translate(${c.bell || 0} 0)`);
        tr(bellR, `translate(${-(c.bell || 0)} 0)`);
      },
      /** лапка от (x0, y0) длиной len, k 0…1 */
      paw(x0, y0, len, k) {
        if (k <= 0.001) return op(paw, 0);
        op(paw, 1);
        const L = 12 + len * k;
        set(paw, { cx: x0 + L / 2, cy: y0, rx: L / 2 + 8, ry: 18 });
      },
    };
  };
})();

(function () {
  if (new URLSearchParams(location.search).get('still')) return;
  const { C, clamp, lerp, ease, win, keys, svg, tr, op, set } = R;
  const D = 13;
  const TAU = Math.PI * 2;
  const per = (k) => (TAU * k) / D;
  const S = R.camStage(C.bg);

  // дальний план: мягкие пятна стены
  [
    [120, 560, 240, C.soft, 0.45],
    [980, 760, 160, C.growthSoft, 0.8],
    [90, 1620, 220, C.soft, 0.35],
    [1000, 1500, 200, C.growthSoft, 0.6],
  ].forEach(([x, y, r, c, o]) => svg('circle', { cx: x, cy: y, r, fill: c, opacity: o }, S.far));
  svg('rect', { x: -400, y: 1250, width: 1900, height: 900, fill: C.soft, opacity: 0.5 }, S.world);

  const room = window.buildBedroom(S.world);
  const mk = (name) => {
    const g = svg('g', {}, room.tkSlot);
    return { g, p: R.poseTimka(g, name, { noShadow: true }) };
  };
  const frontG = svg('g', {}, S.world); // Тимка перед кроватью и табуретом после прыжка
  const sleep = mk('sleep');
  const stretch = mk('stretch');
  const hello = mk('hello');

  // ---- тексты (поверх камеры) ----
  const chipBox = (text) => {
    const d = R.div({ style: { position: 'absolute', left: '0', top: '300px', width: '1080px', textAlign: 'center' } }, S.ui);
    R.div({ style: { display: 'inline-block', padding: '13px 34px', borderRadius: '999px', background: C.soft, color: C.onSoft, font: "600 42px 'Golos Text'", lineHeight: '52px' }, html: text }, d);
    return d;
  };
  const chipA = chipBox('Ожидание');
  const chipB = chipBox('Реальность');
  const plan = R.textBlock(S.ui, { text: 'Посплю\n20 минут', y: 400, size: 110, line: 122, color: C.text, words: true });
  const more = R.textBlock(S.ui, { text: 'Ещё 5 минут', y: 410, size: 100, line: 116, color: C.text, words: true });
  const counts = ['×2', '×3'].map((s) => R.textBlock(S.ui, { text: s, y: 530, size: 110, line: 124, color: C.primary }));
  const tipA = R.textBlock(S.ui, { text: 'Поставьте будильник\nподальше от кровати', y: 310, w: 1000, size: 88, line: 102, color: C.text, words: true });
  const tipB = R.textBlock(S.ui, { text: 'Короткий сон днём\nможет помочь взбодриться', y: 1500, w: 900, font: 'text', weight: 600, size: 46, line: 60, color: C.onSoft, words: true });
  // круг-переход (поверх всего)
  const wipeSvg = svg('svg', { width: 1080, height: 1920, viewBox: '0 0 1080 1920' }, S.ui);
  wipeSvg.style.cssText = 'position:absolute;left:0;top:0';
  const wipe = svg('circle', { cx: 0, cy: 0, r: 0, fill: C.primary }, wipeSvg);

  // ---- партитура ----
  const RINGS = [3.3, 4.9, 6.5]; // начало звонка; лапка через 0,55 с, толчок 0,7…0,95
  const PUSH = 45;
  // круг-переход: [начало, закрыт, открыт, откуда (мир), куда (мир)]; точки в мировых координатах, на экран — через камеру
  const WIPES = [
    [2.15, 2.45, 2.75, [860, 1050], [860, 1050]],
    [8.15, 8.45, 8.75, [950, 1050], [930, 1050]],
    [12.3, 12.6, 13.0, [930, 1050], [860, 1050]],
  ];
  const camOf = (m, t) => (m === 'A' ? { cx: 575, cy: 1010, z: 1.18 } : m === 'B' ? { cx: 690, cy: 1010, z: 1.38 } : { cx: 575, cy: 1040, z: 1.14 });
  const toScreen = (c, p) => [540 + (p[0] - c.cx) * c.z, 960 + (p[1] - c.cy) * c.z];
  const TS = 330;
  const BED_Y = 988; // центр рисунка Тимки в кровати

  window.renderAt = function (tRaw) {
    const t = Math.round((((tRaw % D) + D) % D) * 1e6) / 1e6;
    // режим сцены: A — ожидание, B — реальность, C — совет
    const mode = t < 2.45 || t >= 12.6 ? 'A' : t < 8.45 ? 'B' : 'C';
    room.layout(mode === 'C' ? 'far' : 'near');

    // ---- камера ----
    let cam;
    if (mode === 'A') cam = { cx: 575, cy: 1010, z: 1.18 };
    else if (mode === 'B') {
      const k = ease.inOutSine((t - 2.45) / 5.8);
      cam = { cx: lerp(575, 690, k), cy: 1010, z: lerp(1.18, 1.38, k) };
      // толчок камеры на звонках
      for (const r of RINGS) {
        const x = t - r;
        if (x > 0 && x < 0.6) cam.x = 5 * Math.sin(x * 70) * (1 - x / 0.6);
      }
    } else {
      const k = ease.inOutSine((t - 8.45) / 3.5);
      cam = { cx: 575, cy: 1040, z: lerp(1.2, 1.14, k) };
    }
    R.camApply(S, { ...cam, x: (cam.x || 0) + 5 * Math.sin(per(2) * t), y: 4 * Math.sin(per(1) * t + 1), r: 0.3 * Math.sin(per(1) * t) }, 0.4);

    // ---- будильник ----
    let pushes = 0;
    let ringK = 0;
    let rot = 0;
    let bell = 0;
    let slide = 0;
    let pawK = 0;
    if (mode === 'B') {
      RINGS.forEach((r, i) => {
        const x = t - r;
        if (x >= 0 && x < 0.75) {
          ringK = Math.max(ringK, Math.min(1, x / 0.05) * (x < 0.7 ? 1 : 1 - (x - 0.7) / 0.05));
          rot = 9 * Math.sin(x * 2 * Math.PI * 14);
          bell = 3 * Math.sin(x * 2 * Math.PI * 28);
        }
        pawK = Math.max(pawK, win(x, 0.5, 0.68, 0.82, 1.05, ease.outCubic));
        slide += PUSH * ease.outCubic((x - 0.68) / 0.3);
        if (x >= 0.7) pushes = i + 1;
      });
    }
    const clockX = mode === 'C' ? 930 : 860 + slide;
    const clockY = 1050;
    let minDeg = 0;
    if (mode === 'B') minDeg = 360 * 1.4 * Math.max(0, t - 2.5) * (1 - 0.0 * 0); // стрелки бегут
    if (mode === 'C') {
      const x = t - 8.85;
      if (x > 0 && x < 1.75) {
        ringK = Math.min(1, x / 0.05) * (x < 1.7 ? 1 : 1 - (x - 1.7) / 0.05);
        rot = 8 * Math.sin(x * 2 * Math.PI * 14);
        bell = 3 * Math.sin(x * 2 * Math.PI * 28);
      }
    }
    room.clock({ x: clockX, y: clockY, rot, ringK, bell, min: minDeg, hour: 300 + minDeg / 12, arc: mode === 'A' ? 1 : mode === 'B' ? 1 - clamp((t - 2.6) / 0.4) : 0 });

    // ---- Тимка ----
    // позы: A, B — sleep в кровати; C: sleep → stretch (9,2) → hello (9,95) прыжок к будильнику → машет
    const breathe = 0.5 - 0.5 * Math.cos(per(4) * t);
    let pose = 'sleep';
    let x = mode === 'C' ? 450 : 560;
    let y = BED_Y;
    let squash = 0;
    let lift = 0;
    let wave = 0;
    let rotT = 0;
    const sq = (t0) => {
      // короткое сжатие вокруг момента смены позы
      if (t >= t0 - 0.1 && t < t0) return ease.inCubic((t - (t0 - 0.1)) / 0.1) * 0.12;
      if (t >= t0 && t < t0 + 0.16) return (1 - ease.outCubic((t - t0) / 0.16)) * 0.12;
      return 0;
    };
    if (mode === 'C') {
      if (t >= 9.2) pose = 'stretch';
      if (t >= 9.95) pose = 'hello';
      squash = sq(9.2) + sq(9.95);
      if (pose === 'stretch') lift = 0.06 * win(t, 9.25, 9.5, 9.7, 9.9);
      // прыжок: 10,0 → 10,55 по дуге к табурету
      const h = clamp((t - 10.0) / 0.55);
      const hx = ease.inOutSine(h);
      if (t >= 10.0) {
        x = lerp(450, 730, hx);
        y = lerp(BED_Y, 1158, hx) - 230 * Math.sin(Math.PI * h);
        rotT = 10 * Math.sin(Math.PI * h);
      }
      squash += t >= 10.55 && t < 10.8 ? 0.14 * Math.sin((Math.PI * (t - 10.55)) / 0.25) : 0;
      // лапка к будильнику (10,62), будильник замолкает; потом машет в камеру
      wave = R.waveAngle(t, 11.25, 2) + -35 * win(t, 10.6, 10.68, 10.82, 10.95);
    }
    const z = (mode === 'A' ? 1 : mode === 'B' ? 1 + 0.45 * pushes + 0.25 * clamp((t - 2.6) / 0.6) : 1) ;
    for (const [name, P] of [['sleep', sleep], ['stretch', stretch], ['hello', hello]]) {
      const on = pose === name;
      op(P.g, on ? 1 : 0);
      if (!on) continue;
      P.p.update({ t, x, y, size: TS, rot: rotT, squash, lift: name === 'sleep' ? 0.015 * breathe : lift, sway: 3 * Math.sin(per(3) * t), wave, blink: name === 'hello' ? R.blinkAt(t, D / 4, 0.3) : 1, zzz: breathe });
      if (name === 'sleep' && P.p.parts.zzz) {
        const zz = P.p.parts.zzz;
        const zs = mode === 'C' ? 1 - ease.inOutSine((t - 8.9) / 0.3) : z;
        tr(zz, `translate(${96 * (1 - zs)} ${30 * (1 - zs) - 3 * breathe}) scale(${Math.max(0.001, zs)})`);
        op(zz, mode === 'C' ? clamp(zs) : 1 - 0.35 * breathe);
      }
    }
    // лапка из-под бока к будильнику (реальность)
    room.paw(730, 1102, Math.max(0, clockX - 40 - 730), pawK);
    const parent = mode === 'C' && t >= 9.95 ? frontG : room.tkSlot;
    if (hello.g.parentNode !== parent) parent.appendChild(hello.g);

    // ---- тексты ----
    op(chipA, mode === 'A' ? 1 : 0);
    if (mode === 'A') {
      if (t < 2.45) R.wordsIn(plan, 1);
      else R.wordsIn(plan, clamp((t - 12.62) / 0.35), { spread: 0.4 });
      op(plan, 1);
    } else op(plan, 0);
    op(chipB, mode === 'B' ? 1 : 0);
    if (mode === 'B' && t > 4.0) {
      op(more, 1);
      R.wordsIn(more, clamp((t - 4.0) / 0.4), { spread: 0.4, rise: 20 });
    } else op(more, 0);
    counts.forEach((n, i) => {
      if (mode !== 'B' || pushes < i + 2) return op(n, 0);
      const r0 = RINGS[i + 1] + 0.7;
      const k = ease.outCubic((t - r0) / 0.25);
      const out = i === 0 && pushes >= 3 ? 1 : 0;
      R.place(n, { o: 1 - out, s: lerp(1.5, 1, k), y: 0 });
    });
    if (mode === 'C') {
      op(tipA, 1);
      R.wordsIn(tipA, clamp((t - 8.75) / 0.6), { spread: 0.45 });
      op(tipB, win(t, 9.9, 10.3, 13, 14));
      R.wordsIn(tipB, clamp((t - 9.9) / 0.6), { spread: 0.4, rise: 18 });
    } else {
      op(tipA, 0);
      op(tipB, 0);
    }

    // ---- круг-переход: растёт из точки, закрывает кадр; потом сжимается в другую точку ----
    let wr = 0;
    let wc = [0, 0];
    for (const [a, m, b, c0, c1] of WIPES) {
      if (t >= a && t < m) {
        wr = 1500 * ease.inCubic((t - a) / (m - a));
        wc = toScreen(cam, c0);
      } else if (t >= m && t < b) {
        wr = 1500 * (1 - ease.outCubic((t - m) / (b - m)));
        wc = toScreen(cam, c1);
      }
    }
    set(wipe, { cx: wc[0], cy: wc[1], r: Math.max(0, wr) });
  };

  R.ready().then(() => {
    window.READY = true;
  });
})();
