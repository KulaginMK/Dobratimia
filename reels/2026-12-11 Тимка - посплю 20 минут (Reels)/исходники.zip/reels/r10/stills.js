// Обложка и кадр сторис: «Посплю 20 минут» и Тимка в кровати с будильником.
(function () {
  const kind = new URLSearchParams(location.search).get('still');
  if (!kind) return;
  const { C, svg } = R;
  const S = R.stage(C.bg);
  const scene = (tf, zzz = 1.6) => {
    const g = svg('g', { transform: tf }, S.world);
    svg('rect', { x: -400, y: 1250, width: 1900, height: 900, fill: C.soft, opacity: 0.5 }, g);
    const room = window.buildBedroom(g);
    room.layout('near');
    room.paw(0, 0, 0, 0);
    room.clock({ x: 905, y: 1050, rot: 8, ringK: 1, bell: 2, min: 220, hour: 330, arc: 0.6 });
    const p = R.poseTimka(room.tkSlot, 'sleep', { noShadow: true });
    p.update({ t: 0, x: 560, y: 988, size: 330, zzz: 0.4 });
    p.parts.zzz.setAttribute('transform', `translate(${96 * (1 - zzz)} ${30 * (1 - zzz)}) scale(${zzz})`);
  };
  if (kind === 'cover') {
    R.chip(S, { text: 'Ожидание / реальность', y: 300 });
    R.textBlock(S.text, { text: 'Посплю\n20 минут', y: 400, size: 130, line: 140, color: C.text });
    scene('translate(540 1040) scale(1.05) translate(-575 -1010)');
    R.textBlock(S.text, { text: 'Будильник звенит в третий раз', y: 1500, size: 46, line: 58, w: 900, font: 'text', weight: 600, color: C.onSoft });
  } else {
    R.wordmark(S, { y: 300, h: 76 });
    R.textBlock(S.text, { text: 'Сколько раз вы\nоткладываете будильник?', y: 440, size: 80, line: 94, w: 1000, color: C.text });
    scene('translate(540 960) scale(0.62) translate(-575 -1010)');
    R.textBlock(S.text, { text: 'Ответьте в опросе ниже', y: 1240, size: 44, line: 56, font: 'text', weight: 600, color: C.onSoft });
  }
  window.renderAt = () => {};
  R.ready().then(() => (window.READY = true));
})();
