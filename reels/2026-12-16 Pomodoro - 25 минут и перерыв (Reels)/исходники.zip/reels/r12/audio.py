"""Звук «Pomodoro — 25 минут и перерыв»: лёгкий грув маримбы (до мажор, 100 уд/мин), тиканье таймера, звонок перерыва; всё синтезировано кодом.
python3 reels/r12/audio.py out/audio.wav [длительность]"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "engine"))
import numpy as np
import synth as s
from synth import note as N

D = 18.0
out = sys.argv[1]
length = float(sys.argv[2]) if len(sys.argv) > 2 else D
b = s.buf(D + 6)
beat = 0.6  # 100 уд/мин: 30 долей за 18 с — петля в такт

# ---- аккорды и бас по тактам (4 доли = 2,4 с) ----
prog = [["C3", "E3", "G3"], ["A2", "C3", "E3"], ["F2", "A2", "C3"], ["G2", "B2", "D3"]]
bar = 4 * beat
k = 0
tb = 0.0
while tb < D - 0.01:
    ch = prog[k % 4]
    s.mix(b, s.sine_pad([N(x) for x in ch], bar, attack=0.05, release=0.6, level=0.05), tb)
    s.mix(b, s.felt(N(ch[0]) / 2, 1.0, level=0.12), tb)
    s.mix(b, s.felt(N(ch[0]) / 2, 0.8, level=0.08), tb + 2 * beat)
    tb += bar
    k += 1
# ---- хук: книги падают на стопку ----
for i in range(1, 6):
    s.mix(b, s.thump(160 + 20 * i, 0.18, level=0.16), 0.25 + i * 0.32 + 0.2, pan=-0.3)
    s.mix(b, s.pop(500 + 60 * i, 0.08, level=0.05), 0.25 + i * 0.32 + 0.2, pan=-0.3)
s.mix(b, s.whoosh(0.4, 2000, 400, level=0.06), 2.6)
# ---- таймер фокуса: быстрое тиканье и мелодия маримбы ----
t0 = 3.0
while t0 < 7.0:
    s.mix(b, s.tick(1800, 0.04, level=0.03), t0, pan=0.25)
    t0 += 0.15
mel = ["E5", "G5", "C6", "G5", "E5", "D5", "C5", "D5"]
for i, x in enumerate(mel):
    s.mix(b, s.pluck(N(x), 1.2, bright=0.5, level=0.08), 3.0 + i * beat, pan=0.15)
# ---- звонок перерыва ----
for i, x in enumerate(["C6", "G5", "C6"]):
    s.mix(b, s.bell(N(x), 2.0, level=0.09), 7.0 + i * 0.12, pan=0.1)
s.mix(b, s.whoosh(0.6, 400, 2400, level=0.06), 7.55)  # потягивается
for i, x in enumerate(["C5", "E5", "G5", "A5"]):
    s.mix(b, s.pluck(N(x), 1.6, bright=0.3, level=0.07), 7.8 + i * 0.6, pan=-0.2)
# ---- ускоренно: три «помидора» ----
for i in range(3):
    a = 11.4 + i
    for j in range(5):
        s.mix(b, s.tick(2000, 0.03, level=0.03), a + j * 0.15, pan=0.25)
    s.mix(b, s.bell(N(["E6", "G6", "C7"][i]), 1.2, level=0.06), a + 0.75)
    s.mix(b, s.pop(700 + 150 * i, 0.1, level=0.07), a + 0.78)
# ---- финал: знак ----
for i, x in enumerate(["C5", "E5", "G5", "C6"]):
    s.mix(b, s.bell(N(x), 2.5, level=0.06), 14.75 + i * 0.14, pan=0.2)
s.mix(b, s.sparkle(2800, 0.8, level=0.05), 15.2)
s.mix(b, s.whoosh(0.5, 300, 1500, level=0.04), 17.1)

b = s.reverb(b, seconds=1.6, wet=0.2)
b = s.loop_wrap(b, D)
n = int(round(length * s.SR))
if n > b.shape[1]:
    b = np.concatenate([b, b[:, : n - b.shape[1]]], axis=1)
b = b[:, :n]
b = s.master_lufs(b, target=-16.0, ceiling_db=-1.5)
b = s.fade_edges(b, ms=30)
s.write(out, b)
