// Обложка и кадр сторис: таймер Pomodoro и Тимка за конспектом.
(function () {
  const kind = new URLSearchParams(location.search).get('still');
  if (!kind) return;
  const { C, svg, tr } = R;
  const S = R.stage(C.bg);
  const draw = (tf, o) => {
    const g = svg('g', { transform: tf }, S.world);
    const back = svg('g', {}, g);
    const tk = R.breathingTimka(svg('g', {}, g));
    const front = svg('g', {}, g);
    const desk = window.buildDesk(back, front);
    for (let i = 0; i < 6; i++) desk.setBook(i, 0, 0, 0);
    tr(desk.paw, 'translate(650 1508)');
    tk.update({ t: 0.5, fill: 0.35, face: { kind: 'look', from: 'look', shift: 1 }, x: 540, y: 1416, size: 300, eyeDx: 1, eyeDy: 2.4, noBlink: true });
    if (o.ui) {
      const ui = window.buildPomodoro(g, o.text);
      ui.update({ mode: 'focus', share: 0.64, ms: (16 * 60 + 5) * 1000, tomato: 2, o: 1 });
    }
  };
  if (kind === 'cover') {
    R.textBlock(S.text, { text: '25 минут\nи перерыв', y: 300, size: 116, line: 126, color: C.text });
    const box = R.div({ style: { position: 'absolute', left: '0', top: '0', width: '1080px', height: '1920px', transform: 'translate(0 , 150px)' } }, S.text);
    box.style.transform = 'translate(0px, 100px)';
    draw('translate(0 100)', { ui: true, text: box });
  } else {
    R.wordmark(S, { y: 300, h: 76 });
    R.textBlock(S.text, { text: 'Сколько вы учитесь\nбез перерыва?', y: 440, size: 84, line: 98, w: 1000, color: C.text });
    draw('translate(540 1010) scale(0.95) translate(-540 -1450)', { ui: false });
    R.textBlock(S.text, { text: 'Ответьте в опросе ниже', y: 1200, size: 44, line: 56, font: 'text', weight: 600, color: C.onSoft });
  }
  window.renderAt = () => {};
  R.ready().then(() => (window.READY = true));
})();
