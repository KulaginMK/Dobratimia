// «Pomodoro — 25 минут и перерыв». 18 с, петля: кадр 18,0 совпадает с кадром 0.
// Интерфейс — как на экране Pomodoro приложения (handoff/reference/screens-png/Pomodoro.png, PomodoroTab.tsx):
// чипы «Фокус · 25 мин» / «Перерыв · 5 мин», кольцевой таймер с подписью «до перерыва» / «до конца перерыва»,
// точки «Помидор N из 4», кнопки «Пауза» и «Пропустить». Цифры: фокус 25 мин, перерыв 5 мин, 4 «помидора».
(function () {
  const { C, svg, div, tr, op, set } = R;
  const SKIN = '#F2B28A';
  /** Интерфейс Pomodoro в мировых координатах. text — HTML-слой камеры, g — SVG-слой. */
  window.buildPomodoro = function (g, text) {
    const check = `<svg width="30" height="30" viewBox="0 0 30 30" style="vertical-align:-5px;margin-right:10px"><path d="M6 15.5 L12.5 22 L24.5 8.5" fill="none" stroke="${C.onSoft}" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    const chipStyle = (sel) => ({ display: 'inline-block', padding: '10px 30px', borderRadius: '999px', font: "600 38px 'Golos Text'", lineHeight: '46px', whiteSpace: 'nowrap', margin: '0 10px', boxSizing: 'border-box', border: `3px solid ${sel ? C.primary : 'rgba(107,58,42,0.22)'}`, background: sel ? C.soft : C.bg, color: sel ? C.onSoft : C.text });
    const row = div({ style: { position: 'absolute', left: '0', top: '512px', width: '1080px', textAlign: 'center' } }, text);
    const chips = {};
    for (const [mode, label] of [['focus', 'Фокус · 25 мин'], ['break', 'Перерыв · 5 мин']]) {
      const wrap = div({ style: { display: 'inline-block', position: 'relative' } }, row);
      chips[mode] = {
        off: div({ style: chipStyle(false), html: check.replace('<svg ', '<svg visibility="hidden" ') + label }, wrap),
        on: div({ style: { ...chipStyle(true), position: 'absolute', left: '0', top: '0' }, html: check + label }, wrap),
        wrap,
      };
    }
    // ширина чипа «выбран» больше из-за галочки: подстраиваем, чтобы ряд не прыгал
    const ringG = svg('g', {}, g);
    const RC = { x: 540, y: 845, r: 228 };
    svg('circle', { cx: RC.x, cy: RC.y, r: RC.r, fill: 'none', stroke: C.soft, 'stroke-width': 34, opacity: 0.7 }, ringG);
    const arc = svg('path', { fill: 'none', stroke: C.primary, 'stroke-width': 34, 'stroke-linecap': 'round' }, ringG);
    const digits = div({ style: { position: 'absolute', left: '240px', top: '760px', width: '600px', textAlign: 'center', font: "900 120px 'Nunito'", lineHeight: '132px', color: C.text, letterSpacing: '-0.02em' }, html: '25:00' }, text);
    const capF = div({ style: { position: 'absolute', left: '240px', top: '896px', width: '600px', textAlign: 'center', font: "400 38px 'Golos Text'", lineHeight: '46px', color: C.text, opacity: 0.75 }, html: 'до перерыва' }, text);
    const capB = div({ style: { position: 'absolute', left: '240px', top: '896px', width: '600px', textAlign: 'center', font: "400 38px 'Golos Text'", lineHeight: '46px', color: C.text, opacity: 0.75 }, html: 'до конца перерыва' }, text);
    // точки
    const dots = [0, 1, 2, 3].map((i) => svg('circle', { cx: 300 + i * 46, cy: 1134, r: 14, fill: C.bg, stroke: C.choco, 'stroke-width': 3.5, 'stroke-opacity': 0.55 }, g));
    const label = div({ style: { position: 'absolute', left: '470px', top: '1110px', width: '420px', font: "400 38px 'Golos Text'", lineHeight: '48px', color: C.text, opacity: 0.8 }, html: 'Помидор 1 из 4' }, text);
    // кнопки
    const btns = div({ style: { position: 'absolute', left: '110px', top: '1186px', width: '860px', height: '96px', display: 'flex', gap: '20px' } }, text);
    const pause = `<svg width="30" height="34" viewBox="0 0 30 34" style="margin-right:16px"><rect x="3" y="3" width="8" height="28" rx="2.5" fill="#FFFFFF"/><rect x="19" y="3" width="8" height="28" rx="2.5" fill="#FFFFFF"/></svg>`;
    div({ style: { flex: '2', borderRadius: '28px', background: C.primary, color: C.white, display: 'flex', alignItems: 'center', justifyContent: 'center', font: "600 42px 'Golos Text'" }, html: pause + 'Пауза' }, btns);
    div({ style: { flex: '1.25', borderRadius: '28px', border: `3px solid rgba(107,58,42,0.5)`, boxSizing: 'border-box', color: C.text, display: 'flex', alignItems: 'center', justifyContent: 'center', font: "600 40px 'Golos Text'" }, html: 'Пропустить' }, btns);
    const all = [row, digits, btns, label];
    const logo = R.logo(g, 'logo-mark');
    return {
      RC,
      /** s: { mode, share 0…1, ms, tomato, o, pulse } */
      update(s) {
        const a0 = -Math.PI / 2;
        const a1 = a0 + 2 * Math.PI * Math.max(0.0005, s.share);
        const p = (a) => [RC.x + RC.r * Math.cos(a), RC.y + RC.r * Math.sin(a)];
        const [x0, y0] = p(a0);
        const [x1, y1] = p(a1);
        set(arc, { d: `M${x0} ${y0} A${RC.r} ${RC.r} 0 ${s.share > 0.5 ? 1 : 0} 1 ${x1} ${y1}`, opacity: s.share > 0.002 ? 1 : 0 });
        tr(ringG, `translate(${RC.x} ${RC.y}) scale(${1 + 0.04 * (s.pulse || 0)}) translate(${-RC.x} ${-RC.y})`);
        const sec = Math.ceil(s.ms / 1000);
        digits.textContent = `${String(Math.floor(sec / 60)).padStart(2, '0')}:${String(sec % 60).padStart(2, '0')}`;
        const f = s.mode === 'focus';
        op(capF, (f ? 1 : 0) * s.o * 0.75);
        op(capB, (f ? 0 : 1) * s.o * 0.75);
        op(chips.focus.on, f ? 1 : 0);
        op(chips.break.on, f ? 0 : 1);
        chips.focus.off.style.visibility = f ? 'hidden' : 'visible';
        chips.break.off.style.visibility = f ? 'visible' : 'hidden';
        const done = f ? s.tomato - 1 : s.tomato;
        dots.forEach((d, i) => set(d, i < done ? { fill: C.primary, 'stroke-width': 0 } : { fill: C.bg, 'stroke-width': 3.5 }));
        label.textContent = `Помидор ${s.tomato} из 4`;
        for (const n of all) op(n, s.o * (1 - (s.end || 0)));
        op(capF, (f ? 1 : 0) * s.o * 0.75 * (1 - (s.end || 0)));
        op(capB, (f ? 0 : 1) * s.o * 0.75 * (1 - (s.end || 0)));
        op(ringG, s.o);
        dots.forEach((d) => op(d, s.o * (1 - (s.end || 0))));
        logo.at(RC.x, RC.y, 230 * (0.9 + 0.1 * (s.logo || 0)), (s.logo || 0) * s.o);
      },
    };
  };
  /** Стол, конспект, стопка книг, лапка с ручкой. */
  window.buildDesk = function (back, front) {
    const books = [C.primary, C.choco, C.soft, C.primary, C.choco, C.soft].map((c, i) => {
      const b = svg('g', {}, back);
      svg('rect', { x: -88 + (i % 2) * 8, y: -17, width: 170 - (i % 3) * 10, height: 34, rx: 8, fill: c }, b);
      svg('rect', { x: 52 - (i % 3) * 10, y: -11, width: 18, height: 22, rx: 4, fill: C.white, opacity: 0.5 }, b);
      return b;
    });
    svg('rect', { x: 190, y: 1540, width: 700, height: 52, rx: 18, fill: C.primary }, front);
    const nb = svg('g', { transform: 'translate(540 1518)' }, front);
    svg('rect', { x: -130, y: -24, width: 260, height: 40, rx: 8, fill: C.white }, nb);
    svg('rect', { x: -3, y: -24, width: 6, height: 40, fill: C.soft }, nb);
    for (const [x, w] of [[-112, 80], [-112, 54], [18, 86], [18, 60]]) svg('rect', { x, y: w > 70 ? -14 : 0, width: w, height: 7, rx: 3.5, fill: C.choco, opacity: 0.35 }, nb);
    const paw = svg('g', {}, front);
    const pen = svg('rect', { x: -6, y: -58, width: 12, height: 62, rx: 6, fill: C.honey, transform: 'rotate(18)' }, paw);
    svg('ellipse', { cx: 0, cy: 0, rx: 22, ry: 17, fill: SKIN }, paw);
    return {
      books,
      paw,
      setBook(i, x, y, o, r = 0) {
        tr(books[i], `translate(${x} ${y}) rotate(${r})`);
        op(books[i], o);
      },
    };
  };
})();

(function () {
  if (new URLSearchParams(location.search).get('still')) return;
  const { C, clamp, lerp, ease, win, svg, tr, op, set } = R;
  const D = 18;
  const TAU = Math.PI * 2;
  const per = (k) => (TAU * k) / D;
  const S = R.camStage(C.bg);
  [
    [110, 420, 230, C.soft, 0.4],
    [1000, 1250, 170, C.growthSoft, 0.8],
    [80, 1700, 240, C.soft, 0.35],
  ].forEach(([x, y, r, c, o]) => svg('circle', { cx: x, cy: y, r, fill: c, opacity: o }, S.far));
  const back = svg('g', {}, S.world);
  const tkG = svg('g', {}, S.world);
  const tk = R.breathingTimka(tkG);
  const stG = svg('g', {}, S.world);
  const st = R.poseTimka(stG, 'stretch', { noShadow: true });
  const front = svg('g', {}, S.world);
  const desk = window.buildDesk(back, front);
  const ui = window.buildPomodoro(S.world, S.text);

  // ---- подписи (поверх камеры) ----
  const T = (text, opt = {}) => R.textBlock(S.ui, { text, y: 300, w: 1000, size: 84, line: 98, color: C.text, words: true, ...opt });
  const hook = T('Учиться 3 часа\nподряд?', { size: 96, line: 110 });
  const focusT = T('25 минут учёбы');
  const breakT = T('5 минут перерыва:\nвстаньте и потянитесь', { size: 76, line: 90 });
  const roundT = T('Один круг:\n4 «помидора»', { size: 84 });
  const endT = T('Pomodoro есть\nв приложении «Добратимия»', { size: 76, line: 90 });

  const TX = 540;
  const TY = 1416;
  const TS = 300;
  const FOCUS = 25 * 60000;
  const BREAK = 5 * 60000;
  // ---- состояние таймера по времени ролика ----
  function timer(t) {
    if (t < 3.0) return { mode: 'focus', share: 1, ms: FOCUS, tomato: 1 };
    if (t < 7.0) {
      const k = ease.inOutSine((t - 3.0) / 4.0);
      return { mode: 'focus', share: 1 - k, ms: FOCUS * (1 - k), tomato: 1 };
    }
    if (t < 7.6) return { mode: 'focus', share: 0, ms: 0, tomato: 1 };
    if (t < 11.4) {
      const k = clamp((t - 7.6) / 3.8);
      return { mode: 'break', share: 1 - 0.55 * k, ms: BREAK * (1 - 0.55 * k), tomato: 1 };
    }
    if (t < 14.4) {
      // ускоренно: помидоры 2, 3, 4 — по 1 с (фокус 0,75 с, перерыв 0,25 с)
      const i = Math.floor((t - 11.4) / 1.0);
      const x = (t - 11.4) % 1.0;
      if (x < 0.75) {
        const k = x / 0.75;
        return { mode: 'focus', share: 1 - k, ms: FOCUS * (1 - k), tomato: i + 2 };
      }
      const k = (x - 0.75) / 0.25;
      return { mode: 'break', share: 1 - k, ms: BREAK * (1 - k), tomato: i + 2 };
    }
    return { mode: 'break', share: 0, ms: 0, tomato: 4 };
  }

  window.renderAt = function (tRaw) {
    const t = Math.round((((tRaw % D) + D) % D) * 1e6) / 1e6;
    // ---- камера: близко к столу на хуке → отъезд к интерфейсу → назад к столу на шве ----
    const out = ease.inOutCubic(clamp((t - 2.5) / 0.9));
    const backIn = ease.inOutCubic(clamp((t - 17.15) / 0.85));
    const brk = 0;
    const k = out * (1 - backIn);
    const cam = { cx: 540, cy: lerp(1370, 950, k) + 40 * brk, z: lerp(1.42, 1.0, k) + 0.06 * brk };
    R.camApply(S, { ...cam, x: 5 * Math.sin(per(2) * t), y: 4 * Math.sin(per(1) * t + 1), r: 0.3 * Math.sin(per(1) * t) }, 0.4);

    // ---- интерфейс ----
    const s = timer(t);
    const uiO = win(t, 3.05, 3.4, 16.9, 17.3);
    const ringPulse = win(t, 7.0, 7.08, 7.25, 7.6) + [11.4, 12.4, 13.4].reduce((a, b) => a + win(t, b + 0.75, b + 0.8, b + 0.85, b + 1.0) * 0.6, 0);
    const endK = ease.inOutSine(clamp((t - 14.5) / 0.4));
    const logoK = ease.outCubic(clamp((t - 14.75) / 0.5));
    ui.update({ ...s, o: uiO, pulse: ringPulse, end: endK, logo: logoK });

    // ---- книги: стопка растёт на хуке, уезжает влево, когда включается таймер ----
    for (let i = 0; i < 6; i++) {
      const at = i === 0 ? -1 : 0.25 + i * 0.32;
      const inK = i === 0 ? (t >= 17.45 ? ease.outCubic((t - 17.45) / 0.35) : 1) : ease.outCubic(clamp((t - at) / 0.22));
      const drop = (1 - inK) * -120;
      const leave = i === 0 && t >= 17.45 ? 0 : ease.inCubic(clamp((t - (2.6 + i * 0.04)) / 0.35));
      const back0 = i === 0 && t >= 17.45 ? (1 - inK) * -600 : 0;
      const gone = t >= 2.95 && !(i === 0 && t >= 17.45);
      const x = 300 - 700 * leave + back0;
      const y = 1523 - i * 34 + drop;
      desk.setBook(i, x, y, gone ? 0 : i === 0 ? 1 : clamp(inK * 3), (i % 2 ? 2 : -2) + 10 * (1 - inK) * (i ? 1 : 0));
    }

    // ---- Тимка: за конспектом (дыхательная фигура, лицо look) ↔ перерыв (поза stretch) ----
    const breakPose = t >= 7.6 && t < 11.4;
    const sq = (t0) => (t >= t0 - 0.1 && t < t0 ? ease.inCubic((t - (t0 - 0.1)) / 0.1) * 0.12 : t >= t0 && t < t0 + 0.16 ? (1 - ease.outCubic((t - t0) / 0.16)) * 0.12 : 0);
    const squash = sq(7.6) + sq(11.4);
    op(tkG, breakPose ? 0 : 1);
    op(stG, breakPose ? 1 : 0);
    const writing = !breakPose && t > 3.0 && t < 17.0;
    // взгляд: на хуке — на растущую стопку; за работой — по строчкам конспекта
    const hookLook = t < 2.7 || t > 17.4;
    const read = writing ? 2.2 * Math.sin(t * 7) : 0;
    const eyeDx = hookLook ? -2.6 : read;
    const eyeDy = hookLook ? -2.2 : writing ? 2.4 : 0;
    if (!breakPose) {
      tk.update({ t, fill: 0.35 + 0.05 * Math.sin(per(9) * t), face: { kind: 'look', from: 'look', shift: 1 }, x: TX, y: TY, size: TS, eyeDx, eyeDy, idleSpeed: per(18), blinkEvery: D / 5, extraY: -squash, extraX: squash * 0.6 });
    } else {
      const lift = 0.07 * win(t, 7.75, 8.2, 10.8, 11.25);
      st.update({ t, x: TX, y: TY - 14 * win(t, 7.7, 8.0, 11.0, 11.35), size: TS, squash, lift, sway: 4 * Math.sin(per(9) * t) });
    }
    // лапка с ручкой: пишет
    const px = 640 + (writing ? 18 * Math.sin(t * 11) + 6 * Math.sin(t * 23) : 0);
    const py = 1508 + (writing ? 4 * Math.sin(t * 17) : 0);
    tr(desk.paw, `translate(${px} ${py})`);
    op(desk.paw, breakPose ? 0 : 1);

    // ---- подписи ----
    const cap = (n, a, b, c, d) => {
      const o = win(t, a, a + 0.01, c, d);
      op(n, o);
      if (o > 0) R.wordsIn(n, clamp((t - a) / (b - a)), { spread: 0.45 });
    };
    if (t < 2.75) {
      op(hook, 1 - ease.inOutSine((t - 2.45) / 0.3));
      R.wordsIn(hook, 1);
    } else if (t >= 17.35) {
      op(hook, 1);
      R.wordsIn(hook, clamp((t - 17.35) / 0.6));
    } else op(hook, 0);
    cap(focusT, 3.0, 3.5, 6.9, 7.2);
    cap(breakT, 7.65, 8.3, 11.1, 11.4);
    cap(roundT, 11.5, 12.1, 14.4, 14.7);
    cap(endT, 14.75, 15.4, 16.9, 17.25);
  };

  R.ready().then(() => {
    window.READY = true;
  });
})();
