"""Звук «Тимка — как прошла неделя»: грув 120 уд/мин, ми-бемоль мажор; всё синтезировано кодом.
12,5 с = 6 тактов по 4 доли + затакт, который ведёт обратно в начало петли.
python3 reels/r4/audio.py out/audio.wav [длительность]"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "engine"))
import numpy as np
import synth as s
from synth import note as N

D = 12.5
out = sys.argv[1]
length = float(sys.argv[2]) if len(sys.argv) > 2 else D
BEAT = 0.5
b = s.buf(D + 4)

def shaker(at, level):
    n = int(0.04 * s.SR)
    x = s.highpass(s.noise(n), 6000) * np.exp(-np.arange(n) / s.SR * 80)
    s.mix(b, x * level, at, pan=0.3)

bars = [
    (0.0, ["D#4", "G4", "A#4"], "D#2"),
    (2.0, ["C4", "D#4", "G4"], "C2"),
    (4.0, ["G#3", "C4", "D#4"], "G#1"),
    (6.0, ["A#3", "D4", "F4"], "A#1"),
    (8.0, ["D#4", "G4", "A#4"], "D#2"),
    (10.0, ["G#3", "C4", "D#4"], "G#1"),
]
for t0, ch, bass in bars:
    for k in range(8):  # восьмые маримбы
        f = N(ch[[0, 1, 2, 1, 0, 1, 2, 1][k]]) * (2 if k in (2, 6) else 1)
        s.mix(b, s.pluck(f, 0.9, bright=0.6, level=0.075 if k % 2 else 0.095), t0 + k * BEAT / 2, pan=-0.35 + 0.7 * (k % 4) / 3)
        shaker(t0 + k * BEAT / 2 + BEAT / 4, 0.02)
    for k in (0, 2):
        s.mix(b, s.felt(N(bass), 0.9, level=0.24), t0 + k * BEAT)
        s.mix(b, s.thump(60, 0.25, level=0.14), t0 + k * BEAT)
    for k in (1, 3):
        s.mix(b, s.tick(2600, 0.04, level=0.05), t0 + k * BEAT, pan=-0.2)
# затакт 12,0–12,5: си-бемоль, нота-подхват ведёт в начало
s.mix(b, s.felt(N("A#1"), 0.6, level=0.22), 12.0)
for i, x in enumerate(["F4", "G4"]):
    s.mix(b, s.pluck(N(x), 0.8, level=0.09), 12.0 + i * 0.25)

# ---- события ----
for t0 in (0.25, 0.73, 7.1):  # взмахи
    s.mix(b, s.whoosh(0.22, 900, 3000, level=0.05), t0, pan=0.4)
for t0, f in ((2.0, N("D#5")), (3.5, N("G5")), (5.0, N("A#5"))):  # строки 1, 2, 3
    s.mix(b, s.pop(f, 0.14, level=0.13), t0)
    s.mix(b, s.pluck(f, 1.2, bright=0.3, level=0.06), t0 + 0.02)
for t0 in (2.0, 3.5, 5.0, 7.0, 10.0, 12.0):  # смена позы: мягкое «буп»
    s.mix(b, s.pop(380, 0.1, level=0.07), t0 - 0.04, pan=-0.1)
t = s.tt(0.32)
s.mix(b, np.sin(2 * np.pi * np.cumsum(500 * 2 ** (t / 0.32)) / s.SR) * np.exp(-t * 6) * 0.06, 2.02)  # потянулся вверх
s.mix(b, s.breath(0.5, "in", level=0.04), 3.5)  # надул щёки
s.mix(b, s.sparkle(2800, 0.5, level=0.04), 3.7, pan=0.4)
t = s.tt(0.6)
s.mix(b, np.sin(2 * np.pi * np.cumsum(700 * 2 ** (-t / 0.6)) / s.SR) * np.sin(np.pi * t / 0.6) * 0.05, 5.05)  # зевок вниз
s.mix(b, s.pop(900, 0.1, level=0.06), 7.15, pan=0.4)  # пузырь
for t0 in (7.6, 8.3, 9.0):  # цифры в комментарии
    s.mix(b, s.tick(3400, 0.035, level=0.10), t0, pan=0.4)
for t0 in (8.0, 8.3):  # кивки
    s.mix(b, s.thump(140, 0.12, level=0.07), t0)
s.mix(b, s.bell(N("D#6"), 2.5, level=0.06), 10.0)
s.mix(b, s.breath(0.85, "in", level=0.06), 10.15)
s.mix(b, s.breath(0.9, "out", level=0.07), 11.0)

b = s.reverb(b, seconds=1.6, wet=0.18)
b = s.loop_wrap(b, D)
n = int(round(length * s.SR))
if n > b.shape[1]:
    b = np.concatenate([b, b[:, : n - b.shape[1]]], axis=1)
b = b[:, :n]
b = s.master_lufs(b, target=-15.0, ceiling_db=-1.5)
s.write(out, b)
