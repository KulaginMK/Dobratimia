// «Дыши с Тимкой — 5-5-5 перед ответом». 55 с, аудитория: доска, часы, парта; петля: кадр 55,0 совпадает с кадром 0.
(function () {
  const { C, svg, tr } = R;
  /** Аудитория: шоколадная доска с «меловыми» строками, часы, парта с тетрадью. update(t, minuteDeg). */
  window.buildRoom = function (back, front) {
    svg('rect', { x: 80, y: 610, width: 920, height: 600, rx: 36, fill: C.choco }, back);
    // строки мелом: короткие скруглённые штрихи (белый, прозрачность)
    const rows = [
      [130, 680, [70, 40, 110, 30, 60]],
      [130, 730, [50, 90, 40]],
      [130, 1080, [80, 30, 60, 90]],
      [130, 1130, [40, 70, 50, 30]],
      [760, 1080, [60, 40, 70]],
      [760, 1130, [90, 50]],
    ];
    for (const [x0, y, ws] of rows) {
      let x = x0;
      for (const w of ws) {
        svg('rect', { x, y, width: w, height: 12, rx: 6, fill: C.white, opacity: 0.28 }, back);
        x += w + 18;
      }
    }
    // часы
    const clock = svg('g', { transform: 'translate(900 700)' }, back);
    svg('circle', { r: 58, fill: C.soft }, clock);
    for (let k = 0; k < 12; k++) {
      const a = (k * Math.PI) / 6;
      svg('circle', { cx: 44 * Math.sin(a), cy: -44 * Math.cos(a), r: k % 3 ? 2.5 : 4, fill: C.onSoft }, clock);
    }
    const hourH = svg('rect', { x: -4, y: -26, width: 8, height: 30, rx: 4, fill: C.text }, clock);
    const minH = svg('rect', { x: -3, y: -42, width: 6, height: 46, rx: 3, fill: C.primary }, clock);
    svg('circle', { r: 6, fill: C.text }, clock);
    // парта и тетрадь (перед кругом)
    svg('rect', { x: 110, y: 1300, width: 860, height: 66, rx: 20, fill: C.primary }, front);
    const nb = svg('g', { transform: 'translate(300 1300) rotate(-4)' }, front);
    svg('rect', { x: -70, y: -34, width: 140, height: 30, rx: 6, fill: C.white }, nb);
    svg('rect', { x: -2, y: -34, width: 4, height: 30, fill: C.soft }, nb);
    const pen = svg('g', { transform: 'translate(760 1290) rotate(8)' }, front);
    svg('rect', { x: -60, y: -6, width: 120, height: 12, rx: 6, fill: C.honey }, pen);
    return {
      update(minuteDeg) {
        tr(minH, `rotate(${minuteDeg})`);
        tr(hourH, "rotate(300)"); // часовая стрелка стоит: за ролик проходит меньше часа, иначе шов петли
      },
    };
  };
})();

(function () {
  if (new URLSearchParams(location.search).get('still')) return;
  const { C, clamp, lerp, ease, win, svg, tr, op, set } = R;
  const place = R.place;
  const D = 55;
  const TAU = Math.PI * 2;
  const per = (k) => (TAU * k) / D;
  const CX = 540;
  const CY = 1010;
  const R1 = 350;
  const TK = 420;
  const IDLE = { idleSpeed: per(16), blinkEvery: D / 15 };

  const START = 5;
  const PH = [
    ['in', 5, 'Вдох'],
    ['hold', 5, 'Задержите дыхание'],
    ['out', 5, 'Выдох'],
  ];
  const CYCLE = 15;
  const N = 3;
  const END = START + N * CYCLE; // 50
  function phaseAt(t) {
    if (t < START || t >= END) return null;
    const c = Math.floor((t - START) / CYCLE);
    let x = (t - START) % CYCLE;
    for (let i = 0; i < PH.length; i++) {
      const [kind, len, name] = PH[i];
      if (x < len) return { cycle: c, i, kind, len, name, x, t0: t - x };
      x -= len;
    }
    return null;
  }
  function levelAt(t) {
    const p = phaseAt(t);
    if (!p) return 0;
    if (p.kind === 'in') return ease.inOutSine(p.x / p.len);
    if (p.kind === 'hold') return 1;
    return 1 - ease.inOutSine(p.x / p.len);
  }

  const S = R.stage(C.bg);
  const scene = svg('g', {}, S.world);
  const back = svg('g', {}, scene);
  const circle = svg('circle', { cx: CX, cy: CY, r: R1 * 0.72, fill: C.soft }, scene);
  const tkG = svg('g', {}, scene);
  const tk = R.breathingTimka(tkG);
  const front = svg('g', {}, scene);
  const room = window.buildRoom(back, front);
  const ui = svg('g', {}, S.world);
  const dots = [0, 1, 2].map((i) => svg('circle', { cx: CX + (i - 1) * 70, cy: 1460, r: 15, fill: C.primary }, ui));
  const mark = R.logo(ui, 'logo-mark');

  const hook = R.textBlock(S.text, { text: 'Через минуту\nвызовут к доске?', y: 300, w: 980, size: 88, line: 102, color: C.text, words: true });
  const scheme = R.textBlock(S.text, { text: 'Вдох 5, задержка 5,\nвыдох 5. Три раза', y: 300, w: 1000, size: 80, line: 96, color: C.text, words: true });
  const phaseNames = PH.map(([, , name]) => R.textBlock(S.text, { text: name, y: 290, w: 1000, size: 76, line: 92, color: C.text }));
  const digits = [];
  for (let d = 1; d <= 5; d++) digits[d] = R.textBlock(S.text, { text: String(d), y: 388, size: 150, line: 170, color: C.primary });
  const dizzy = R.textBlock(S.text, { text: 'Если закружилась голова,\nвернитесь к обычному дыханию', y: 1540, w: 900, font: 'text', size: 38, line: 48, color: C.text });
  const desk = R.textBlock(S.text, { text: 'Можно прямо\nза партой', y: 300, w: 980, size: 88, line: 102, color: C.text, words: true });
  const save = R.textBlock(S.text, { text: 'Сохраните, чтобы\nповторить перед ответом', y: 1530, w: 860, font: 'text', weight: 600, size: 44, line: 58, color: C.onSoft, words: true });

  const faceTrack = [[0, 'look']];
  for (let c = 0; c < N; c++) {
    const t0 = START + c * CYCLE;
    faceTrack.push([t0, 'in'], [t0 + 5, 'hold'], [t0 + 10, 'out']);
  }
  faceTrack.push([END, 'rest'], [54.3, 'look']);

  // взгляд в хуке: быстрые перескоки «доска — часы — доска» (период 1,1 с)
  const dart = (u) => {
    const x = ((u % 1.1) + 1.1) % 1.1;
    const a = [-2.4, 2.6, -2.4];
    const k = x < 0.5 ? 0 : x < 0.62 ? ease.inOutSine((x - 0.5) / 0.12) : x < 0.98 ? 1 : 1 + ease.inOutSine((x - 0.98) / 0.12);
    return k <= 1 ? lerp(a[0], a[1], k) : lerp(a[1], a[2], k - 1);
  };

  window.renderAt = function (tRaw) {
    const t = Math.round((((tRaw % D) + D) % D) * 1e6) / 1e6;
    const cam = { cx: CX, cy: 960, z: 1, x: 6 * Math.sin(per(3) * t), y: 5 * Math.sin(per(2) * t + 1), r: 0.25 * Math.sin(per(2) * t + 0.5) };
    tr(scene, R.camera(cam, 1));
    tr(ui, R.camera(cam, 1));
    tr(back, `translate(${-cam.x * 0.4} ${-cam.y * 0.4})`); // доска дальше круга — параллакс
    room.update((360 * t) / D); // минутная стрелка: оборот за ролик

    const L = levelAt(t);
    set(circle, { r: R1 * (0.72 + 0.28 * L) });
    const gaze = t < 3.4 ? 1 - ease.inOutSine((t - 2.9) / 0.5) : t > 54.2 ? ease.inOutSine((t - 54.2) / 0.5) : 0;
    tk.update({ t, fill: L, face: R.faceAt(faceTrack, t), x: CX, y: CY, size: TK, eyeDx: gaze * dart(t), eyeDy: -0.6 * gaze, ...IDLE });

    const p = phaseAt(t);
    const dotsO = win(t, 4.6, 5.2, 50.0, 50.5);
    dots.forEach((d, i) => {
      const cur = p ? p.cycle : t >= END ? N : -1;
      const act = i === cur ? ease.outCubic((t - (START + i * CYCLE)) / 0.4) : 0;
      set(d, { r: 15 + 7 * act, opacity: i <= cur ? 1 : 0.3 });
      op(d, dotsO);
    });

    if (t < 3.0) {
      const k = ease.inOutSine((t - 2.6) / 0.3);
      op(hook, 1 - k);
      R.wordsIn(hook, 1);
      hook.style.transform = `translateY(${-20 * k}px)`;
    } else if (t >= 54.35) {
      op(hook, 1);
      R.wordsIn(hook, clamp((t - 54.35) / 0.6));
      hook.style.transform = '';
    } else op(hook, 0);
    const sIn = (t - 2.95) / 0.6;
    const sOut = clamp((t - 4.75) / 0.25);
    if (sIn > 0 && sOut < 1) {
      op(scheme, 1 - sOut);
      R.wordsIn(scheme, clamp(sIn), { spread: 0.45 });
      scheme.style.transform = `translateY(${-20 * sOut}px)`;
    } else op(scheme, 0);
    phaseNames.forEach((n, i) => {
      if (!p || p.i !== i) return op(n, 0);
      const k = ease.outCubic((t - p.t0) / 0.3);
      const out = ease.inOutSine(clamp((p.x - (p.len - 0.2)) / 0.2));
      place(n, { o: k * (1 - out), y: 14 * (1 - k) });
    });
    for (let d = 1; d <= 5; d++) {
      const n = digits[d];
      if (!p || d > p.len) {
        op(n, 0);
        continue;
      }
      const sec = p.x - (p.len - d);
      if (sec < 0 || sec > 1) {
        op(n, 0);
        continue;
      }
      const k = ease.outCubic(sec / 0.2);
      const last = d === 1 ? 0.2 : 0.12;
      const out = ease.inOutSine(clamp((sec - (1 - last)) / last));
      const first = d === p.len ? 0 : 0.5;
      place(n, { o: (first + (1 - first) * k) * (1 - out), y: 10 * (1 - k), s: 0.96 + 0.04 * k });
    }
    place(dizzy, { o: win(t, 5.0, 5.8, 49.6, 50.3) * 0.9 });
    if (t > 50.1 && t < 54.45) {
      op(desk, 1 - ease.inOutSine((t - 54.1) / 0.35));
      R.wordsIn(desk, clamp((t - 50.2) / 0.8), { spread: 0.45 });
    } else op(desk, 0);
    const endO = win(t, 50.9, 51.6, 54.1, 54.45);
    mark.at(CX, 1452, 110 * (0.94 + 0.06 * ease.outCubic((t - 50.9) / 0.7)), endO);
    if (t > 51.3 && t < 54.45) {
      op(save, 1 - ease.inOutSine((t - 54.1) / 0.35));
      R.wordsIn(save, clamp((t - 51.4) / 0.8), { spread: 0.45, rise: 22 });
    } else op(save, 0);
  };

  R.ready().then(() => {
    window.READY = true;
  });
})();
