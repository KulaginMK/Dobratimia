// Обложка и кадр сторис.
(function () {
  const kind = new URLSearchParams(location.search).get('still');
  if (!kind) return;
  const { C, svg } = R;
  const S = R.stage(C.bg);
  const sceneAt = (g, cx, cy, r, size) => {
    const back = svg('g', {}, g);
    svg('circle', { cx, cy, r, fill: C.soft }, g);
    const tk = R.breathingTimka(svg('g', {}, g));
    tk.update({ t: 0.5, fill: 0.3, face: { kind: 'look', from: 'look', shift: 1 }, x: cx, y: cy, size, eyeDx: 2, eyeDy: -0.6, noBlink: true });
    const front = svg('g', {}, g);
    window.buildRoom(back, front).update(330);
  };
  if (kind === 'cover') {
    R.chip(S, { text: 'Дыши с Тимкой', y: 300 });
    R.textBlock(S.text, { text: '5-5-5', y: 370, size: 190, line: 200, color: C.primary });
    R.textBlock(S.text, { text: 'перед ответом', y: 572, size: 96, line: 110, color: C.text });
    const g = svg('g', { transform: 'translate(0 90)' }, S.world);
    sceneAt(g, 540, 1010, 290, 400);
    R.textBlock(S.text, { text: 'Три цикла прямо за партой', y: 1500, size: 46, line: 58, w: 820, font: 'text', weight: 600, color: C.onSoft });
  } else {
    R.wordmark(S, { y: 300, h: 76 });
    R.textBlock(S.text, { text: 'Что помогает вам\nперед ответом?', y: 440, size: 88, line: 102, w: 960, color: C.text });
    const g = svg('g', { transform: 'translate(540 980) scale(0.6) translate(-540 -1000)' }, S.world);
    sceneAt(g, 540, 1010, 260, 380);
    R.textBlock(S.text, { text: 'Ответьте в опросе ниже', y: 1290, size: 44, line: 56, font: 'text', weight: 600, color: C.onSoft });
  }
  window.renderAt = () => {};
  R.ready().then(() => (window.READY = true));
})();
