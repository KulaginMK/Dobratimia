"""Звук «5-5-5 перед ответом»: пэд ре мажор, ноты фаз, дыхание, тиканье часов на задержке; всё синтезировано кодом.
python3 reels/r9/audio.py out/audio.wav [длительность]"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "engine"))
import numpy as np
import synth as s
from synth import note as N

D = 55.0
out = sys.argv[1]
length = float(sys.argv[2]) if len(sys.argv) > 2 else D
START, CYCLE = 5.0, 15.0

b = s.buf(D + 8)
chords = [
    (-1.0, 6.2, ["D2", "A2", "F#3", "A3", "E4"]),
    (4.6, 21.2, ["D2", "A2", "F#3", "C#4", "E4"]),
    (19.6, 36.2, ["B1", "F#2", "D3", "A3", "C#4"]),
    (34.6, 51.2, ["G1", "D2", "B2", "F#3", "A3"]),
    (49.6, 57.0, ["D2", "A2", "F#3", "A3", "E4"]),
]
for a, z, ch in chords:
    s.mix(b, s.sine_pad([N(x) for x in ch], z - a, attack=2.2, release=2.8, level=0.08), a)

# ---- хук: часы тикают чуть торопливо, взгляд «доска — часы» ----
for k in range(6):
    s.mix(b, s.tick(1700 if k % 2 else 1400, 0.05, level=0.05), 0.15 + k * 0.5, pan=0.35)
s.mix(b, s.pop(800, 0.1, level=0.05), 0.62)
s.mix(b, s.pop(950, 0.1, level=0.04), 1.72)
for i, x in enumerate(["D4", "F#4", "A4"]):
    s.mix(b, s.pluck(N(x), 2.5, bright=0.4, level=0.11), 2.95 + i * 0.22, pan=-0.2 + 0.2 * i)

for c in range(3):
    t0 = START + c * CYCLE
    s.mix(b, s.felt(N("A3"), 3.2, level=0.10), t0, pan=-0.15)
    s.mix(b, s.felt(N("D4"), 3.2, level=0.09), t0 + 0.6, pan=0.15)
    s.mix(b, s.breath(5.0, "in", level=0.075), t0)
    s.mix(b, s.bell(N("F#5"), 4.0, level=0.045), t0 + 5)
    for k in range(1, 5):
        s.mix(b, s.tick(1500, 0.06, level=0.035), t0 + 5 + k, pan=0.3)
    for i, x in enumerate(["F#4", "D4", "A3"]):
        s.mix(b, s.felt(N(x), 3.5, level=0.085), t0 + 10 + i * 0.6, pan=0.2 - 0.2 * i)
    s.mix(b, s.breath(5.0, "out", level=0.09), t0 + 10)

for x, t0 in [("A4", 50.2), ("B4", 50.55), ("D5", 50.9), ("F#5", 51.5)]:
    s.mix(b, s.bell(N(x), 3.0, level=0.06), t0, pan=0.2)
s.mix(b, s.felt(N("A4"), 3.0, level=0.06), 54.35)

b = s.reverb(b, seconds=2.6, wet=0.28)
b = s.loop_wrap(b, D)
n = int(round(length * s.SR))
if n > b.shape[1]:
    b = np.concatenate([b, b[:, : n - b.shape[1]]], axis=1)
b = b[:, :n]
b = s.master_lufs(b, target=-18.0, ceiling_db=-1.5)
b = s.fade_edges(b, ms=30)
s.write(out, b)
