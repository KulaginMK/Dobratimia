"""Звук «4-7-8 перед сном»: тихий пэд фа мажор, ноты фаз, дыхание; всё синтезировано кодом.
python3 reels/r2/audio.py out/audio.wav [длительность]"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "engine"))
import numpy as np
import synth as s
from synth import note as N

D = 68.0
out = sys.argv[1]
length = float(sys.argv[2]) if len(sys.argv) > 2 else D
START, CYCLE = 5.0, 19.0

b = s.buf(D + 8)

# ---- пэды: аккорд на цикл ----
chords = [
    (3.6, 24.8, ["F2", "C3", "A3", "E4"]),
    (23.2, 43.8, ["D2", "A2", "F3", "C4", "E4"]),
    (42.2, 62.8, ["A#1", "F2", "D3", "A3", "C4"]),
    (61.2, 72.0, ["F2", "C3", "G3", "A3", "E4"]),
]
for a, z, ch in chords:
    s.mix(b, s.sine_pad([N(x) for x in ch], z - a, attack=2.5, release=3.0, level=0.09), a)
s.mix(b, s.sine_pad([N("F1")], D + 4, attack=0.01, release=4, level=0.035), 0)

# ---- хук: глаза распахнулись ----
s.mix(b, s.pop(700, 0.14, level=0.10), 0.45)
s.mix(b, s.pop(900, 0.12, level=0.06), 0.55, pan=0.2)
# схема и «Тимка сел»
for i, x in enumerate(["F4", "A4", "C5"]):
    s.mix(b, s.pluck(N(x), 2.5, bright=0.4, level=0.12), 2.95 + i * 0.22, pan=-0.2 + 0.2 * i)
s.mix(b, s.whoosh(0.7, 300, 1500, level=0.04), 3.0)

# ---- три цикла ----
for c in range(3):
    t0 = START + c * CYCLE
    # вдох 4 с: две ноты вверх, воздух
    s.mix(b, s.felt(N("C4"), 3.0, level=0.10), t0, pan=-0.15)
    s.mix(b, s.felt(N("F4"), 3.0, level=0.09), t0 + 0.4, pan=0.15)
    s.mix(b, s.breath(4.0, "in", level=0.075), t0)
    # задержка 7 с: тихий колокольчик и «тик» каждую секунду
    s.mix(b, s.bell(N("A5"), 4.0, level=0.05), t0 + 4)
    for k in range(1, 7):
        s.mix(b, s.tick(1500, 0.06, level=0.035), t0 + 4 + k, pan=0.1 * (-1) ** k)
    # выдох 8 с: три ноты вниз, долгий воздух
    for i, x in enumerate(["A4", "F4", "C4"]):
        s.mix(b, s.felt(N(x), 3.5, level=0.09), t0 + 11 + i * 0.5, pan=0.2 - 0.2 * i)
    s.mix(b, s.breath(8.0, "out", level=0.09), t0 + 11)

# ---- финал: Тимка ложится, колыбельная шкатулки, знак ----
s.mix(b, s.whoosh(0.8, 1400, 300, level=0.04), 62.35)
lullaby = [("C6", 62.5), ("A5", 62.9), ("F5", 63.3), ("G5", 63.7), ("A5", 64.3), ("F5", 64.9), ("C5", 65.7)]
for x, t0 in lullaby:
    s.mix(b, s.bell(N(x), 3.0, level=0.07), t0, pan=0.25)
    s.mix(b, s.pluck(N(x) / 2, 2.0, bright=0.2, level=0.05), t0, pan=-0.25)
s.mix(b, s.bell(N("F6"), 4.0, level=0.035), 63.4)
# на шве: вопрос возвращается — тихая нота
s.mix(b, s.felt(N("C5"), 3.0, level=0.06), 67.4)

b = s.reverb(b, seconds=3.4, wet=0.33)
b = s.loop_wrap(b, D)
n = int(round(length * s.SR))
if n > b.shape[1]:
    b = np.concatenate([b, b[:, : n - b.shape[1]]], axis=1)
b = b[:, :n]
b = s.master_lufs(b, target=-18.0, ceiling_db=-1.5)
s.write(out, b)
