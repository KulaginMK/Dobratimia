// «Дыши с Тимкой — 4-7-8 перед сном». 68 с, тёмный фон, петля: кадр 68,0 совпадает с кадром 0.
(function () {
  if (new URLSearchParams(location.search).get('still')) return; // обложка и сторис — в stills.js
  const { C, clamp, lerp, ease, win, keys, svg, tr, op, set } = R;
  const D = 68;
  const TAU = Math.PI * 2;
  const per = (k) => (TAU * k) / D;
  const CX = 540;
  const CY = 1030;
  const R1 = 360; // радиус круга на полном вдохе; на выдохе 0,72 от него (как в приложении)
  const R_SLEEP = 285;
  const TK = 430;
  const IDLE = { idleSpeed: per(18), blinkEvery: D / 19 };

  // ---- схема: 4-7-8, три цикла с 5 с ----
  const START = 5;
  const PH = [
    ['in', 4, 'Вдох'],
    ['hold', 7, 'Задержите дыхание'],
    ['out', 8, 'Выдох'],
  ];
  const CYCLE = 19;
  const END = START + 3 * CYCLE; // 62
  function phaseAt(t) {
    if (t < START || t >= END) return null;
    const c = Math.floor((t - START) / CYCLE);
    let x = (t - START) % CYCLE;
    for (let i = 0; i < PH.length; i++) {
      const [kind, len, name] = PH[i];
      if (x < len) return { cycle: c, i, kind, len, name, x, left: Math.ceil(len - x - 1e-9), t0: t - x };
      x -= len;
    }
    return null;
  }
  // наполненность L: растёт 4 с, держится 7 с, снижается 8 с
  function levelAt(t) {
    const p = phaseAt(t);
    if (!p) return 0;
    if (p.kind === 'in') return ease.inOutSine(p.x / p.len);
    if (p.kind === 'hold') return 1;
    return 1 - ease.inOutSine(p.x / p.len);
  }

  const S = R.stage(C.choco);
  const far = svg('g', {}, S.world);
  const scene = svg('g', {}, S.world);
  const ui = svg('g', {}, S.world);

  // ---- дальний план: крупные мягкие пятна и медовые звёзды ----
  [
    [130, 560, 260],
    [980, 1450, 230],
    [820, 330, 150],
  ].forEach(([x, y, r]) => svg('circle', { cx: x, cy: y, r, fill: C.soft, opacity: 0.06 }, far));
  const stars = [
    [150, 760, 15, 0.0],
    [930, 700, 11, 1.3],
    [120, 1290, 10, 2.1],
    [960, 1240, 14, 0.7],
    [140, 1600, 9, 1.8],
    [955, 1610, 10, 2.6],
    [205, 600, 8, 3.1],
  ].map(([x, y, r, ph]) => ({ x, y, r, ph, n: svg('rect', { x: -r, y: -r, width: 2 * r, height: 2 * r, rx: r * 0.2, fill: C.honey }, far) }));
  // месяц: круг мёда, «выеденный» кругом фона
  const moon = svg('g', {}, far);
  svg('circle', { cx: 0, cy: 0, r: 38, fill: C.honey }, moon);
  svg('circle', { cx: 18, cy: -12, r: 34, fill: C.choco }, moon);

  // ---- круг ----
  const circle = svg('circle', { cx: CX, cy: CY, r: R_SLEEP, fill: C.soft }, scene);

  // ---- Тимка: дыхательная поза и «переходная» фигура (sleep ↔ breathing) ----
  const tkG = svg('g', {}, scene);
  const tk = R.breathingTimka(tkG);

  // Фигура для лёжа и перехода: контуры позы sleep плавно переходят в дыхательную позу (у путей одинаковое строение).
  const parse = (name) => new DOMParser().parseFromString(window.ASSETS[name], 'image/svg+xml').documentElement;
  const sl = parse('timka-sleep');
  const br = parse('timka-breathing');
  const slBody = sl.querySelector('#body');
  const slPaths = slBody.querySelectorAll('path');
  const SLEEP = { stem: slPaths[0].getAttribute('d'), leafL: slPaths[1].getAttribute('d'), leafR: slPaths[2].getAttribute('d'), body: slPaths[3].getAttribute('d') };
  const BREATH = {
    stem: br.querySelector('#stem').getAttribute('d'),
    leafL: br.querySelector('#leaf-left').getAttribute('d'),
    leafR: br.querySelector('#leaf-right').getAttribute('d'),
    body: br.querySelector('#body path').getAttribute('d'),
  };
  const nums = (d) => d.match(/-?\d*\.?\d+/g).map(Number);
  const tmpl = (d) => d.replace(/-?\d*\.?\d+/g, '#');
  const fillT = (tp, v) => {
    let i = 0;
    return tp.replace(/#/g, () => (Math.round(v[i++] * 1000) / 1000).toString());
  };
  // точки пути через аффинное преобразование (только пары координат: M и C)
  const mapPts = (v, f) => {
    const o = [];
    for (let i = 0; i < v.length; i += 2) {
      const [x, y] = f(v[i], v[i + 1]);
      o.push(x, y);
    }
    return o;
  };
  // Дыхательная поза при L = 0 (как её рисует breathingTimka): тело 0,97 × 0,94 от низа, росток опущен на 74·0,06,
  // листья наклонены на 0,18 рад вокруг черешков.
  const SY0 = R.B.BODY_EMPTY_Y;
  const SX0 = R.B.BODY_EMPTY_X;
  const DROP = -R.B.BODY_HEIGHT * (SY0 - 1);
  const rot = (cx, cy, a) => (x, y) => [cx + (x - cx) * Math.cos(a) - (y - cy) * Math.sin(a), cy + (x - cx) * Math.sin(a) + (y - cy) * Math.cos(a)];
  const TILT = R.B.LEAF_TILT;
  const TARGET = {
    body: mapPts(nums(BREATH.body), (x, y) => [60 + (x - 60) * SX0, 102 + (y - 102) * SY0]),
    stem: mapPts(nums(BREATH.stem), (x, y) => [x, y + DROP]),
    leafL: mapPts(nums(BREATH.leafL), (x, y) => {
      const [a, b] = rot(59.5, 18, -TILT)(x, y);
      return [a, b + DROP];
    }),
    leafR: mapPts(nums(BREATH.leafR), (x, y) => {
      const [a, b] = rot(60.5, 14, TILT)(x, y);
      return [a, b + DROP];
    }),
  };
  const FROM = { body: nums(SLEEP.body), stem: nums(SLEEP.stem), leafL: nums(SLEEP.leafL), leafR: nums(SLEEP.leafR) };
  const TPL = { body: tmpl(SLEEP.body), stem: tmpl(SLEEP.stem), leafL: tmpl(SLEEP.leafL), leafR: tmpl(SLEEP.leafR) };

  const mG = svg('g', {}, scene);
  const mInner = svg('g', {}, mG);
  const mStem = svg('path', { fill: 'none', stroke: '#6E8A4E', 'stroke-width': 3.5, 'stroke-linecap': 'round' }, mInner);
  const mLeafL = svg('path', { fill: '#8FA66B' }, mInner);
  const mLeafR = svg('path', { fill: '#6E8A4E' }, mInner);
  const mBody = svg('path', { fill: '#F2B28A' }, mInner);
  const mFace = svg('g', {}, mInner);
  const mCheeks = [39, 81].map((x) => svg('ellipse', { cx: x, cy: 73, rx: 5.5, ry: 3.2, fill: '#E07A5F', opacity: 0.55 }, mFace));
  const mClosed = svg('g', {}, mFace);
  svg('path', { d: 'M44 64 Q48 67.5 52 64', fill: 'none', stroke: '#2C1F1A', 'stroke-width': 2.6, 'stroke-linecap': 'round' }, mClosed);
  svg('path', { d: 'M68 64 Q72 67.5 76 64', fill: 'none', stroke: '#2C1F1A', 'stroke-width': 2.6, 'stroke-linecap': 'round' }, mClosed);
  const mOpen = svg('g', {}, mFace);
  const mEyes = svg('g', {}, mOpen);
  svg('ellipse', { cx: 48, cy: 64, rx: 3.5, ry: 4.3, fill: '#2C1F1A' }, mEyes);
  svg('circle', { cx: 49.2, cy: 62.4, r: 1.1, fill: '#FFFFFF' }, mEyes);
  svg('ellipse', { cx: 72, cy: 64, rx: 3.5, ry: 4.3, fill: '#2C1F1A' }, mEyes);
  svg('circle', { cx: 73.2, cy: 62.4, r: 1.1, fill: '#FFFFFF' }, mEyes);
  // улыбка: у позы look — «M55.5 76.5 Q60 78.9 64.5 76.5», у позы rest — глубже
  const mSmile = svg('path', { fill: 'none', stroke: '#2C1F1A', 'stroke-width': 2.6, 'stroke-linecap': 'round' }, mFace);
  // «Z» из позы sleep
  const zzz = svg('g', {}, mG);
  const slZ = sl.querySelector('#zzz');
  for (const c of Array.from(slZ.childNodes)) zzz.appendChild(document.importNode(c, true));

  /** m 0…1: 0 — поза sleep, 1 — дыхательная поза при L = 0. open — глаза открыты; smile 0…1; look — улыбка как у look (1) или rest (0). */
  function drawMorph(t, m, open, smile, lookSmile, z) {
    R.placeFigure(mG, CX, CY, TK);
    const k = ease.inOutSine(m);
    const L = (a, b) => a.map((v, i) => lerp(v, b[i], k));
    set(mBody, { d: fillT(TPL.body, L(FROM.body, TARGET.body)) });
    set(mStem, { d: fillT(TPL.stem, L(FROM.stem, TARGET.stem)) });
    set(mLeafL, { d: fillT(TPL.leafL, L(FROM.leafL, TARGET.leafL)) });
    set(mLeafR, { d: fillT(TPL.leafR, L(FROM.leafR, TARGET.leafR)) });
    // лицо: у позы sleep оно на 10 ниже; в дыхательной позе масштабируется вместе с телом
    const sx = lerp(1, SX0, k);
    const sy = lerp(1, SY0, k);
    tr(mFace, `translate(0 ${10 * (1 - k)}) translate(60 102) scale(${sx} ${sy}) translate(-60 -102)`);
    mCheeks.forEach((c) => set(c, { opacity: lookSmile ? 0.5 : 0.55 }));
    op(mOpen, open);
    op(mClosed, 1 - open);
    const blink = R.blinkAt(t, D / 15, 0.9);
    tr(mEyes, `translate(60 64) scale(1 ${blink}) translate(-60 -64)`);
    const y1 = lerp(78.9, 80.7, 1 - lookSmile);
    set(mSmile, { d: `M55.5 76.5 Q60 ${y1} 64.5 76.5`, opacity: smile });
    // спит: тело чуть поднимается, «Z» всплывают и тают (как motion="sleepy" в приложении)
    const sl = 0.5 - 0.5 * Math.cos((TAU * t) / 4);
    tr(mInner, `translate(60 102) scale(1 ${1 + 0.02 * sl * (1 - k)}) translate(-60 -102)`);
    tr(zzz, `translate(0 ${-3 * sl})`);
    op(zzz, (1 - 0.5 * sl) * z);
  }

  // ---- интерфейс: точки циклов ----
  const dots = [0, 1, 2].map((i) => svg('circle', { cx: CX + (i - 1) * 70, cy: 1480, r: 15, fill: C.soft }, ui));
  const mark = R.logo(ui, 'logo-mark-white');

  // ---- тексты (белые) ----
  const W = C.white;
  const hook = R.textBlock(S.text, { text: 'Не получается уснуть\nпосле учёбы?', y: 300, w: 980, size: 82, line: 98, color: W, words: true });
  const scheme = R.textBlock(S.text, { text: 'Вдох 4, задержка 7,\nвыдох 8. Три раза', y: 300, size: 80, line: 96, color: W, words: true });
  const phaseNames = PH.map(([, , name]) => R.textBlock(S.text, { text: name, y: 290, size: 80, line: 96, color: W }));
  const digits = [];
  for (let d = 1; d <= 8; d++) digits[d] = R.textBlock(S.text, { text: String(d), y: 392, size: 150, line: 170, color: W });
  const dizzy = R.textBlock(S.text, { text: 'Если закружилась голова,\nвернитесь к обычному дыханию', y: 1556, w: 900, font: 'text', size: 38, line: 48, color: W });
  const night = R.textBlock(S.text, { text: 'Спокойной ночи', y: 330, size: 96, line: 110, color: W, words: true });
  const save = R.textBlock(S.text, { text: 'Сохраните, чтобы повторить\nперед сном', y: 1510, w: 860, font: 'text', weight: 600, size: 44, line: 58, color: W, words: true });

  // лица: вдох — задержка — выдох; в конце — rest
  const faceTrack = [[0, 'look']];
  for (let c = 0; c < 3; c++) {
    const t0 = START + c * CYCLE;
    faceTrack.push([t0, 'in'], [t0 + 4, 'hold'], [t0 + 11, 'out']);
  }
  faceTrack.push([END, 'rest']);

  window.renderAt = function (tRaw) {
    const t = Math.round((((tRaw % D) + D) % D) * 1e6) / 1e6; // округление: кадры петли совпадают до пикселя
    const cam = { cx: CX, cy: 960, z: 1, x: 6 * Math.sin(per(3) * t), y: 5 * Math.sin(per(2) * t + 1), r: 0.3 * Math.sin(per(2) * t + 0.5) };
    tr(scene, R.camera(cam, 1));
    tr(far, R.camera(cam, 0.5));
    stars.forEach((s) => {
      const tw = 0.55 + 0.45 * Math.sin(per(9) * t + s.ph * 2);
      op(s.n, 0.35 + 0.65 * tw);
      tr(s.n, `translate(${s.x} ${s.y}) rotate(45) scale(${0.75 + 0.25 * tw})`);
    });
    tr(moon, `translate(${935} ${655 + 6 * Math.sin(per(1) * t)})`);

    // ---- круг ----
    const L = levelAt(t);
    const rCycle = R1 * (0.72 + 0.28 * L);
    const toCycle = ease.inOutSine((t - 3.0) / 1.6);
    const toSleep = ease.inOutSine((t - 62.35) / 1.0);
    let r = R_SLEEP;
    if (t >= 3.0 && t < 62.35) r = lerp(R_SLEEP, rCycle, toCycle);
    else if (t >= 62.35) r = lerp(R1 * 0.72, R_SLEEP, toSleep);
    set(circle, { r });

    // ---- Тимка ----
    const m = t < 3.0 ? 0 : t < 3.7 ? ease.inOutSine((t - 3.0) / 0.7) : t < 62.35 ? 1 : 1 - ease.inOutSine((t - 62.35) / 0.75);
    const breathing = t >= 3.7 && t < 62.35;
    op(tkG, breathing ? 1 : 0);
    op(mG, breathing ? 0 : 1);
    if (breathing) {
      // покачивание листьев затихает к моментам перехода, чтобы стык с фигурой перехода был точным
      const idleK = clamp((t - 3.7) / 0.8) * clamp((62.35 - t) / 0.8);
      tk.update({ t, fill: L, face: R.faceAt(faceTrack, t), x: CX, y: CY, size: TK, idleK, ...IDLE });
    } else {
      const start = t < 30;
      // в начале: спит → на 0,45 с открывает глаза; в конце: глаза закрыты, улыбка гаснет, появляются «Z»
      const open = start ? ease.inOutSine((t - 0.45) / 0.12) : 0;
      const smile = start ? ease.inOutSine((t - 0.5) / 0.25) : 1 - ease.inOutSine((t - 62.5) / 0.6);
      const z = start ? 1 - ease.inOutSine((t - 0.45) / 0.35) : ease.inOutSine((t - 63.0) / 0.8);
      drawMorph(t, m, open, smile, start ? 1 : 0, z);
    }

    // ---- точки циклов ----
    const p = phaseAt(t);
    const dotsO = win(t, 4.6, 5.2, 62.4, 63.0);
    dots.forEach((d, i) => {
      const cur = p ? p.cycle : t >= END ? 3 : -1;
      const act = i === cur ? ease.outCubic((t - (START + i * CYCLE)) / 0.4) : 0;
      set(d, { r: 15 + 7 * act, fill: C.soft, opacity: i < cur || i === cur ? 1 : 0.3 });
      op(d, dotsO);
    });

    // ---- тексты ----
    // хук: виден с кадра 0; на шве петли возвращается
    if (t < 3.0) {
      op(hook, 1 - ease.inOutSine((t - 2.6) / 0.3));
      R.wordsIn(hook, 1);
      hook.style.transform = `translateY(${-20 * ease.inOutSine((t - 2.6) / 0.3)}px)`;
    } else if (t >= 67.35) {
      op(hook, 1);
      R.wordsIn(hook, clamp((t - 67.35) / 0.65));
      hook.style.transform = '';
    } else op(hook, 0);
    // схема
    const sIn = (t - 2.95) / 0.6;
    const sOut = clamp((t - 4.8) / 0.25);
    if (sIn > 0 && sOut < 1) {
      op(scheme, 1 - sOut);
      R.wordsIn(scheme, clamp(sIn), { spread: 0.45 });
      scheme.style.transform = `translateY(${-20 * sOut}px)`;
    } else op(scheme, 0);
    // фаза и счёт
    phaseNames.forEach((n, i) => {
      if (!p || p.i !== i) return op(n, 0);
      const k = ease.outCubic((t - p.t0) / 0.3);
      const out = ease.inOutSine(clamp((p.x - (p.len - 0.2)) / 0.2));
      place(n, { o: k * (1 - out), y: 14 * (1 - k) });
    });
    // цифры: новая проявляется за 0,2 с, прежняя гаснет за последние 0,12 с своей секунды — без пустого кадра
    for (let d = 1; d <= 8; d++) {
      const n = digits[d];
      if (!p || d > p.len) {
        op(n, 0);
        continue;
      }
      const a = p.len - d; // секунда, когда появляется цифра d
      const sec = p.x - a;
      if (sec < 0 || sec > 1) {
        op(n, 0);
        continue;
      }
      const k = ease.outCubic(sec / 0.2);
      const last = d === 1 ? 0.2 : 0.12;
      const out = ease.inOutSine(clamp((sec - (1 - last)) / last));
      const first = d === p.len ? 0 : 0.5; // первая цифра фазы проявляется с нуля, следующие — с половины
      place(n, { o: (first + (1 - first) * k) * (1 - out), y: 10 * (1 - k), s: 0.96 + 0.04 * k });
    }
    place(dizzy, { o: win(t, 5.0, 5.8, 61.8, 62.6) * 0.92 });
    // финал
    if (t > 62.4 && t < 67.45) {
      op(night, 1 - ease.inOutSine((t - 67.1) / 0.35));
      R.wordsIn(night, clamp((t - 62.5) / 0.9), { spread: 0.4 });
    } else op(night, 0);
    const endO = win(t, 63.4, 64.2, 67.1, 67.45);
    mark.at(CX, 1400, 150 * (0.94 + 0.06 * ease.outCubic((t - 63.4) / 0.8)), endO);
    if (t > 63.9 && t < 67.45) {
      op(save, 1 - ease.inOutSine((t - 67.1) / 0.35));
      R.wordsIn(save, clamp((t - 64.0) / 0.9), { spread: 0.45, rise: 22 });
    } else op(save, 0);
  };
  const place = R.place;

  R.ready().then(() => {
    window.READY = true;
  });
})();
