// Обложка (центр 1080×1350 виден в сетке профиля) и кадр сторис для репоста с местом под стикер.
(function () {
  const kind = new URLSearchParams(location.search).get('still');
  if (!kind) return;
  const { C, svg } = R;
  const S = R.stage(C.choco);
  [[130, 560, 260], [980, 1450, 230], [820, 330, 150]].forEach(([x, y, r]) => svg('circle', { cx: x, cy: y, r, fill: C.soft, opacity: 0.06 }, S.world));
  const star = (x, y, r) => svg('rect', { x: -r, y: -r, width: 2 * r, height: 2 * r, rx: r * 0.2, fill: C.honey, transform: `translate(${x} ${y}) rotate(45)` }, S.world);
  const moon = (x, y) => {
    svg('circle', { cx: x, cy: y, r: 38, fill: C.honey }, S.world);
    svg('circle', { cx: x + 18, cy: y - 12, r: 34, fill: C.choco }, S.world);
  };
  const sleeping = (cx, cy, r, size) => {
    svg('circle', { cx, cy, r, fill: C.soft }, S.world);
    const p = R.poseTimka(S.world, 'sleep', { noShadow: true });
    p.update({ t: 0, x: cx, y: cy, size, zzz: 0.3 });
  };
  if (kind === 'cover') {
    R.chip(S, { text: 'Дыши с Тимкой', y: 330, bg: C.soft, color: C.onSoft });
    R.textBlock(S.text, { text: '4-7-8', y: 420, size: 190, line: 200, color: C.white });
    R.textBlock(S.text, { text: 'перед сном', y: 630, size: 110, line: 124, color: C.white });
    sleeping(540, 1150, 280, 430);
    [[150, 900, 14], [930, 860, 11], [140, 1350, 10], [950, 1330, 13]].forEach((a) => star(...a));
    moon(900, 800);
    R.textBlock(S.text, { text: 'Три цикла, чтобы замедлиться после учёбы', y: 1490, size: 46, line: 58, w: 820, font: 'text', weight: 600, color: C.white });
  } else {
    R.wordmark(S, { y: 300, h: 76, color: C.white, mark: 'logo-mark-white' });
    R.textBlock(S.text, { text: 'Попробуете 4-7-8\nсегодня вечером?', y: 450, size: 92, line: 106, w: 960, color: C.white });
    sleeping(540, 960, 200, 300);
    [[200, 820, 11], [880, 780, 9], [860, 1110, 12]].forEach((a) => star(...a));
    R.textBlock(S.text, { text: 'Ответьте в опросе ниже', y: 1220, size: 44, line: 56, font: 'text', weight: 600, color: C.soft });
  }
  window.renderAt = () => {};
  R.ready().then(() => (window.READY = true));
})();
