// «Доброе слово — ночь перед экзаменом». 18 с, по шаблону «Доброе слово в двух тональностях» (2026-11-23). Фразы — дословно из expo-app/src/data/mocks/phrases.ts.
(function () {
  if (new URLSearchParams(location.search).get('still')) return;
  const { C, clamp, lerp, ease, win, keys, svg, tr, op, set, div } = R;
  const D = 18;
  const SWEET = 'Не обязательно знать всё. Даже профессора иногда заглядывают в учебник.'; // sweet-7
  const SPICY = 'Учебник не обидится, если вы закроете его и пойдёте спать. Во сне мозг как раз раскладывает выученное по полочкам.'; // spicy-2

  // ---- сцена: дальний слой (SVG) и «камера» — div, внутри которого и графика, и текст ----
  document.body.style.cssText = `margin:0;width:1080px;height:1920px;overflow:hidden;background:${C.bg}`;
  const root = div({ style: { position: 'absolute', inset: '0', width: '1080px', height: '1920px', overflow: 'hidden', background: C.bg } }, document.body);
  const farSvg = svg('svg', { width: 1080, height: 1920, viewBox: '0 0 1080 1920' }, root);
  farSvg.style.position = 'absolute';
  const far = svg('g', {}, farSvg);
  const blobs = [
    [120, 380, 220, C.soft, 0.5],
    [1000, 1500, 210, C.growthSoft, 0.8],
    [60, 1650, 160, C.soft, 0.45],
    [990, 260, 110, C.growthSoft, 0.7],
  ].map(([x, y, r, c, o]) => svg('circle', { cx: x, cy: y, r, fill: c, opacity: o }, far));
  const cam = div({ style: { position: 'absolute', left: '0', top: '0', width: '1080px', height: '1920px', transformOrigin: '0 0' } }, root);
  const abs = (style, parent = cam, html) => div({ style: Object.assign({ position: 'absolute' }, style), html }, parent);

  // три учебника падают в стопку на 0,45 / 0,85 / 1,25 с (под карточкой)
  const cupSvg = svg('svg', { width: 1080, height: 1920, viewBox: '0 0 1080 1920' }, cam);
  cupSvg.style.cssText = 'position:absolute;left:0;top:0;overflow:visible';
  const CUPS = [0.45, 0.85, 1.25].map((at, i) => {
    const g = svg('g', {}, cupSvg);
    const inner = svg('g', {}, g);
    const steam = svg('g', {}, inner); // у книг пара нет — пустая группа для совместимости
    const w = [380, 340, 360][i];
    svg('rect', { x: -w / 2, y: -30, width: w, height: 60, rx: 12, fill: [C.primary, C.choco, C.primary][i] }, inner);
    svg('rect', { x: w / 2 - 70, y: -30, width: 26, height: 60, fill: C.soft, opacity: 0.55 }, inner);
    svg('rect', { x: -w / 2 + 30, y: -6, width: w * 0.35, height: 12, rx: 6, fill: C.white, opacity: 0.4 }, inner);
    return { at, g, inner, steam, x: 540 + [-10, 14, -6][i], y: 1010 - i * 62, r: [-3, 4, -2][i] };
  });
  // вопрос: сначала крупно, потом — подпись сверху
  const q = abs({ left: '60px', top: '0', width: '960px', textAlign: 'center', font: "900 92px 'Nunito'", lineHeight: '108px', color: C.text, transformOrigin: '50% 0' }, cam, 'Учить всю ночь<br>перед экзаменом?');
  const label = R.textBlock(cam, { text: 'Учить всю ночь перед экзаменом?', y: 296, w: 1040, x: 20, size: 52, line: 76, color: C.text });

  // переключатель тона, как в приложении (SegmentedControl): дорожка и бегунок
  const SEG = { x: 90, y: 410, w: 900, h: 136, pad: 10 };
  const seg = abs({ left: SEG.x + 'px', top: SEG.y + 'px', width: SEG.w + 'px', height: SEG.h + 'px', borderRadius: '999px', background: C.soft });
  const thumbW = (SEG.w - 3 * SEG.pad) / 2;
  const thumb = abs({ left: SEG.pad + 'px', top: SEG.pad + 'px', width: thumbW + 'px', height: SEG.h - 2 * SEG.pad + 'px', borderRadius: '999px', background: C.bg }, seg);
  const lab = (i, text) => abs({ left: SEG.pad + i * (thumbW + SEG.pad) + 'px', top: '0', width: thumbW + 'px', height: SEG.h + 'px', display: 'flex', alignItems: 'center', justifyContent: 'center', font: "600 42px 'Golos Text'" }, seg, text);
  const labSweet = lab(0, 'Сахарный');
  const labSpicy = lab(1, 'С перчиком');
  const touch = abs({ left: '0', top: '0', width: '160px', height: '160px', marginLeft: '-80px', marginTop: '-80px', borderRadius: '50%', background: C.text }, cam);

  // карточка фразы (PhraseCard): «Сахарный» — мягкая терракота, «С перчиком» — шоколад, раскрывается кругом из точки касания
  const CARD = { x: 90, y: 600, w: 900, h: 780 };
  const card = abs({ left: CARD.x + 'px', top: CARD.y + 'px', width: CARD.w + 'px', height: CARD.h + 'px', borderRadius: '78px', overflow: 'hidden', background: C.soft });
  abs({ right: '-110px', top: '-110px', width: '440px', height: '440px', borderRadius: '50%', background: C.bg, opacity: '0.6' }, card);
  abs({ left: '-46px', bottom: '-46px', width: '150px', height: '150px', borderRadius: '50%', background: C.honey, opacity: '0.9' }, card);
  const textBox = (parent, text, size, line, color) => {
    const b = abs({ left: '76px', top: '0', width: CARD.w - 152 + 'px', height: CARD.h - 90 + 'px', display: 'flex', alignItems: 'center' }, parent);
    const t = R.textBlock(b, { text, y: 0, w: CARD.w - 152, x: 0, size, line, color, align: 'left', words: true, balance: false });
    t.style.position = 'relative';
    return t;
  };
  const sweetT = textBox(card, SWEET, 70, 86, C.onSoft);
  const spicy = abs({ left: '0', top: '0', width: CARD.w + 'px', height: CARD.h + 'px', background: C.choco }, card);
  const spicyT = textBox(spicy, SPICY, 58, 74, C.white);

  // Тимка (SVG поверх карточки)
  const tkSvg = svg('svg', { width: 1080, height: 1920, viewBox: '0 0 1080 1920' }, cam);
  tkSvg.style.position = 'absolute';
  tkSvg.style.left = '0';
  tkSvg.style.top = '0';
  tkSvg.style.overflow = 'visible';
  const tk = R.breathingTimka(svg('g', {}, tkSvg));

  // финал
  const endQ = R.textBlock(cam, { text: 'Какой тон\nнужен вам?', y: 300, size: 96, line: 108, color: C.text, words: true });
  const endHint = R.textBlock(cam, { text: 'Напишите в комментариях:\nсахарный или с перчиком', y: 1290, w: 900, font: 'text', weight: 600, size: 46, line: 60, color: C.text, words: true });
  const markG = R.logo(farSvg, 'logo-mark');
  const word = R.textBlock(root, { text: 'Добратимия', y: 1500, w: 400, x: 0, size: 44, line: 76, color: C.text, align: 'left' });

  const faceTrack = [
    [0, 'look'],
    [0.55, 'in'],
    [2.7, 'look'],
    [3.9, 'rest'],
    [7.75, 'look'],
    [8.55, 'hold'],
    [14.5, 'look'],
    [15.45, 'rest'],
    [16.65, 'hold'],
  ];

  const place = R.place;
  window.renderAt = function (t) {
    t = clamp(t, 0, D);
    // ---- камера ----
    const z = keys(t, [[0, 1.08], [2.5, 1.05], [3.4, 1.0], [7.6, 1.02], [8.05, 1.06], [9.2, 1.03], [14.2, 1.0], [18, 1.0]]);
    const cx = keys(t, [[0, 540], [7.6, 540], [8.05, 620], [9.2, 550], [14.2, 540], [18, 540]]);
    const cy = keys(t, [[0, 900], [2.5, 900], [3.4, 960], [7.6, 950], [8.05, 880], [9.2, 940], [14.2, 960], [18, 960]]);
    const r = 0.4 * Math.sin(t * 0.7);
    const dx = 5 * Math.sin(t * 0.9);
    cam.style.transform = `translate(${540 + dx}px, 960px) rotate(${r}deg) scale(${z}) translate(${-cx}px, ${-cy}px)`;
    tr(far, `translate(${540 + dx * 0.4} 960) rotate(${r * 0.4}) scale(${1 + (z - 1) * 0.4}) translate(${-(540 + (cx - 540) * 0.4)} ${-(960 + (cy - 960) * 0.4)})`);

    // ---- вопрос: крупно → подпись ----
    const toLabel = ease.inOutCubic((t - 2.55) / 0.8);
    const qOut = ease.inOutSine((t - 14.3) / 0.4);
    q.style.transform = `translateY(${lerp(540, 300, toLabel)}px) scale(${lerp(1, 0.6, toLabel)})`;
    op(q, 1 - ease.inOutSine((t - 2.6) / 0.35));
    const lb = ease.inOutSine((t - 3.0) / 0.4);
    place(label, { o: lb * (1 - qOut), y: 14 * (1 - lb) });

    // ---- чашки: падают сверху, сжимаются при касании, пар поднимается ----
    CUPS.forEach((c, i) => {
      const k = clamp((t - (c.at - 0.18)) / 0.18);
      const land = t - c.at;
      const sq = land > 0 && land < 0.22 ? 0.16 * Math.sin((Math.PI * land) / 0.22) : 0;
      tr(c.g, `translate(${c.x} ${c.y - 120 * (1 - ease.inCubic(k))}) rotate(${c.r})`);
      tr(c.inner, `translate(0 30) scale(${1 + sq * 0.5} ${1 - sq}) translate(0 -30)`);
      tr(c.steam, `translate(0 ${-8 * Math.sin(t * 2.4 + i)})`);
      op(c.steam, clamp((t - c.at - 0.15) / 0.3) * 0.9);
      op(c.g, k > 0 && t < 3.6 ? ease.outCubic(k * 1.6) : 0);
    });

    // ---- переключатель и карточка въезжают снизу ----
    const inUI = ease.outCubic((t - 2.6) / 0.85);
    const inCard = ease.outCubic((t - 2.75) / 0.85);
    const outCard = ease.inOutCubic((t - 14.35) / 0.7);
    seg.style.transform = `translateY(${(1 - inUI) * 1500 + lerp(0, 230, ease.inOutCubic((t - 14.45) / 0.8))}px)`;
    op(seg, t > 2.6 ? 1 : 0);
    card.style.transform = `translateY(${(1 - inCard) * 1500 + outCard * 1500}px)`;
    op(card, t > 2.75 && t < 15.2 ? 1 : 0);

    // бегунок: в 7,95 — вправо; в финале качается между тонами
    let pos = ease.inOutCubic((t - 7.95) / 0.32);
    if (t > 15.0) {
      // в такт: 15,4 → сахарный, 16,6 → с перчиком
      pos = 1 - ease.inOutCubic((t - 15.3) / 0.32) + ease.inOutCubic((t - 16.5) / 0.32);
    }
    thumb.style.transform = `translateX(${pos * (thumbW + SEG.pad)}px)`;
    labSweet.style.color = pos < 0.5 ? C.text : C.onSoft;
    labSpicy.style.color = pos >= 0.5 ? C.text : C.onSoft;
    // касание
    const tc = (t - 7.8) / 0.45;
    if (tc > 0 && tc < 1) {
      touch.style.left = SEG.x + SEG.pad * 2 + thumbW * 1.5 + 'px';
      touch.style.top = SEG.y + SEG.h / 2 + 'px';
      touch.style.transform = `scale(${0.3 + 0.7 * ease.outCubic(tc)})`;
      op(touch, 0.16 * (1 - ease.inCubic(tc)));
    } else op(touch, 0);

    // ---- фразы ----
    R.wordsIn(sweetT, clamp((t - 3.35) / 1.0), { spread: 0.55 });
    const rev = ease.inOutCubic((t - 8.0) / 0.6);
    spicy.style.clipPath = `circle(${rev * 1250}px at ${SEG.pad * 2 + thumbW * 1.5}px ${SEG.y + SEG.h / 2 - CARD.y}px)`;
    op(spicy, rev > 0 ? 1 : 0);
    R.wordsIn(spicyT, clamp((t - 8.45) / 1.4), { spread: 0.6 });

    // ---- Тимка: с вопросом в центре → прыгает на угол карточки → в центр финала ----
    const hop = ease.inOutCubic((t - 2.75) / 0.8);
    const back = ease.inOutCubic((t - 14.45) / 0.8);
    let x = lerp(540, 850, hop);
    let y = lerp(1290, 1385, hop) - 120 * Math.sin(Math.PI * hop);
    let size = lerp(430, 280, hop);
    x = lerp(x, 540, back);
    y = lerp(y, 1010, back) - 90 * Math.sin(Math.PI * back);
    size = lerp(size, 400, back);
    const face = R.faceAt(faceTrack, t);
    const fill = keys(t, [[0, 0.3], [8.5, 0.3], [8.9, 1], [14.4, 1], [14.9, 0.3], [16.6, 0.3], [16.95, 1]]);
    const eyeDx = keys(t, [[7.7, 0], [7.85, -2.2], [8.5, -2.2], [8.7, 0]]);
    const eyeDy = keys(t, [[0.5, 0], [0.6, -1.2], [2.6, -1.2], [2.8, 0], [7.7, 0], [7.85, -2.2], [8.5, -2.2], [8.7, 0]]);
    tk.update({ t, fill, face, x, y, size, eyeDx, eyeDy, noPuffs: true, blinkEvery: 3.1 });

    // ---- финал ----
    if (t > 14.6) {
      op(endQ, 1);
      R.wordsIn(endQ, clamp((t - 14.7) / 0.8), { spread: 0.45 });
      op(endHint, 1);
      R.wordsIn(endHint, clamp((t - 15.3) / 0.9), { spread: 0.5, rise: 22 });
    } else {
      op(endQ, 0);
      op(endHint, 0);
    }
    const mk = ease.outCubic((t - 16.0) / 0.7);
    // знак с надписью: знак 76 px, надпись 0,58 высоты, зазор 8 px
    const total = 76 + 8 + (window.WORDW || 250);
    const x0 = 540 - total / 2;
    markG.at(x0 + 38, 1538, 76, mk);
    word.style.left = x0 + 84 + 'px';
    op(word, mk);
  };

  R.ready().then(() => {
    // ширина надписи для точной вёрстки знака
    const probe = document.createElement('span');
    probe.style.cssText = "font:900 44px 'Nunito';position:absolute;visibility:hidden;white-space:nowrap";
    probe.textContent = 'Добратимия';
    document.body.appendChild(probe);
    window.WORDW = probe.getBoundingClientRect().width;
    probe.remove();
    window.READY = true;
  });
})();
