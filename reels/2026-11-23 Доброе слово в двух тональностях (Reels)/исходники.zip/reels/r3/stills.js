// Обложка (центр 1080×1350 виден в сетке профиля) и кадр сторис для репоста с местом под стикер.
(function () {
  const kind = new URLSearchParams(location.search).get('still');
  if (!kind) return;
  const { C, svg, div } = R;
  const S = R.stage(C.bg);
  [[120, 380, 220, C.soft, 0.5], [1000, 1500, 210, C.growthSoft, 0.8], [60, 1650, 160, C.soft, 0.45], [990, 260, 110, C.growthSoft, 0.7]].forEach(([x, y, r, c, o]) => svg('circle', { cx: x, cy: y, r, fill: c, opacity: o }, S.world));
  const cardEl = (x, y, w, h, rot, bg, color, text) =>
    div({ style: { position: 'absolute', left: x + 'px', top: y + 'px', width: w + 'px', height: h + 'px', borderRadius: '64px', background: bg, color, transform: `rotate(${rot}deg)`, display: 'flex', alignItems: 'flex-start', justifyContent: 'center', paddingTop: '70px', boxSizing: 'border-box', font: "900 66px 'Nunito'", textAlign: 'center', lineHeight: '76px' }, html: text }, S.text);
  if (kind === 'cover') {
    R.chip(S, { text: 'Доброе слово', y: 320 });
    R.textBlock(S.text, { text: 'Завалили\nколлоквиум?', y: 430, size: 116, line: 128, w: 980 });
    cardEl(50, 790, 470, 430, -6, C.soft, C.onSoft, 'Сахарный');
    cardEl(540, 860, 470, 430, 5, C.choco, C.white, 'С перчиком');
    const tkSvg = svg('svg', { width: 1080, height: 1920, viewBox: '0 0 1080 1920' }, S.text);
    tkSvg.style.position = 'absolute';
    const tk = R.breathingTimka(tkSvg);
    tk.update({ t: 0.5, fill: 0.8, face: { kind: 'hold', from: 'hold', shift: 1 }, x: 540, y: 1300, size: 330, noBlink: true });
    R.textBlock(S.text, { text: 'Одна ситуация,\nдва тона поддержки', y: 1500, size: 48, line: 60, w: 860, font: 'text', weight: 600 });
  } else {
    R.wordmark(S, { y: 300, h: 76 });
    R.textBlock(S.text, { text: 'Вам сегодня\nсахарный\nили с перчиком?', y: 440, size: 92, line: 106, w: 960 });
    const tkSvg = svg('svg', { width: 1080, height: 1920, viewBox: '0 0 1080 1920' }, S.text);
    tkSvg.style.position = 'absolute';
    svg('circle', { cx: 540, cy: 1000, r: 170, fill: C.soft }, tkSvg);
    const tk = R.breathingTimka(tkSvg);
    tk.update({ t: 0.5, fill: 0.4, face: { kind: 'look', from: 'look', shift: 1 }, x: 540, y: 1000, size: 270, noBlink: true });
    R.textBlock(S.text, { text: 'Ответьте в опросе ниже', y: 1215, size: 44, line: 56, font: 'text', weight: 600, color: C.primary });
  }
  window.renderAt = () => {};
  R.ready().then(() => (window.READY = true));
})();
